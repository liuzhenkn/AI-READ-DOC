import { IConfig } from '@umijs/types'

const config: IConfig = {
  logo: 'https://pic1.zhimg.com/v2-a1761065ad0d593d6819722ecdc97805.png',
  title: ' ',
  mode: 'site',
  locales: [['zh-CN', '中文']],
  hash: true,
  resolve: {
    includes: ['docs'],
    excludes: ['tree.md']
  },
  // NOTE: 部署到 zhdocs，需要开启 html 后缀，如果没有 html 后缀，zhdoc nginx 会重定向到错误地址
  exportStatic: { htmlSuffix: true },
  webpack5: {},
  navs: [
    null,
    {
      title: '生态',
      path: 'http://mix-market.zhdocs.io/',
    },
    {
      title: 'Gitlab',
      path: 'https://git.in.zhihu.com/fe/mix',
    },
    {
      title: '更新日志',
      path: 'https://git.in.zhihu.com/fe/mix/-/blob/master/packages/cli/CHANGELOG.md',
    }
  ]
}

export default config
