#!/usr/bin/env node

const yargs = require('yargs/yargs')
const { hideBin } = require('yargs/helpers')
const shelljs = require('shelljs')
const debug = require('debug')
const path = require('path')
const fs = require('fs')

const log = debug('link')
log.enabled = true

const argv = yargs(hideBin(process.argv)).argv

function copyEnvLocal () {
  const envConfigPath = path.resolve(__dirname, './../mix-example/.env.local.development')
  const envConfigtTemplate = path.resolve(__dirname, './../mix-example/.env.local.development.template')

  fs.access(envConfigPath, fs.constants.F_OK, (err) => {
    if (err) {
      shelljs.cp(envConfigtTemplate, envConfigPath)
      log('生成 env local 配置文件: ' + envConfigPath)
    }
  })
}

if (argv['mix-example']) {
  log('mix-example link react-dom / react 防止出现多个react实例导致服务端渲染报错')

  const example = 'mix-example'

  shelljs.exec(`cd ${example}/node_modules/react && pnpm link --global`)
  shelljs.exec(`cd ${example}/node_modules/react-dom && pnpm link --global`)
  shelljs.exec(`cd ${example}/node_modules/@zh-mix-mkt/react-helmet && pnpm link --global`)
  shelljs.exec(`cd ${example}/node_modules/@zh-mix-mkt/react-css-critical && pnpm link --global`)

  shelljs.exec('cd packages/core-react && pnpm link --global react')
  shelljs.exec('cd packages/core-react && pnpm link --global react-dom')

  shelljs.exec('cd packages/plugin-react && pnpm link --global react')
  shelljs.exec('cd packages/plugin-react && pnpm link --global react-dom')

  // 和业务侧使用同一个 react-helmet 单例
  shelljs.exec('cd packages/core-react && pnpm link --global @zh-mix-mkt/react-helmet')
  shelljs.exec('cd packages/plugin-react && pnpm link --global @zh-mix-mkt/react-helmet')

  // 和业务侧使用同一个 react-css-critical 单例
  shelljs.exec('cd packages/plugin-react && pnpm link --global @zh-mix-mkt/react-css-critical')

  log('link mix 开发包到全局')
  shelljs.exec('cd packages/cli && pnpm link --global')
  shelljs.exec('cd packages/core-koa && pnpm link --global')
  shelljs.exec('cd packages/plugin-koa && pnpm link --global')
  shelljs.exec('cd packages/plugin-react && pnpm link --global')
  shelljs.exec('cd packages/types && pnpm link --global')
  shelljs.exec('cd packages/core-react && pnpm link --global')
  shelljs.exec('cd packages/utils && pnpm link --global')

  log(`${example} link mix 全局开发包`)
  shelljs.exec(`cd ${example}/ && pnpm link --global @zh-mix/cli`)
  shelljs.exec(`cd ${example}/ && pnpm link --global @zh-mix/plugin-koa`)
  shelljs.exec(`cd ${example}/ && pnpm link --global @zh-mix/plugin-react`)
  shelljs.exec(`cd ${example}/ && pnpm link --global @zh-mix/types`)
  shelljs.exec(`cd ${example}/ && pnpm link --global @zh-mix/core-koa`)
  shelljs.exec(`cd ${example}/ && pnpm link --global @zh-mix/core-react`)
  shelljs.exec(`cd ${example}/ && pnpm link --global @zh-mix/utils`)

  copyEnvLocal()

  log(`现在 ${example} 将使用本地开发包进行开发了`)
}
