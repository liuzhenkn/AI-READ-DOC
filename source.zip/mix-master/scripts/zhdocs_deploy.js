#!/usr/bin/env node

const { exec } = require('child_process')
const { spawnSync } = require('child_process')

const { BUILD_TYPE } = process.env

function getListFromShell (shell, options = { shell: true }) {
  const result = spawnSync(shell, options)

  const appList = result.stdout.toString().split('\n')
  appList.pop()

  return appList
}

function getXbuildDiffFiles (commit = 'HEAD', anotherCommit = 'origin/master') {
  const shell = `git --no-pager diff ${commit} ${anotherCommit} --name-only`
  const diffFiles = getListFromShell(shell)

  return diffFiles
}

if (BUILD_TYPE === 'master') {
  // 只有 master 触发构建
  const diffFile = getXbuildDiffFiles('HEAD', 'HEAD~')
  if (
    Array.isArray(diffFile) &&
    diffFile.some(file => /^docs\//.test(file))
  ) {
    exec('curl -X POST http://rtd01.dev.rack.zhihu.com/build/mix')
    console.log('DOCS__DEPLOY: 触发文档部署，文档变化文件如下 ↓')
    console.log(diffFile.filter(file => /^docs\//.test(file)))
  } else {
    console.log('DOCS__DEPLOY: 文档目录无代码变化，不触发文档部署')
  }
} else {
  console.log('DOCS__DEPLOY: 非 master 构建，不触发文档部署')
}
