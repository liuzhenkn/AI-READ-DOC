#!/usr/bin/env node

const shelljs = require('shelljs')
const debug = require('debug')

const log = debug('clean')
log.enabled = true

const files = [
  'packages/**/cjs',
  'packages/**/esm',
  'packages/**/node_modules',
  'mix-example/node_modules',
  'mix-example/build',
  'node_modules'
]

files.forEach((file) => {
  log(`删除 ${file}`)
  shelljs.rm('-rf', file)
})
