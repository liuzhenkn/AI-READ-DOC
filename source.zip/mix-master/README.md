# mix

- 文档：[http://mix.zhdocs.io/](http://mix.zhdocs.io/)
- mix 快速上手 PPT：[http://mix-ppt.zhdocs.io](http://mix-ppt.zhdocs.io)
- mix 物理市场(代码库)：[https://git.in.zhihu.com/fe/mix-market](https://git.in.zhihu.com/fe/mix-market)
- mix 物理市场(文档)：[http://mix-market.zhdocs.io/](http://mix-market.zhdocs.io/)
- mix 项目模板：[https://git.in.zhihu.com/kfe/mix-example](https://git.in.zhihu.com/kfe/mix-example)

## 开发

### 拉取 mix 代码

#### fork

- 打开代码仓库地址: [https://git.in.zhihu.com/fe/mix](https://git.in.zhihu.com/fe/mix)
- 点击「star」 + 「fork」

#### 拉取代码

```shell
git clone --recurse-submodules git@git.in.zhihu.com:guolei/mix.git # 注意 guolei 改成自己的代码库地址
```

- 注意：需要带 `recurse-submodules` 参数拉取代码，因为 mix 代码库包含了 mix-example 的 `git submodule` 依赖。如果拉取代码时未带参数，也可以待代码拉取完成之后执行：`git submodule update --init` 拉取 mix-example 代码

### 安装 pnpm

统一使用 `v7.x.x` 版本

#### 安装

- 官方文档：[https://pnpm.io/zh/installation](https://pnpm.io/zh/installation)

```shell
npm install -g pnpm # 其他方案也行，使用本方案作为记录

pnpm -v # 7.1.7

pnpm setup # 初次安装完  pnpm 需要执行命令更新全局 pnpm 包存储路径
```

比如执行 `pnpm setup` 后将在 `.zshrc` 中自动写入以下配置

```shell
# pnpm
export PNPM_HOME="/Users/arley_guolei/Library/pnpm"
export PATH="$PNPM_HOME:$PATH"
# pnpm end
```

### 安装依赖

```bash
pnpm run bootstrap
```

执行命令后，做了以下步骤：

- [x] 安装 mix 根目录 和 子包的所有依赖
- [x] 执行 mix 子包构建
- [x] 进行 example 的依赖安装
- [x] example 本地 mix link 开发
- [x] example 的 env 配置项检测写出

### 开始开发

```bash
# 开发本框架
pnpm run dev

# 开发 mix-example 例子
pnpm run example:dev
```

### 开发案例

[mix-example](https://git.in.zhihu.com/kfe/mix-example) 使用 `git submodule` 引入本仓库中，[学习参考文档](https://git-scm.com/book/zh/v2/Git-%E5%B7%A5%E5%85%B7-%E5%AD%90%E6%A8%A1%E5%9D%97)

#### 更新 mix-example 代码

```shell
git submodule update --remote
```

## e2e

### husky git pre-commit hook

在代码提交时，会通过 husky 执行 git 的 `pre-commit` 钩子执行项目 mix-example 的 e2e 测试，保证 mix 的框架集成稳定性

在保证 mix-example 引用的 mix 为本地包后，执行 e2e 之前需启动 mix-example 服务

推荐先构建一次 mix-example 的 production 代码，然后在 mix-example 中执行 `pnpm run start` 启动服务

## 发包

### 发正式包

已接入 changeset-publish CI 自动发包

代码修改完之后，执行 `pnpm changeset` 生成版本说明临时文件，提交代码合入 master 后将自动发包

- [https://git.in.zhihu.com/kfe/changeset-publish](https://git.in.zhihu.com/kfe/changeset-publish)
