---
title: mix - 为多 APP 场景而生的服务端渲染框架
order: 1
hero:
  title: M I X
  desc: 为多 APP 场景而生的服务端渲染框架
  actions:
    - text: 快速上手
      link: /guide.html
features:
  - icon: https://pic2.zhimg.com/v2-78e96125903e222308168f51f589616d.png
    title: 开箱即用
    desc: 基于 webpack 5 构建，内置 ts、less、按需 polyfill 等常用配置；渲染服务由框架提供，仅需关注业务开发
  - icon: https://pic3.zhimg.com/v2-72b1988d1dab86ad55b652499fec5b1e.png
    title: 多 APP 架构
    desc: 一个项目可创建多 app，每个 app 可创建多页面，同时支持约定式路由和声明式路由两种模式，页面资源动态按需加载
  - icon: https://pic2.zhimg.com/v2-44535596cea39f7cda372057ac50869a.png
    title: 高可用场景
    desc: 可无缝从 SSR 降级到 CSR，最佳容灾方案；没有模版引擎，All in JSX，每个 APP 可自行定制 HTML
  - icon: https://pic1.zhimg.com/v2-391dac40f141e5a891156c0282d9604a.png
    title: 现代化技术栈
    desc: 全面支持 typeScript、Hooks、React 17等技术栈，由 webpack 5、esbuild 进行构建驱动，智能按需引入 react-router
  - icon: https://pic1.zhimg.com/v2-28c71558a51da2233bd151a55a5d4d26.png
    title: 高拓展性
    desc: 可自行修改构建配置，服务支持自定义中间件；插件驱动，框架可高拓展性支持 vue 等其他前端框架，技术资产持续积累
  - icon: https://pic1.zhimg.com/v2-0e846776f0155c53a566c75b18078cec.png
    title: 功能丰富
    desc: 支持返回 Stream，多 APP 并行构建，轻松断点调试服务，容器多进程服务守护，不同容器启动不同 app 服务，spa 等
footer: Copyright © 2022-present<br />Powered by zhihu
---

<Alert type="info">
  一个普通的多 APP 项目使用 mix 做研发的目录结构大致如下
</Alert>

<embed src="./tree.md"></embed>

-----

<Alert type="info">
  开发模式 CLI 启动开发
</Alert>

![开发模式启动](https://zhihu-live.zhimg.com/namespace_1001/static/20220128/51eeae470fceb21ba4f500e1556a42da.gif)
