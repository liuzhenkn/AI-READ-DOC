---
title: APP 配置
toc: menu
order: 2
---

## 基础配置

App 配置可在每个 app 目录下的 `config.ts` 进行配置

### prefix <Badge>必配</Badge>

当前 APP 的 baseUrl，由于使用的是当项目多 APP 架构，该配置必配

- 类型: `string`
- 默认: `''`

在功能上等价于 `React-Router` 提供的 basename 以及 Vue-Router 提供的 base 选项，同样在设置完该参数后，前端路由的跳转操作都会添加该前缀

**例子**：某 app 的 `prefix: '/xen/manuscript'`，xen 可以认为是服务容器，nginx 会将 `/xen` 开头的请求打至该项目，manuscript 为 APP 名称。如果该 APP 有多个页面，比如首页 (index)，列表页 (list)，最终该 app 的页面路由将为

- 首页：`/xen/manuscript/index` 或 `/xen/manuscript` (index 可以省略)
- 列表页：`/xen/manuscript/list`

<Alert type="warning">
  配置时建议使用 app 名称作为标识，避免重复
</Alert>

## 常用构建配置

### chainBaseConfig

使用 webpack-chain 来修改 服务端/客户端 公共的 Webpack 构建配置

注意：开发者的大部分需求都应该修改 baseConfig 而不是独立的 serverConfig 或 clientConfig。由于 webpack-chain 官方未支持 webpack 5，在社区里找了 webpack 5 版本适用的 webpack-chain，框架层面已锁死 chain 包版本

- 类型: `(config: WebpackChain, isServer: boolean, app: string) => void`
- 默认: [react 场景](https://git.in.zhihu.com/fe/mix/-/blob/master/packages/plugin-react/src/webpackConfig/base.ts)

例如实现 svg 图标组件 ↓

```ts
const userConfig: UserConfig = {
  chainBaseConfig: (chain: WebpackChain) => {
  chain.module
    .rule('svg')
    .test(/\.svg$/)
    .use('@svgr/webpack')
    .loader(loadModule('@svgr/webpack'))
    .options({
      svgProps: {
        height: '{props.size || props.height}',
        width: '{props.size || props.width}',
        fill: '{props.fill || "currentColor"}'
      },
      svgo: false
    })
    .end()
  }
}
```

### chainServerConfig

使用 webpack-chain 来修改 服务端 公共的 Webpack 构建配置

- 类型: `(config: WebpackChain) => void`
- 默认: [react 场景](https://git.in.zhihu.com/fe/mix/-/blob/master/packages/plugin-react/src/webpackConfig/server.ts)

### chainClientConfig

使用 webpack-chain 来修改 客户端 公共的 Webpack 构建配置

- 类型: `(config: WebpackChain) => void`
- 默认: [react 场景](https://git.in.zhihu.com/fe/mix/-/blob/master/packages/plugin-react/src/webpackConfig/client.ts)

### css

用于添加用户自定义配置 css-loader less-loader 以及 postcss-loader 的配置，需要用 函数 return 的形式

```ts
css?: () => {
  loaderOptions?: {
    /** css loader options */
    cssOptions?: any
    less?: any
    postcss?: {
      /** function | object */
      options?: Function | Record<string, any>
      /** 用户自定义 postcss 插件 */
      plugins?: any[]
    }
  }
}
```

例如：增加 postcssZpxPlugin 的 postcss 插件，插件地址：[https://git.in.zhihu.com/guolei/zpx-2-vw](https://git.in.zhihu.com/guolei/zpx-2-vw)

```ts
import postcssZpxPlugin from '@zh-mix-mkt/postcss-zpx-plugin'

const userConfig: UserConfig = {
  css: () => ({
    loaderOptions: {
      postcss: {
        plugins: [
          postcssZpxPlugin({
            viewportWidth: 375
          })
        ]
      }
    }
  })
}

export { userConfig }
```

### babelOptions <Badge>1.0.0</Badge>

- 类型: `(isServer: boolean, app: string) => {presets?: unknown[], plugins?: unknown[]}`
- 默认: `undefined`

例如：增加 [babel-plugin-lodash](https://www.npmjs.com/package/babel-plugin-lodash)，实现按需引入 lodash

```ts
export default {
  babelOptions: (isServer) => {
    return {
      plugins: [
        !isServer && 'babel-plugin-lodash'
      ]
    }
  }
}
```

### babelExtraModule

框架默认不使用 babel 来编译 node_modules 中的代码，这会拖慢构建速度，且十分没有必要。一个质量合格的模块应当在发布前对自身进行构建。针对模块质量不合格的特殊情况，我们提供了配置来让开发者指定具体的模块参与 babel 编译

- 类型: `webpack.RuleSetCondition`
- 默认: `undefined`

```ts
export default {
  babelExtraModule: [/module-name/]
}
```

### mode

APP 渲染模式，默认为 `ssr`。当为 ssr 时，会在服务端请求数据并且注入数据至模板做服务端渲染。

注意当为 csr 时，请求也会经过服务端，仅是**不做服务端接口请求**，不做**页面级别**服务端渲染，放服务端遇到错误时，会优先使用该方案进行渲染。

- 类型: `ssr` | `csr`
- 默认: `ssr`

### static <Badge>1.1.0</Badge>

是否为真纯静态页，默认为 false。当设置为 `true` 时，开发和正式构建时，将不进行服务端代码构建。

- 类型: `boolean`
- 默认: `false`

注意：当 static 为 `false` 时，并且 `html` 配置的 template 模板存在时，也会生成纯静态部署方案 APP。

该配置项仅用于控制 APP 是否进行服务端构建。

### html <Badge>1.1.0</Badge>

当 html 配置项 template 路径存在时，将开启纯静态构建

`html-webpack-plugin` 配置，用于生成静态页 HTML

- 类型: [html-webpack-plugin Options](https://www.npmjs.com/package/html-webpack-plugin)
- 默认: `{template: '${app}/components/layout/index.html'}`

### useHash

构建产物是否带有 hash，默认生产环境开启，不建议关闭

- 类型: `boolean`
- 默认: `true`

### useReactRouter

react 框架下默认如果一个 app 只有一个页面将不引入 react-router，如果需要强制引入，可以设置该选项为 true

- 类型: `boolean`
- 默认: `false`

自动不引入的方式比较 hack，基于构建别名实现，如果不需要引入的情况下，会使用一个空模块代替 react-router

## 中间件

> 项目级别的中间件配置会暴露服务的 koa app 对象，应用级别的中间件 -不暴露- koa app，仅提供应用配置。

### beforeRender

服务端渲染前置中间件，在调用 render 前调用，其中的 next 为 render 渲染，所以这个比 afterRender 常用的多

可用于服务端渲染前的一些操作，比如重定向到其他页面

- 类型：`(appConfig: ServerAppConfig) => Middleware`
- 默认：`undefined`

例如：

```ts
const userConfig: UserConfig = {
  beforeRender: (appConfig) => {

    return async (ctx, next) => {
      console.time('render')

      console.log('1')

      // TIME 1
      await next() // react render

      console.log('2')

      console.timeEnd('render')
    }
  },
  afterRender: (appConfig) => {

    return async (ctx, next) => {

      // TIME 2 --- (2 - 1 才是真的 renderTime)

      console.time('afterRender')
      console.log('3')

      await next()

      console.log('4')
      console.timeEnd('afterRender')
    }
  }
}

```

当需要配置多个中间件时，可通过 compose 的形式转为一个中间件

### afterRender

服务端渲染后置中间件，在调用 render next 后调用

- 类型：`(appConfig: ServerAppConfig) => Middleware`
- 默认：`undefined`

## 更多配置

### polyfill

是否使用 `@babel/preset-env` corejs usage 作为 polyfill，默认 true，开启需要项目安装 `core-js@3` 模块

- 类型: `boolean`
- 默认: `true`

```ts
if (polyfill && !isServer) {
  Object.assign(envOptions, {
    targets: {
      // https://github.com/browserslist/browserslist
      chrome: '60',
      firefox: '60',
      ie: '11',
      safari: '10',
      edge: '17'
    },
    corejs: {
      version: 3,
      proposals: true
    },
    useBuiltIns: 'usage',
    ...corejsOptions
  })
}
```

### corejsOptions

该配置用于覆盖默认的 corejsOptions 配置

- 类型: `Record<string, any>`
- 默认: 如上所示

### parallelFetch

layout 和 page 的 fetch 是否并行发送

- 类型: `boolean`
- 默认: `undefined`

开启后在服务端获取数据时会并行请求 layout fetch 与 page fetch。若 page fetch 的请求依赖 layout fetch 的返回。请不要使用该选项

### publicPath

静态资源的 publicPath, 本地开发环境一般无需配置

生产环境若走本地静态资源目录可基于 afterRouterMiddleware 中间件实现 staic 中间件
若需要走单独的 CDN 服务部署可配置为具体的 CDN 地址例如 https://static.zhihu.com/mix/

### container

需要启动该 app 的服务容器，不设置默认启动，设置后可通过启动服务时传入容器名指定需要启动的 apps

字段详细解析：[Mix 怎么实现同一个项目下的服务拆分，每个服务启动不同的 APP？](https://why.in.zhihu.com/questions/10010000000150095/mix-zen-yao-shi-xian-tong-ge-xiang-mu-xia-de-fu-wu-chai-fen-mei-ge-fu-wu-qi-dong-bu-tong-de-app)

- 类型: `string`
- 默认: `''`

容器配置规则：

- 项目启动时未添加启动参数 `container` 或 `CONTAINER_NAME` 环境变量，不知道当前容器名是啥，故将启动项目中的所有 app
- 项目启动时有添加启动参数 `container` 或 `CONTAINER_NAME` 环境变量，将启动 APP 配置中 `container` 和启动命令所带的容器名相同的 APP 和 **未设置 APP container 的 APP**
- 启动项目时和 APP container 配置均有配置的情况下，如果值不相同则不启动

### cssCritical <Badge>1.8.0</Badge>

是否开启服务端渲染时的 CSS 首屏优化，业务方需配合[@zh-mix-mkt/react-css-critical](http://mix-market.zhdocs.io/market/react-css-critical.html)使用传入框架需要注入的 CSS 文件。

仅开启该配置的情况下，才能使用`react-css-critical`中的`useCssCritical`

此配置需要将[stream](http://mix.zhdocs.io/configs/app.html#stream)设置为 false 才可使用，需要使用 string 同步返回框架侧才能修改整体的 HTML 结果，如果 stream 开启的情况下使用了`useCssCritical`，框架侧会给出相应的报错提示。

- 类型：`boolean`
- 默认：`false`

### webpackStatsOption

webpack stats 配置，修改 webpack 的打包终端输出

- 类型: `WebpackConfiguration['stats']`
- 默认: 如下

```ts
const webpackStatsOption: IConfig['webpackStatsOption'] = {
  assets: true, // 添加资源信息
  cachedAssets: true, // 显示缓存的资源（将其设置为 `false` 则仅显示输出的文件）
  children: false, // 添加 children 信息
  chunks: false, // 添加 chunk 信息（设置为 `false` 能允许较少的冗长输出）
  colors: true, // 以不同颜色区分构建信息
  modules: false, // 添加构建模块信息
  warnings: false,
  entrypoints: false
}
```

### alias

配置 alias 构建别名

- 类型: `Record<string, string>`
- 默认: `{'@': "当前 APP 目录路径", '~': '项目根目录路径', '_build': '预构建临时产物路径，业务侧无使用场景，但不可配置覆盖'}`

### fePort

webpack-dev-server 托管前端静态资源的端口，Node.js Server 会自动 proxy 静态资源, 无特殊需求(比如同时启动多 APP) 不需要修改

- 类型：`number`
- 默认：`8888`

### host

webpack dev server 的启动 host，默认 0.0.0.0，一般无需修改

- 类型：`string`
- 默认：`0.0.0.0`

### webpackDevServerConfig

webpack-dev-server 启动配置，host 和 port 使用整体配置中的进行覆盖

- 类型：`webpack-dev-server.Configuration ↓`
- 详细配置参考：[https://github.com/webpack/webpack-dev-server/blob/b9e11ba90a35ec543140fbb3b50684ccfa122f5c/types/lib/Server.d.ts#L3730](https://github.com/webpack/webpack-dev-server/blob/b9e11ba90a35ec543140fbb3b50684ccfa122f5c/types/lib/Server.d.ts#L3730)
- 默认：↓

```ts
// dev-server 的很多配置网上找到的都是 v3 版本的，可以参考 https://github.com/webpack/webpack-dev-server/blob/master/migration-v4.md
// DOC: https://webpack.docschina.org/configuration/dev-server/
// 禁用输出在 webpack 的 infrastructureLogging 中配置

const webpackDevServerConfig = Object.assign({
  https,
  headers: {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, PATCH, OPTIONS',
    'Access-Control-Allow-Headers': 'X-Requested-With, content-type, Authorization'
  },
  // Allows to configure options for serving static files from directory (by default 'public' directory).
  static: false,
  client: {
    // Enables a full-screen overlay in the browser when there are compiler errors or warnings.
    overlay: true
  },
  allowedHosts: 'all',
  devMiddleware: {
    stats: webpackStatsOption
  }
}, userConfig.webpackDevServerConfig, {
  host,
  port: fePort
})
```

### stream

是否使用 stream 返回服务端渲染结果，加快展现速度，在关闭情况下将返回普通 html 字符串

- 类型：`boolean`
- 默认：`false`

服务端渲染异常时，如果使用的是 stream 形式，当捕获到流错误时，也会强制降级为 csr 的模式进行返回 html 字符串做异常兜底。

- 在 `catcher` 中间件中 `await next() [渲染中间件]` catch 不到 stream 的渲染报错，因为 stream 是异步操作
- fetch 中接口报错 `stream.on('error')` 是捕获不到的，其能捕获到 JSX 2 Stream 过程的异常，但是在  `catcher` 中间件中可以捕获

- 注意历史事故：[https://wiki.in.zhihu.com/pages/viewpage.action?pageId=54368966](heifetz 使用 stream render 导致服务端渲染时 head 标签中出现错误的信息)

### isDev

标识当前的构建和运行环境

- 类型：`boolean`
- 默认：`true`

标志当前环境，默认根据`process.env.NODE_ENV !== 'production'`判断

将影响到构建相关配置，比如：**devtool**、**cache**、**产物是否携带 hash**、**是否开启代码压缩**、**css 类名**等等

也会影响到运行时的一些区别，比如**是否开启本地静态代理**、**运行时异常输出**等

使用 mix 脚手架启动项目时，当执行 mix build 命令时，将注入环境变量 **NODE_ENV** 值为 **production**。当执行 mix dev 命令时，将注入环境变量 **NODE_ENV** 值为 **development**

### dynamic

是否开启代码分割

- 类型: `boolean`
- 默认: `true`

为 true 时，页面将生成为以 `dynamicComponent` 命名的函数，页面资源将异步加载

```ts
export const FeRoutes = [
  {
    "path": "/paid_column",
    "component": function dynamicComponent () {
      return import(/* webpackChunkName: "paid_column" */ '@/pages/paid_column/render.tsx')
    },
    "webpackChunkName": "paid_column",
    "fetch": () => import(/* webpackChunkName: "paid_column-fetch" */ '@/pages/paid_column/fetch.ts')
  }
] 
```

### routerOptimize

指定前端页面进行编译构建。在某些情况下我们只需要调试某个前端页面而不是所有页面，此时可以通过该配置来选择需要调试的页面进行构建来提升构建速度减小代码体积。但要注意，如果生产环境仍然是所有页面都需要发布，需要在生产环境禁用此配置，否则构建出来的代码只包含当前选中的页面。

- 类型：`routerOptimize?: { include?: string[] exclude?: string[] }`
- 默认：`undefined`

```ts
const userConfig: UserConfig = {
  prefix: '/mix/manuscript',
  routerOptimize: {
    // 注意，include 和 exclude 不能同时设置只能设置一项
    include: ['/paid_column'] // 例如：仅对 paid_column 页面进行打包
  }
}
```

### routerPriority

针对同一前端 path 可以对应多个路由时控制约定式路由优先级例如 /foo, 可以同时匹配 /:page /foo。用于约定式路由解析生成的数组排序。数字越大代表优先级越高。没有显示指定的路由优先级统一为 0

- 类型: `Record<string, number>`
- 默认: undefined

```js
const userConfig: UserConfig = {
  routerPriority: {
      '/:string': 1,
      '/foo': 2 // 优先级更高
    }
}
```

### https

是否开启底层 webpack-dev-server 的 https 模式，需配合 3000 端口的 Node.js 的 https 服务同步使用，证书需一致

- 类型: `boolean`
- 默认: `userConfig.https ? userConfig.https : !!process.env.HTTPS`

### extraJsOrder

需要额外初始化加载的 js chunk name，通常配合 splitChunks 配置一起使用, 若生成其他 name 的 chunk 开发者可通过 http://localhost:3000/asset-manifest.json 文件查看具体的 chunkName

- 类型: `string[]`
- 默认: `[]`

在默认的拆包配置下，需要加载如下模块作为页面启动入口

```ts
const jsOrder = [`runtime~${chunkName}.js`, 'vendor.js', `${chunkName}.js`, 'zhlibs.js'].concat(userConfig.extraJsOrder ?? [])
```

### extraCssOrder

需要额外初始化加载的 css chunk name，通常配合 splitChunks 配置一起使用

- 类型: `string[]`
- 默认: `[]`

在默认的拆包配置下，需要加载如下模块作为页面启动入口

```ts
const cssOrder = ['vendor.css', `${chunkName}.css`].concat(userConfig.extraCssOrder ?? [])
```

### whiteList

服务端构建 node_externals 白名单

- 类型: RegExp[]|string[]
- 默认: [/\.(css|less|sass|scss)$/]

处理 server 端构建模块时，我们默认会对所有的第三方模块使用 externals 模式，即不在构建时用 Webpack 处理，运行时直接从 node_modules 中加载具体模块，但对于一些只提供了 esm 格式的模块，或者是非 Node.js 环境能直接执行的文件，例如 jsx|less|sass|css 等类型的文件会发生运行错误，针对这种类型的特殊模块我们提供了白名单配置，设置服务端构建配置 externals 的白名单，即需要让 Webpack 来处理的模块

```ts
// https://www.npmjs.com/package/webpack-node-externals ，use additionalModuleDirs

chain.externals(nodeExternals({ allowlist: whiteList, additionalModuleDirs: modulesDir }))
```

### proxy

开发阶段启动的代理，底层使用 http-proxy-middleware 来进行代理，框架只是单纯透传参数， 具体配置查看 http-proxy-middleware 文档，开发阶段的 mock 代理可以基于此实现

- 类型: `object`
- 默认: `{}`

例如：

```ts
export default {
  proxy: {
    '/api': {
      target: 'http://www.example.org', 
      changeOrigin: true
    }
  }
}
```

当 `static` 配置为 `false` 时，启用服务端构建和服务，将使用服务中间件方案进行代理；如果 `static` 为 true，则不会启用服务，将使用 `webpack-dev-server` 进行代理 (方案对开发者透明，仅配置 proxy 即可)

## 只读配置

此类配置不建议修改，会影响整体框架的执行

### cwd

项目根目录，需要在根目录执行 mix cli 来启动、打包项目等

### chunkName

webpack 打包默认 chunkname，默认为 Page，不建议修改，修改需要同步修改 jsOrder 和 cssOrder 等

### cssOrder

服务端渲染时写入的 css

```ts
const cssOrder = ['vendor.css', `${chunkName}.css`].concat(userConfig.extraCssOrder ?? [])
```

### jsOrder

服务端渲染时写入的 js，需要根据 webpack 默认打包配置做调整

```ts
const jsOrder = [`runtime~${chunkName}.js`, 'vendor.js', `${chunkName}.js`, 'zhlibs.js'].concat(userConfig.extraJsOrder ?? [])
```

### getOutput

获取当前 app 的打包输出路径

```ts
() => {
  clientOutPut: string
  serverOutPut: string
  /** 临时文件，构建时需要 */
  preBuildOutPut: string
}
```

### manifestPath

开发模式下的 manifestPath

### proxyKey

dev 模式下需要代理的静态资源

```ts

const manifestPath = `${normalizeEndPath(devPublicPath)}asset-manifest.json`
const staticPath = `${normalizeEndPath(devPublicPath)}static`
const hotUpdatePath = `${normalizeEndPath(devPublicPath)}*.hot-update**`

const proxyKey = [staticPath, hotUpdatePath, manifestPath]
```
