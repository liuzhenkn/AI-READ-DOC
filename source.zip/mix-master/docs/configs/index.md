---
title: 项目配置
order: 1
toc: menu
nav:
  title: 配置项
  order: 2
---

每个项目必须在项目根目录创建名为 `project.confid.ts` 的项目配置文件

## 基础配置

### serverPort

Node.js 服务端渲染服务启动监听的端口, 也可以通过环境变量指定 SERVER_PORT=9000，默认为 3000，配置项优先级高于环境变量

### plugin <Badge>必配</Badge>

配置项目使用的客户端插件和服务端插件，目前客户端插件仅实现了 react，服务端插件实现了 koa 版本，配置如下：

```ts
import type { IProjectConfig } from '@zh-mix/types'
import { koaPlugin } from '@zh-mix/plugin-koa'
import { reactPlugin } from '@zh-mix/plugin-react'

const projectConfig: IProjectConfig = {
  plugin: {
    serverPlugin: koaPlugin(),
    clientPlugin: reactPlugin()
  }
}

export default projectConfig

```

插件类型定义如下：

```ts
export interface IPlugin {
  clientPlugin: {
    name: string
    dev?: (app: string, argv?: Argv) => void
    build?: (app: string, argv?: Argv) => void
  }
  serverPlugin: {
    name: string
    dev?: (app: string, argv?: Argv) => void
    build?: (app: string, argv?: Argv) => void
  }
}
```

### browserslist (package.json)

`babel` 和 `webpack` 构建会读取项目的`browserslist`配置进行相应的 polyfill 操作，可在 `package.json` 中进行配置，不配置情况下默认为：`browserslist default`

> defaults: Browserslist’s default browsers (> 0.5%, last 2 versions, Firefox ESR, not dead).

```json
"browserslist": [
  "Firefox > 60",
  "Chrome > 60",
  "IE 11",
  "safari 10",
  "edge 17"
]
```

## 中间件

> 项目级别的中间件配置会暴露服务的 koa app 对象，应用级别的中间件 -不暴露- koa app，仅提供应用配置。

### beforeRouterMiddleware

render router 前执行的中间件

例如实现静态服务托管的中间件，用于生产环境下直接服务静态文件，用于服务端渲染结果的静态资源加载 (一般推荐将静态资源托管至 `CDN`)

```ts
import type { IProjectConfig } from '@zh-mix/types'
import { koaPlugin } from '@zh-mix/plugin-koa'
import { reactPlugin } from '@zh-mix/plugin-react'
import koaStatic from 'koa-static'
import { resolve } from 'path'

const projectConfig: IProjectConfig = {
  beforeRouterMiddleware: (app) => {
    return koaStatic(resolve(__dirname, './../client/'), {})
  }
}

export default projectConfig

```

### afterRouterMiddleware

render router 后执行的中间件
