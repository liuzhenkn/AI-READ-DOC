---
toc: menu
order: 3
---

# 环境变量

## 可配

开发环境下的环境变量，可以通过根目录下的 `.env.local.development` 文件进行配置，例如

- `.env.local.development` 文件内容如下：

```text
APP=manuscript
CONTAINER_NAME=manuscript
DEV_HOST=arley.zhihu.com
```

### process.env.APP

构建时的 APP 名称，优先取 cli 命令传入的 app 参数，再取环境变量 APP 值

### process.env.GENERATE_ANALYSIS

当执行 [mix build / buildAll](/cli.html#mix-build) 时，可增加**analyzer** (简写 `-a`) 参数，判断是否进行打包产物分析，设置为 true 后，将注入环境变量：`process.env.GENERATE_ANALYSIS`，构建结束将自动打开产物分析。

也可以通过直接设置环境变量为 true 来开启该特性，建议使用 `mix build --analyzer` 启用

### process.env.CONTAINER_NAME

当前启动的服务容器名称，具体查看 [container](/configs/app.html#container)

项目启动时如果有配置 container (参数可通过 mix 脚手架传入) 或 process.env.CONTAINER_NAME，将启动 appConfig.container 相同和 未设置容器名的 app

### process.env.DEV_HOST

开发环境服务端的域名 HOST，默认为 `127.0.0.1`，在启动服务后自动输出页面路径。

### process.env.SERVER_PORT

Node.js 服务端渲染服务启动监听的端口, 也可以通过环境变量指定 SERVER_PORT=9000，默认为 3000，配置项优先级高于环境变量

### process.env.HTTPS

是否开启底层 webpack-dev-server 的 https 模式，需配合 3000 端口的 Node.js 的 https 服务同步使用，证书需一致。更多参考 [app https 配置](/configs/app.html#https)

## 只读

### process.env.NODE_ENV

当前的构建和运行环境，无需手动设置，取值 `development`(开发) | `production`(生产)

**构建时**，当执行 [mix dev](/cli.html#mix-dev) 时，自动注入值为：`development`，当执行 [mix build / buildAll](/cli.html#mix-build) 时，自动注入值为：`production`

**运行时**，当执行 mix dev 构建完成后，将启动 server 服务，自动注入值为：`development`，当执行 [mix start / prod](/cli.html#mix-prod) 启动服务时，自动注入值为：`production`
