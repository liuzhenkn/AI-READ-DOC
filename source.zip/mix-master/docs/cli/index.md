---
title: 命令行工具
order: 1
toc: menu
nav:
  title: 脚手架
  order: 3
---

## mix dev

启动本地开发服务器进行项目的开发调试，将自动注入环境变量 `process.env.NODE_ENV = 'development'`

- 命令别名：`mix watch`

```shell
$ mix dev
```

启动在浏览器中运行的开发服务器，并监视源文件变化，自动热加载。

默认使用 `3000` 端口作为服务端口，可以通过项目配置中的 `serverPort` 来修改端口号，也可以通过环境变量 `SERVER_PORT` 进行设置

### 参数

- **app** (**必须**配置，也可通过环境变量 `APP` 设置): 所需要启动服务的 APP 名称，命令行参数优先于环境变量
- **debug** (简写 `-d`): 「开发模式」 下是否开启 `server` 的 inspect 进行附加断点调试
- **container**: 当前的容器名称，如果有值将赋值给 CONTAINER_NAME 环境变量，服务启动时将仅启动相关的 apps，在 dev 和 prod 环境均生效 (开发环境一般不需要配置)

### 例子

```shell
$ mix dev --debug --app=manuscript --container=default

  脚手架 (开发模式) 删除历史构建 /Users/arley_guolei/pkg/mix/example/react-koa/build/* +0ms
  脚手架 (开发模式) 🍨 启动 manuscript 的构建服务 +0ms
  脚手架 (开发模式) 🍨 加载客户端插件 plugin-react，服务端插件 plugin-koa +397ms
  客户端构建 🍨 该 app 只有一个页面，将移除 react-router 依赖，如果需要强制引入可以配置 useReactRouter 选项 +0ms

✔ 服务端构建


✔ 客户端构建
  Compiled successfully in 5.92s

  静态服务 「启动成功」 资源列表可以打开: http://10.13.104.146:8888/webpack-dev-server 查看 +0ms
asset Page.server.js 119 KiB [emitted] (name: Page) 1 related asset
webpack 5.66.0 compiled successfully in 4066 ms
assets by path static/ 1.64 MiB
  assets by chunk 20.4 KiB (name: paid_column)
    asset static/js/paid_column.chunk.js 11.4 KiB [emitted] (name: paid_column) 1 related asset
    asset static/css/paid_column.chunk.css 9.08 KiB [emitted] (name: paid_column) 1 related asset
  asset static/js/vendor.js 1.5 MiB [emitted] (name: vendor) (id hint: vendors) 1 related asset
  asset static/js/runtime~Page.js 50.4 KiB [emitted] (name: runtime~Page) 1 related asset
  asset static/js/Page.js 40.2 KiB [emitted] (name: Page) 1 related asset
  asset static/js/paid_column-fetch.chunk.js 31.6 KiB [emitted] (name: paid_column-fetch) 1 related asset
asset asset-manifest.json 709 bytes [emitted]
asset index.html 249 bytes [emitted]
webpack 5.66.0 compiled successfully in 5925 ms
  服务 (开发环境) 当前启动的容器名称为 default +0ms
  服务 (开发环境) 🍨 「启动成功」，服务地址：http://arley.zhihu.com:7000 +27ms
  服务 (开发环境) 🍨 开启了 debug 参数，可通过 node 附加进行断点调试 +1ms


  manuscript 🔗 页面 URL：http://arley.zhihu.com:7000/mix/manuscript/paid_column +0ms


Debugger listening on ws://127.0.0.1:9231/789f8abb-6cdc-4c7c-99f7-d4f51aa4d4e1
For help, see: https://nodejs.org/en/docs/inspector
```

开启开发服务还会同时提供对应 app 所启动页面的链接，你可以在能访问到你当前运行设备的其他设备中预览页面。

## mix build

构建指定 app 的服务端 和 客户端代码，将自动注入环境变量 `process.env.NODE_ENV = 'production'`

```shell
$ mix build
```

### 参数

- **app** (**必须**配置，也可通过环境变量 `APP` 设置): 所需要构建的 APP 名称，命令行参数优先于环境变量
- **analyzer** (简写 `-a`): 是否进行打包产物分析，设置为 true 后，构建结束将自动打开产物分析。为 true 时将注入环境变量：`process.env.GENERATE_ANALYSIS`，所以也可以通过直接设置环境变量来开启该特性
- **clean**: 进行构建前是否删除以前的产物，默认为 `true` 进行删除

### 例子

```shell
$ mix build --app manuscript -a

  客户端构建 🍨 该 app 只有一个页面，将移除 react-router 依赖，如果需要强制引入可以配置 useReactRouter 选项 +0ms

✔ 服务端构建

✔ 客户端构建
  Compiled successfully in 7.23s

asset Page.server.js 39.2 KiB [emitted] [minimized] (name: Page) 1 related asset
webpack 5.66.0 compiled successfully in 3721 ms
assets by path static/ 239 KiB
  assets by chunk 5.11 KiB (name: paid_column)
    asset static/css/paid_column.b3c91afd.chunk.css 3.55 KiB [emitted] [immutable] [minimized] (name: paid_column) 1 related asset
    asset static/js/paid_column.b7f51f37.chunk.js 1.56 KiB [emitted] [immutable] [minimized] (name: paid_column) 1 related asset
  asset static/js/vendor.5e6d4c80.js 195 KiB [emitted] [immutable] [minimized] (name: vendor) (id hint: vendors) 2 related assets
  asset static/js/paid_column-fetch.d2ae9f71.chunk.js 28.7 KiB [emitted] [immutable] [minimized] (name: paid_column-fetch) 1 related asset
  asset static/js/Page.2d247e84.js 5.56 KiB [emitted] [immutable] [minimized] (name: Page) 1 related asset
  asset static/js/runtime~Page.b5bfb799.js 4.75 KiB [emitted] [immutable] [minimized] (name: runtime~Page) 1 related asset
asset asset-manifest.json 1010 bytes [compared for emit]
asset index.html 297 bytes [emitted]
webpack 5.66.0 compiled successfully in 6810 ms
```

- 客户端代码分析：`http://127.0.0.1:8901/`

![客户端代码分析](https://pica.zhimg.com/v2-fb05b1e63507347160d9c8e89d7e4455.png)

- 服务端代码分析：`http://127.0.0.1:8900/`

![服务端代码分析](https://pic3.zhimg.com/v2-0efc66e7c1c29ad1a6aa63f41dc68997.png)

## mix buildAll

构建所有 app 的服务端和客户端代码，可通过 apps 参数指定需要构建的 app，内部基于 `concurrently` 实现多进程并行构建

### 参数

- **apps**: buildAll 所需要编译的 app 名称，不传入将默认构建所有 app

### 例子

```shell
$ mix buildAll --apps 1-yuan-purchase manuscript

  buildAll 🍨 构建项目配置 +0ms
  buildAll 需要编译的 APP 有 1-yuan-purchase manuscript (总共 2 个) +56ms
  buildAll cpu 内核为 8，最大可启用 4 个编译进程 +0ms
[14:20:39 pid: 96071] manuscript =>  2022-01-30T06:20:39.102Z 客户端构建 🍨 该 app 只有一个页面，将移除 react-router 依赖，如果需要强制引入可以配置 useReactRouter 选项
[14:20:39 pid: 96070] 1-yuan-purchase =>  2022-01-30T06:20:39.102Z 客户端构建 🍨 该 app 只有一个页面，将移除 react-router 依赖，如果需要强制引入可以配置 useReactRouter 选项
[14:20:39 pid: 96071] manuscript =>  ℹ Compiling 客户端构建
[14:20:39 pid: 96070] 1-yuan-purchase =>  ℹ Compiling 客户端构建
[14:20:39 pid: 96071] manuscript =>  ℹ Compiling 服务端构建
[14:20:39 pid: 96070] 1-yuan-purchase =>  ℹ Compiling 服务端构建
[14:20:43 pid: 96070] 1-yuan-purchase =>  ✔ 服务端构建: Compiled successfully in 3.55s
[14:20:43 pid: 96070] 1-yuan-purchase =>  asset Page.server.js 17.3 KiB [emitted] [minimized] (name: Page) 1 related asset
[14:20:43 pid: 96070] 1-yuan-purchase =>  webpack 5.66.0 compiled successfully in 3548 ms
[14:20:43 pid: 96071] manuscript =>  ✔ 服务端构建: Compiled successfully in 3.68s
[14:20:43 pid: 96071] manuscript =>  asset Page.server.js 39.2 KiB [compared for emit] [minimized] (name: Page) 1 related asset
[14:20:43 pid: 96071] manuscript =>  webpack 5.66.0 compiled successfully in 3681 ms
[14:20:45 pid: 96070] 1-yuan-purchase =>  ✔ 客户端构建: Compiled successfully in 5.75s
[14:20:45 pid: 96070] 1-yuan-purchase =>  assets by path static/ 207 KiB
[14:20:45 pid: 96070] 1-yuan-purchase =>    assets by chunk 2.19 KiB (name: home)
[14:20:45 pid: 96070] 1-yuan-purchase =>      asset static/css/home.770dd183.chunk.css 1.86 KiB [emitted] [immutable] [minimized] (name: home) 1 related asset
[14:20:45 pid: 96070] 1-yuan-purchase =>      asset static/js/home.75bc8c38.chunk.js 337 bytes [emitted] [immutable] [minimized] (name: home) 1 related asset
[14:20:45 pid: 96070] 1-yuan-purchase =>    asset static/js/vendor.b4026fff.js 194 KiB [emitted] [immutable] [minimized] (name: vendor) (id hint: vendors) 2 related assets
[14:20:45 pid: 96070] 1-yuan-purchase =>    asset static/js/Page.c098665e.js 5.52 KiB [emitted] [immutable] [minimized] (name: Page) 1 related asset
[14:20:45 pid: 96070] 1-yuan-purchase =>    asset static/js/runtime~Page.cd9f566e.js 4.73 KiB [emitted] [immutable] [minimized] (name: runtime~Page) 1 related asset
[14:20:45 pid: 96070] 1-yuan-purchase =>    asset static/js/home-fetch.b0a1d517.chunk.js 503 bytes [emitted] [immutable] [minimized] (name: home-fetch) 1 related asset
[14:20:45 pid: 96070] 1-yuan-purchase =>  asset asset-manifest.json 995 bytes [compared for emit]
[14:20:45 pid: 96070] 1-yuan-purchase =>  asset index.html 312 bytes [emitted]
[14:20:45 pid: 96070] 1-yuan-purchase =>  webpack 5.66.0 compiled successfully in 5755 ms
[14:20:45 pid: 96070] 1-yuan-purchase =>  mix build --app 1-yuan-purchase exited with code 0
[14:20:45 pid: 96071] manuscript =>  ✔ 客户端构建: Compiled successfully in 5.82s
[14:20:45 pid: 96071] manuscript =>  assets by status 239 KiB [cached]
[14:20:45 pid: 96071] manuscript =>    assets by chunk 5.11 KiB (name: paid_column)
[14:20:45 pid: 96071] manuscript =>      asset static/css/paid_column.b3c91afd.chunk.css 3.55 KiB [cached] [immutable] [minimized] (name: paid_column) 1 related asset
[14:20:45 pid: 96071] manuscript =>      asset static/js/paid_column.b7f51f37.chunk.js 1.56 KiB [cached] [immutable] [minimized] (name: paid_column) 1 related asset
[14:20:45 pid: 96071] manuscript =>    asset static/js/vendor.5e6d4c80.js 195 KiB [cached] [immutable] [minimized] (name: vendor) (id hint: vendors) 2 related assets
[14:20:45 pid: 96071] manuscript =>    asset static/js/paid_column-fetch.d2ae9f71.chunk.js 28.7 KiB [cached] [immutable] [minimized] (name: paid_column-fetch) 1 related asset
[14:20:45 pid: 96071] manuscript =>    asset static/js/Page.2d247e84.js 5.56 KiB [cached] [immutable] [minimized] (name: Page) 1 related asset
[14:20:45 pid: 96071] manuscript =>    asset static/js/runtime~Page.b5bfb799.js 4.75 KiB [cached] [immutable] [minimized] (name: runtime~Page) 1 related asset
[14:20:45 pid: 96071] manuscript =>  assets by status 1.28 KiB [compared for emit]
[14:20:45 pid: 96071] manuscript =>    asset asset-manifest.json 1010 bytes [compared for emit]
[14:20:45 pid: 96071] manuscript =>    asset index.html 297 bytes [compared for emit]
[14:20:45 pid: 96071] manuscript =>  webpack 5.66.0 compiled successfully in 5823 ms
[14:20:45 pid: 96071] manuscript =>  mix build --app manuscript exited with code 0
  buildAll 构建成功，耗时 9208 ms +9s
```

## mix prod

启动生产环境服务端渲染服务，基于 [cfork](https://github.com/node-modules/cfork) 实现启动进程，并维持多个进程的保活，类似 pm2

如果使用 docker 进行服务部署，容器为单核 CPU 时，可以通过`cluster`参数禁用多进程启动服务

- 命令别名：`mix start`

```shell
$ mix prod
```

### 参数

- **container**: 当前的容器名称，如果有值将赋值给 CONTAINER_NAME 环境变量，服务启动时将仅启动相关的 apps，在 dev 和 prod 环境均生效
- **cluster**: 默认为`false`，设置为`true`时，启用多进程模型启动服务，例如：`mix prod --cluster=true`

容器类服务不需要启用 `cluster` 模式，容器本身有扩容和进程守护能力，当启用 `cluster` 后将根据 cpu 内核数启用进程数目。注意：容器启用的 cpu 核数取的是物理机 cpu 内核数，不是当前容器内核。

### 例子

```shell
$ mix prod --cluster=true

  Server CLI 服务入口为 /Users/arley_guolei/pkg/mix/example/react-koa/node_modules/@zh-mix/core-koa/cjs/server.js, 将启用 8 个进程 +0ms
  Server CLI Sun Jan 30 2022 14:23:57 GMT+0800 (中国标准时间) 启动服务进程 [96413] +32ms
  Server CLI Sun Jan 30 2022 14:23:57 GMT+0800 (中国标准时间) 启动服务进程 [96414] +0ms
  Server CLI Sun Jan 30 2022 14:23:57 GMT+0800 (中国标准时间) 启动服务进程 [96415] +0ms
  Server CLI Sun Jan 30 2022 14:23:57 GMT+0800 (中国标准时间) 启动服务进程 [96416] +0ms
  Server CLI Sun Jan 30 2022 14:23:57 GMT+0800 (中国标准时间) 启动服务进程 [96417] +0ms
  Server CLI Sun Jan 30 2022 14:23:57 GMT+0800 (中国标准时间) 启动服务进程 [96418] +0ms
  Server CLI Sun Jan 30 2022 14:23:57 GMT+0800 (中国标准时间) 启动服务进程 [96419] +0ms
  Server CLI Sun Jan 30 2022 14:23:57 GMT+0800 (中国标准时间) 启动服务进程 [96420] +0ms
```

## mix list

根据目录结构打印 app 列表

```shell
$ mix list

  脚手架 (获取 APP 列表) [1] - 1-yuan-purchase +0ms
  脚手架 (获取 APP 列表) [2] - manuscript +1ms
  脚手架 (获取 APP 列表) 共 2 个 app +0ms
```

## mix clean

删除指定 app 的构建产物

## mix new

mix 根据 app 模版创建项目

### 参数

- **app** (**必须**配置): 所需要创建的 app 名称,不能使用驼峰命名，可用中划线 例如：hello-world
- **template** (**必须**配置):  在 example/react-koa/app-templates 多模版文件下查看所使用的模版文件

```shell
$ mix new --app=manuscript --template=baseFirst
```
**注：运行脚本的目录在业务项目的根目录文件夹下运行**

用户在自己创建 app 模版的时候可自定义配置项，目前有 name （文件夹名）配置，例如：`prefix: '/mix/<%- name %>',` 按照 name 配置完成以后即可定制化使用


