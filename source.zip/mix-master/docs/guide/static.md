---
group:
  title: 基础使用
  order: 2
  path: /basic
order: 6
---

## 纯静态化

`MIX` 定位为**多 app 服务端渲染框架**，同时提供了伪 CSR 的降级模式，当服务端渲染异常将自动降级至伪 CSR，可以通过配置 `mode: csr` 或 请求链接中增加 `csr=true` 参数实现。

之所以称为伪 CSR 是因为页面实际上也是由服务端返回的，仅仅是跳过了「服务端接口请求」和「具体页面渲染」。

但对于需要做**离线包**、**后台**、**活动静态页**等，如果使用「服务端渲染」或「伪CSR」，那有点大材小用。

为了满足上述场景，MIX 同时也支持了纯静态化方案，即 SPA 应用。将不再启用任何 node 服务，可直接将 html 和 静态资源单独部署。

### 相关配置

#### static

一个项目可以包含多个 APP，每个 app 的渲染模式可单独配置。当设置了 app 的 static 配置为 `true`时，开发和正式构建时，将不进行服务端代码构建。

详细可参考：[/configs/app.html#static](/configs/app.html#static)

#### html

当 html 配置项 template 路径存在时，将开启纯静态方案构建，配置可参考：[/configs/app.html#html](/configs/app.html#html)

默认路径为`${app}/components/layout/index.html`，即当路径文件存在时，将开启构建。

该配置实际上为透传[html-webpack-plugin Options](https://www.npmjs.com/package/html-webpack-plugin)配置项。

#### 模板案例

模板即上述提到的`${app}/components/layout/index.html`案例

模板中可以通过`window.prefix`指定当前页面的prefix路径，实际为 `react-router` 的 basename 配置。为了一个页面同时支持服务端渲染的同时，支持 spa 纯静态化

```html
<!DOCTYPE html>

<html lang="zh-CN">

<head>
  <meta charSet="utf-8" />
  <meta name="description" content="Web site created using mix" />
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, viewport-fit=cover" />
  <link rel="dns-prefetch" href="//static.zhihu.com" />
  <link rel="dns-prefetch" href="//pic4.zhimg.com" />
  <link rel="dns-prefetch" href="//pic1.zhimg.com" />
  <link rel="dns-prefetch" href="//pic2.zhimg.com" />
  <link rel="dns-prefetch" href="//pic3.zhimg.com" />
  <link rel="shortcut icon" type="image/x-icon" href="https://static.zhihu.com/heifetz/favicon.ico" />
  <title>mix-basic</title>
</head>

<body>
  <noscript>You need to enable JavaScript to run this app.</noscript>
  <div id="app">
  </div>

  <script>
    window.prefix = "/mix/spa/basic";
  </script>
</body>

</html>
```

### 请求代理

在本地开发过程中，可以通过 proxy 实现请求服务端携带 cookie 或者 mock 地址转发等

当 `static` 配置为 `false` 时，启用服务端构建和服务，将使用服务中间件方案进行代理；如果 `static` 为 true，则不会启用服务，将使用 `webpack-dev-server` 进行代理 (方案对开发者透明，仅配置 app 配置的 proxy 即可)

### 知乎场景部署

静态文件使用 `joker.yml`进行配置将自动部署产物至 CDN，HTML 文件房间可直接在 nginx 平台配置即可。

```yaml
artifacts:
  targets:
    - static
  static:
    path: build/client
  storages:
    - oss
```
