---
group:
  title: 基础使用
  order: 2
  path: /basic
order: 3
---

## 约定式路由

约定式路由即根据前端文件夹结构来自动的生成前端路由配置。

本框架同时支持约定式路由和声明式路由，当检测到 `app/_route.ts` 文件存在时会使用该文件来作为前端路由结构。但我们默认不支持你这么做，因为框架会根据你当前的不同配置来生成不同的路由结构。如果手动编写工作量过大且容易出错。在没有特殊需求的情况下建议直接使用约定式路由。

<Alert type="info">
  注意，app 指 apps 中的任意目录，比如：manuscript 可称为一个 app
</Alert>

### 路由规则

下面来介绍我们详细的路由映射规则, 以下为一个基础的 `app` 文件夹的结构，我们主要关注 `app/pages` 文件夹，根据该文件夹来 `parse` 前端路由结构

```shell
$ tree ./ -I node_modules -L 3
├── pages
│   ├── detail
│   │   ├── fetch.ts
│   │   └── render$id.tsx
│   └── index
│       ├── fetch.ts
│       └── render.tsx
```

### 页面组件

`pages` 文件夹下的每个文件夹，我们都会认为它是一个页面。上述结构包含 `index`, `detail` 两个页面。

同样我们定义 `render` 文件代表一个页面的渲染组件。`render` 文件支持多种格式来应对不同类型的前端路由

### 普通路由

最常见的普通路由即 `/`, `/detail`, `/user` 这种我们只需要创建同名文件夹即可。这里我们特殊针对根路由，来将 `index` 文件夹进行映射

- `/index/render.tsx` 映射为 `/`
- `/detail/render.tsx` 映射为 `/detail`
- `/user/render.tsx` 映射为 `/user`

### 动态路由

动态路由即携带参数的路由，例如 `/user/:id` 这种

- `/user/render$id.tsx` 映射为 `/user/:id`
- `/user/render$foo$bar.tsx` 多参数的情况下映射为 `/user/:foo/:bar`

### 可选参数路由

由于 `?` 符号无法作为文件名使用，所以这里我们需要用 `#` 号代替

- `/index/render$id#.tsx` 映射为 `/:id?`

### 路由参数获取

- `/user/render$id$name#.tsx` 映射为 `/user/:id/:name?`，当请求是链接为：`/user/123/arley?ab=test` 时
  - react 场景下：在 fetch 中可通过 `routerProps` 获取到路由参数 `{ params: { id: '123', name: 'arley', ab: 'test' } }`；在 pages 下的页面组件中的 `props` 可获取 `params` 参数，同 `{ params: { id: '123', name: 'arley', ab: 'test' } }`

其中 params 动态路由参数 和 GET query 参数，同名的 query 参数会覆盖动态路由参数参数

### 多级路由

尽管在大多数情况下我们用不到多级路由，但这里我们仍然提供了对应的解析策略。如果你的应用所有路由 `path` 前面都需要加上一个统一的前缀，那么你应该通过 app 层级的 `config.prefix` 来实现，而不是多级路由。参考[应用配置](/configs/app.html#prefix)

- `/user/detail/render$id` 映射为 `/user/detail/:id`
- `/user/detail/render$foo$bar` 映射为 `/user/detail/:foo/:bar`

### 输出 parse 结构

在本地开发时可以通过框架内置的 `DEBUG` 模块的能力打印出 `parse` 后的前端路由结构 (本地开发启动服务可见)

也可以直接查看 `/build/preBuild/${app}/mix-temporary-routes.js` 文件

## 手动编写路由结构

### React 场景

在 React 场景我们按照如下规范编写前端路由结构

```js
import React from "react"
export const FeRoutes = [
{
  "fetch": () => import(/* webpackChunkName: "detail-id-fetch" */ '@/pages/detail/fetch.ts'),
  "path": "/detail/:id",
  "component":  function dynamicComponent () {
    return import(/* webpackChunkName: "detail-id" */ '@/pages/detail/render$id.tsx')
   }, 
   "webpackChunkName": "detail-id"
}, 
{
  "fetch": () => import(/* webpackChunkName: "index-fetch" */ '@/pages/index/fetch.ts')
  "path": "/",
  "component": function dynamicComponent () {
    return import(/* webpackChunkName: "index" */ '@/pages/index/render.tsx')
   }, 
   "webpackChunkName": "index"
}]

export { default as App } from "@/components/layout/App.tsx"
export { default as layoutFetch } from "@/components/layout/fetch.ts"
export * from "@/store/index.ts"
export const PrefixRouterBase = '/user'

// 当 app 只有一个页面时，会增加以下标识，不引入 react-router
//#not-import-react-router-dom
```

- `//#not-import-react-router-dom` 标识该 app 只有一个页面，打包时不引入 react-router
