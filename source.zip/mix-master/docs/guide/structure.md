---
group:
  title: 基础使用
  order: 2
  path: /basic
order: 2
---

## 目录结构

### React 示例

<embed src="./../tree.md"></embed>

### 其他指引

- 关于约定式路由/自定义路由/路由映射，请阅读 [约定式路由](/guide/basic/fe-routes.html) 章节
- 关于 `fetch.ts` 文件更加详细内容，请阅读 [数据获取](/guide/basic/fetch.html) 章节
- 关于 `store` 和组件通信，请阅读 [组件通信](/guide/basic/communication.html) 章节
- 关于 `project.config.ts` 项目级别配置，请阅读 [项目配置](/configs.html) 章节
- 关于 `config.ts` 应用级别配置，请阅读 [APP 配置](/configs/app.html) 章节
