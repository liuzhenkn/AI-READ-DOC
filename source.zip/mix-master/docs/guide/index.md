---
title: 介绍
order: 1
toc: menu
nav:
  title: 指南
  order: 1
---

## 什么是 mix？

mix 框架是为前端框架在**单服务多 APP 服务端渲染**的场景下所打造的开箱即用的服务端渲染框架。此框架脱胎于 [ssr](https://github.com/zhangyuang/ssr)，在其基础上做了诸多演进，例如全面使用 webpack 5、支持多 APP 架构、服务一体化、支持服务中间件、智能引入`react-router`、服务端渲染数据查看等。通过插件化的代码组织形式，支持任意服务端框架与任意前端框架的组合使用。

### 项目背景和目标分析

不管是 [xen](https://git.in.zhihu.com/fe/xen)、[heifetz](https://git.in.zhihu.com/cfe/heifetz)、[amadeus](https://git.in.zhihu.com/cfe/amadeus) 、[raccoon](https://git.in.zhihu.com/efe/raccoon) 等等`N个`知乎内的服务端渲染项目都属于**单服务多 APP** 的服务架构，目前想要拆分 xen 项目，将会面临同一套架构重复使用且需要重复造轮问题，这样存在并维护多个架构技术栈，我们发现了一些**痛点，包括但不限于：**

- 多个项目架构技术栈不统一，在修改其他服务端渲染项目时，存在更多的架构盲区需要了解和学习，上手成本高
- 要引入某一特性时，需要在不同的项目中单独以不同方式进行接入，难以复用，例如：增量构建、Sentry 接入等，存在重复造轮子现象
- 目前的架构技术栈老旧，xen 中采用了 double rendering 的方式进行服务端渲染，React 升级 18 之后，一次渲染的 [Suspense](https://reactjs.org/docs/concurrent-mode-suspense.html) 将是react 项目服务端渲染的数据获取方案首选
  - double rendering：第一次渲染时我们可以拿到当前的组件具有哪些子组件并且可以拿到子组件上定义的静态方法，进行收集并调用。在第二次渲染的时候将收集的数据与组件结合变成完整的字符串。当然这样的缺陷就是渲染两次会对性能造成一定影响
  - 所有 APP 共用一个 HTML 渲染模板文件，会因为一个 app 对 html 的需求变更在其他 APP 中引入冗余代码
  - 不支持 TypeScript 等

为了解决上述问题，可以考虑使用统一的一个服务端渲染框架，社区中也出现了不少的 react 技术栈相关的服务端渲染项目，比如但不限于：

- [Next.js](https://nextjs.org/) 18w 行代码实现的、最新的、社区庞大的、适用场景多的 react 服务端渲染框架
- 蚂蚁的 [umi](https://umijs.org/zh-CN/docs)，和next几乎一样，只是配置简单，umi 很多功能是参考 Next.js 做的
- [ssr](https://github.com/zhangyuang/ssr)，轻量 2000 + 行代码，插件化支持多前端框架
- [Modern.js](https://github.com/modern-js-dev/modern.js)，字节跳动的「航空母舰」

这些框架在不同程度上封装了 react，并给出了各自风格的使用和上层方案，但都也不完全是一个开箱即用、满足知乎内场景的服务端渲染框架，难以直接融入已有知乎风格的项目，不支持单服务多 APP 架构，知乎不支持 Faas 基础设施等。当然，这些框架也有各自设计上的优缺点，暂不展开。

我们需要统筹调研，产出一套服务端渲染的开发框架，**目的是在保障易用性、稳定性的基础上，提升 SSR 项目开发的效率及服务性能，实现技术积累，技术资产共建**。

## 特性

- 前端框架: 目前支持 React v17 版本，可拓展插件支持 vue 等其他框架
- 后端服务: 目前以插件化实现 koa 服务，支持多进程 cluster 启动，可以直接通过插件配置的形式替换后端服务为任意服务框架，轻松迁移[Polaris](https://git.in.zhihu.com/fe/polaris)
- 开发语言: TypeScript
- 样式处理: less + css modules(根据后缀名自动识别 .module.less 文件使用 css-modules)
- 前端路由: 约定式路由/声明式路由
- 数据管理: react 使用 Hooks 提供的 useContext 实现极简的跨组件通信方案, 摒弃传统的 redux/dva 等数据管理方案
- 构建工具: Webpack 5
- 高可用场景，可无缝从SSR降级到CSR，最佳容灾方案
