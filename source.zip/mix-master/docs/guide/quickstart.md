---
title: 快速开始
toc: menu
order: 1
---

## Mix Generator 脚手架

### 项目初始化

npm 源需要切换为知乎内网源：`http://npm.in.zhihu.com/`，推荐使用 [nrm](https://www.npmjs.com/package/nrm) 来管理 npm 源

```bash
npm init yo @zh-mix/mix
```

![执行示例](https://picx.zhimg.com/v2-4bdb5a14b7c6f1229a09f26ed0aef58c.png)

![执行结果](https://pica.zhimg.com/v2-9e7448002082f5eec2eff35b766c5eaa.png)

如果初始化时 npx 报错 `libnpx xxx`，可以执行 `npm install libnpx -g` 安装一下 libnpx (报错原因和 node 版本管理器 n、nvm 等有关系)

![libnpx 错误截图](https://pica.zhimg.com/v2-56af9b45212a99a8153cad6d8cf3d03d.png)

如果初始化后的模板提交代码时 husky 钩子没有生效执行 eslint，可执行一下命令

```bash
chmod +x .husky/commit-msg
chmod +x .husky/pre-commit
```

### 脚手架源码 & 模板贡献

- 代码库：[https://git.in.zhihu.com/kfe/mix-example](https://git.in.zhihu.com/kfe/mix-example)
- npm：[https://npm.in.zhihu.com/-/web/detail/@zh-mix/generator-mix](https://npm.in.zhihu.com/-/web/detail/@zh-mix/generator-mix)

### Mix 快速上手

#### 底层框架 Mix 及生态

项目底层基于 [Mix](http://mix.zhdocs.io/) 实现，为多 APP 场景而生的服务端渲染框架。

- Mix 文档 (上手、配置、命令行指引等)：[http://mix.zhdocs.io/](http://mix.zhdocs.io/)
- Mix-Market (服务端渲染生态、组件库、异常处理、请求)：[http://mix-market.zhdocs.io/](http://mix-market.zhdocs.io/)

![Mix 生态关系图例](https://picx1.zhimg.com/v2-d62fc52b4dc2409fd2b27d745a03efe2.png)

![Mix 架构参考](https://picx1.zhimg.com/v2-c085271ab4859a094b099572d5e35bb9.png)

↓ 此图和当前项目中可能存在差异，大体框架如下
![业务项目架构示例](https://pic1.zhimg.com/v2-60ec129a5d824491b5228a9195f661a1.png)

更多参考：

- Mix 架构参考：[https://wiki.in.zhihu.com/pages/viewpage.action?pageId=379589314](https://wiki.in.zhihu.com/pages/viewpage.action?pageId=379589314)
- Mix 搭建的业务项目架构参考：[https://wiki.in.zhihu.com/pages/viewpage.action?pageId=386737939](https://wiki.in.zhihu.com/pages/viewpage.action?pageId=386737939)

Mix 本身和知乎业务无耦合，Mix-Market 中集成了大部分生态能力支持，业务耦合还是在对应的项目中，推荐大概看下 Mix 框架是什么后，详细看下当前项目的代码库整体文件和架构，快速上手

> 如果文档打不开 (办公室网络偶现文档域名 DNS 劫持失败)，可以在hosts文件中增加以下配置：

```shell
10.101.1.199 mix.zhdocs.io
10.101.1.199 mix-market.zhdocs.io
```

#### 开发

```bash
# 首次下载项目后需要执行复制一份环境变量模板，用于存储环境变量
# APP=basic => .env.local.development 文件中可修改成对应需要启动的 APP
cp .env.local.development.template .env.local.development

pnpm install
pnpm run dev
```

提示：目前在 `.env.local.development` 中的 `DEV_HOST` 默认为 `local.zhihu.com`，需要在 hosts 中强制将 `local.zhihu.com` 指向 `127.0.0.1`
