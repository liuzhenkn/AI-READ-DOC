---
group:
  title: 基础使用
  order: 2
  path: /basic
order: 4
---

## 数据获取

数据获取是服务端渲染应用中非常重要的一个环节。通过本章节的内容，读者可以了解服务端渲染应用的一些深层次的知识

### 静态方法获取数据

`mix` 框架提出定义 `fetch.ts` 文件用于获取数据，本质上 `Next.js` 提出的 `getInitialProps` 意义一致，都属于一个静态方法。

关于什么是 `static method`, 即不需要将类实例化便可以拿到的方法。例如下面的代码

```js
class Foo {}

Foo.bar = () => {}
```

此时的 `bar` 函数即为 `static method`, 我们可以直接通过 `Foo.bar()` 来调用它，而不需要 `new Foo()`。这里大部分用户可能会有疑惑，为什么要使用一个静态方法来进行数据的获取，而不是像传统 SPA 应用一样直接写在组件的生命周期当中呢。

对服务端渲染有一定了解的同学会知道，在服务端会执行的生命周期只有 `created/componentWillMount`，而像 `mounted/componentDidMount` 这样的生命周期是不会被执行的。那么我们将获取数据的逻辑写在 `created` 当中是否可行呢。答案也是否定的

由于我们获取数据的逻辑一般都是异步的。在服务端渲染的过程中，并不会像客户端应用那样，当 `props/state` 改变时组件重新 `render`。举个例子，下面的代码是无法拿到正确的渲染结果的

```js
class Foo extends React.component {
    construtor (props) {
        super(props)
        this.state = {
            value: 'foo'
        }
    }
    async componentWillMount() {
        const newValue = await Promise.resolve('bar')
        this.setState({
            value: newValue
        })
    }
    render() {
        return (
            <div>{this.state.value}</div>
        )
    }
}
```

上述代码我们期望的渲染结果是 `value=bar` 但是实际的结果却并不是这样。有兴趣的同学可以实际运行一下上述代码来观察一下具体的现象。同理在 `Vue` 当中我们也不能够拿到正确的数据。所以我们需要定义一个静态方法来获取数据

## fetch.ts 规范

我们在静态方法的基础上抽象出 `fetch.ts` 文件规范来作为获取数据的入口文件。因为对一些大团队来说，我们在服务端通常可以采用 `rpc` 类型的调用，或是直接调用 `Node Service` 的代码来获取数据，无需通过 `http` 请求，所以在 `fetch.ts` 中，我们可能会编写服务端相关代码，故独立出一个文件来进行维护。

`fetch.ts` 的定义是页面级别的组件进行数据获取的入口文件，不包括子组件。由于在服务端一个组件被真正的 `render` 之前，我们并不知道它依赖哪些子组件。所以我们没有办法调用子组件的 `fetch`, 当然也有其他方式可以解决这个问题。见本文最后的补充内容。

`fetch.ts` 的文件类型分为两种

### Layout fetch

`Layout` 级别的 `fetch` (可选)，定义在 `${app}/components/layout/fetch.ts` 路径

意义: `Layout` 级别的 `fetch` 用于初始化一些所有页面都会用到的一些公共数据，若该文件存在则调用。将会把返回的数据与页面级别的 `fetch` 合并返回给开发者。`Layout` 场景只允许存在一个 `fetch` 文件

### 页面级 fetch

页面级别的 `fetch` (可选, 可以存在多个)，定义在 `${app}/pages/xxx/fetch.ts` 路径

意义: 页面级别的 `fetch` 将会在当前访问该前端页面组件对应的 `path` 时被调用

### fetch 与 render 对应关系

`fetch` 文件与 `render` 对应关系如下

- 当只有一个 `fetch` 文件时，当前文件夹所有的 `render` 文件都对应这个 `fetch` 文件
- `fetch` 文件存在多个时，`render` 文件与 `fetch` 文件名一一对应，例如 `render.tsx` => `fetch.ts`, `render$id.tsx` => `fetch$id.ts`

## fetch 调用时机

这里我们将其分为`服务端渲染模式`和`客户端渲染模式`两种情况

### 服务端渲染模式

将会在服务端渲染执行的过程中被调用。在客户端激活的过程中会复用服务端获取并注入到 `window` 中的数据来进行初始化。不会在客户端再次获取。当客户端进行前端路由切换时会调用将要前往的页面对应的 `fetch`。下图中的 `fetch` 代表 `layout fetch` + `page fetch`。有则调用。

![服务端请求](https://pic2.zhimg.com/v2-acb5a0fde0afc42070c2a47a587e7b5c.png)

### 客户端渲染模式

此时服务端不会进行任何的数据获取操作, 仅渲染一个空的 `html` 骨架，实际的数据获取以及 DOM 渲染的操作都会在客户端执行。也就跟大家熟悉的传统客户端 SPA 应用的行为一致了

![客户端请求](https://pic1.zhimg.com/v2-3b4ea8752fc034817e8383fe078aeb84.png)

#### 注意

上述图片指的是用 `前端路由` 进行跳转的情况。此时的跳转并不会真正的向服务端发起请求。所有数据的获取是在客户端完成的。

如果开发者使用 `a` 标签进行跳转。则此时可视为完全打开一个新页面。此时的数据获取操作仍然是在服务端完成

如下图：

- 首次刷新页面服务端渲染，请求由服务端调用
- 后面通过 router 前端路由形式跳转，客户端按需加载静态资源，请求数据

![请求示意演示](https://zhihu-live.zhimg.com/namespace_1001/static/20220216/89533284eeaf1974b12cf8010fc13f27.gif)

### 判断当前环境

在默认的示例中，我们会通过 `__isBrowser__` 变量来标志当前环境是为了让开发者了解该文件可能会在 `服务端`，`客户端` 两种不同的环境中执行。该变量构建过程中会自动注入无需开发者关注。而真实应用中，除了基础建设成熟的公司或部门会在 `Node.js` 层通过 `RPC` 的方式去调用其他语言的接口之外，大部分公司还是使用 `HTTP` 的形式来请求服务。这种情况不需要通过 `__isBrowser__` 判断环境。可直接用 [axios](https://github.com/axios/axios) 发起 `HTTP` 请求, `axios` 会自动根据当前环境判断是客户端则使用 `xhr` 对象发起请求服务端则使用 `http` 模块发起请求。

### 方法入参

#### React 场景

在 `React` 场景，我们在 `服务端` 会将当前请求的上下文 `ctx` 作为参数传入。开发者可以通过 `ctx` 拿到上面挂载的 `自定义 Service` (可通过中间件挂载) 或者 `ctx.request` 等对象信息。

```js
export interface Params<T, U> {
  ctx?: ISSRContext<T> // 请求上下文，仅在服务端使用
  routerProps?: RouteComponentProps<U> // 路由参数
  state?: any // 当前的 store state，客户端场景下可获取
}

export type ReactFetch<T={}, U={}> = (params: Params<T, U>) => Promise<any>
```

在 `React` 场景客户端请求数据时，我们会用一个 [高阶组件](https://git.in.zhihu.com/fe/mix/-/blob/master/packages/plugin-react/src/components/wrapComponent.tsx) 包裹在所有的页面级别组件外部。在 `useEffect` 中获取数据。所以我们的行为会是跳转后立即打开跳转后的页面组件，当执行完 `useEffect` 的逻辑后拿到数据修改 `Context` 再触发组件的重新 `render`

### 补充内容

通过上面的内容开发者可以知道在一个服务端渲染应用中我们应该怎么获取数据了。但是比起纯客户端应用我们还是有一些不足如下

- 只能够获取页面级组件数据，不包含子组件
- 必须通过静态方法来获取

在 `React` 场景略麻烦，`react-graphQl-apollo` 的解决思路是将组件在服务端渲染两次。第一次渲染时我们可以拿到当前的组件具有哪些子组件并且可以拿到子组件上定义的静态方法。进行收集并调用。在第二次渲染的时候将收集的数据与组件结合变成完整的字符串。当然这样的缺陷就是渲染两次会对性能造成一定影响。但也是一个思路

针对 `double rendering` 以及 静态方法的问题，我们都可以通过 [React Suspense](https://reactjs.org/docs/concurrent-mode-suspense.html) 来解决。`Suspense` 的概念有些丰富，这里不进行详细描述。这里摘录官网的[示例代码](https://codesandbox.io/s/frosty-hermann-bztrp?file=/src/fakeApi.js)进行讲解

```js
// This is not a Promise. It's a special object from our Suspense integration.
const resource = fetchProfileData();

function ProfilePage() {
  return (
    <Suspense fallback={<h1>Loading profile...</h1>}>
      <ProfileDetails />
      <Suspense fallback={<h1>Loading posts...</h1>}>
        <ProfileTimeline />
      </Suspense>
    </Suspense>
  );
}

function ProfileDetails() {
  // Try to read user info, although it might not have loaded yet
  const user = resource.user.read();
  return <h1>{user.name}</h1>;
}

function ProfileTimeline() {
  // Try to read posts, although they might not have loaded yet
  const posts = resource.posts.read();
  return (
    <ul>
      {posts.map(post => (
        <li key={post.id}>{post.text}</li>
      ))}
    </ul>
  );
}
```

在 `resource.posts.read()` 中，我们会进行一个异步的获取数据的操作。当然它返回的并不是一个 `Promise` 对象，而是一个特殊的 `Suspense integration`。在组件渲染的过程中，会等待 `posts` 的数据真正返回后，在进行具体的 `render` 逻辑。也就是我们用同步的写法来描述了一个异步的操作。

当然目前 `Suspense` 的特性并没有成熟，特别是与服务端渲染结合这一块还有许多问题要解决。但是也是一个未来的发展思路。值得关注。

## 其他

### 直接查看服务端请求结果

接口数据请求一般可通过 **禁用服务端渲染** 即 `?csr=false` 参数，然后直接在浏览器的控制台 network 面板查看数据请求，但是该方案存在以下问题：

- 只能查看 `fetch / xhr` 真实 http 的请求链路，如果服务端请求是由 rpc 接口请求也无法直接查看数据
- 无法看到 fetch 文件最终处理数据的返回结果，因为请求数据不一定为最终服务端渲染使用的数据

另外一个方案为在服务端渲染的 HTML 中找到注水数据，但是该数据实际上是 store 的数据结果，不一定完全由请求数据组成

故为了方便查看服务端请求结果，`mix` 框架提供了 `data_type=json` 参数，打开页面时加上该参数，可直接获取服务端 `fetch` 文件的返回结果，例如：

![list页面服务端请求返回](https://pic3.zhimg.com/v2-0af9676e6aa75ca5876e18c3101f1d35.png)

### 全局 state 和 fetch 的关系

```js
const combineData = isCsr ? null : Object.assign(state ?? {}, layoutFetchData ?? {}, fetchData ?? {})

const injectState = isCsr
  ? null
  : <script dangerouslySetInnerHTML={{
    __html: `window.__USE_SSR__=true; window.__INITIAL_DATA__ =${serialize(combineData)}`
  }} />
```

全局 state 数据由 `state` 默认数据、`layoutFetch` 返回数据 和 `fetch` 返回数据构成
