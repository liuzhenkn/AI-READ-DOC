---
title: 高级
toc: menu
order: 3
---


## 生态

结合 MIX 和知乎业务背景，搭建的前端基础设施工具集，支持在 MIX 项目使用的同时，最大程度的兼容大部分其他前端项目使用。

该列表不全，具体可参考 [mix-market](http://mix-market.zhdocs.io/) 文档

- React 标题/SEO 优化：[http://mix-market.zhdocs.io/market/react-helmet.html](http://mix-market.zhdocs.io/market/react-helmet.html)
- 请求库
- 异常处理
- 数据上报

## 渲染自动降级

当启用 stream 渲染模式时，如果是在 renderToNodeStream 前发生的异常错误，会渲染降级将失效，将抛出错误。如果是在 renderToNodeStream 过程中发生的异常，错误将被全局 onerror 事件捕获，页面将降级为 csr 模式渲染

当渲染模式为 string 时，优先走渲染降级 csr 策略，如果降级渲染失败，将抛出错误

建议搭配 [trace 生态](http://mix-market.zhdocs.io/market/trace.html) 使用，其中集成了 404、500、异常上报等机制

当发生异常降级时，框架层会抛出 `csr_downgrade` 事件，可以在业务侧监听获取及上报次数

```js
app.on('csr_downgrade', (appName, error) => { // app 为 koa 实例

})
```

## 客户端请求异常处理 <Badge>1.7.0</Badge>

开发者约定式在目录 app/components/layout 下放置名为 ErrorPage 的组件，当客户端请求异常时，可以展示此组件。

```shell
├── app
│   └── components
│       └── layout
│           └── ErrorPage.tsx
```

框架侧会透传错误、路由、以及路由参数给该组件，支持自定义错误组件。

```shell
// ErrorPage.tsx

import type {DowngradeErrorComponentProps} from '@zh-mix/core-react'
import {Empty} from '@kfe/mix-ui'
import css from './index.module.less'

const ErrorPage = (props: DowngradeErrorComponentProps) => {
  const {path, downgradeErr, params} = props

  if (path?.includes('feature')) {
    return <Empty className={css.empty} title='错误 1' />
  }

  return (
    <Empty className={css.empty} title='错误 2' />
  )
}
```

当未放置 ErrorPage 组件时，会在框架侧默认错误组件，样式如下（推荐使用自定义错误组件）：

<img src=https://pic1.zhimg.com/v2-1124b124e09e186ffd1920008f899e88.png width=250px />

## helmet 标题/Meta等 <Badge>1.2.0</Badge>

http://mix-market.zhdocs.io/market/react-helmet.html

仅支持设置了渲染模式为 string 的 APP，修改指引：[http://mix.zhdocs.io/configs/app.html#stream](http://mix.zhdocs.io/configs/app.html#stream)

如果设置了渲染模式为 stream，开发模式下使用了`Helmet`相关特性，将出现如下提示，并且服务端渲染结果中 HTML 中不会生效。(生产模式中无该提示)

![stream 开发模式下提醒示例](https://picx.zhimg.com/v2-2df5051457ff444e71c139dab42894f3.png)

Mix 框架底层为按需引入该库，对于没有使用 Helmet 组件的 APP，不对标签做相关操作修改。

可在任意页面和组件中使用，子组件将覆盖父组件属性

### 简单示例

```jsx | pure
import { Helmet } from '@zh-mix-mkt/react-helmet'

const PageOrComponent = () => {

  return (
    <Helmet>
      <title>Mix 特性</title>
      <link rel="dns-prefetch" href="//pica.zhimg.com" />
    </Helmet> 
  ) 
}
```

### 所支持的完整标签列表

```jsx | pure
import { FC } from 'react'
import { Helmet } from '@zh-mix-mkt/react-helmet'
import type { SProps } from '@zh-mix/core-react'

const Page: FC<SProps> = () => {

  return (
    <div>
      <Helmet>
        <title>Hello World</title>
        <link rel="dns-prefetch" href="//pica.zhimg.com" />
        <link rel="dns-prefetch" href="//picx.zhimg.com" />

        <meta name="description" content="mix application" />

        <html lang="zh-CN" />

        {/* title attributes and value */}
        <title itemProp="name" lang="en">My Plain Title or {`dynamic`} title</title>

        {/* multiple meta elements */}
        <meta name="description" content="Helmet application" />
        <meta property="og:type" content="article" />

        {/* multiple link elements */}
        <link rel="canonical" href="http://mysite.com/example" />
        <link rel="apple-touch-icon" href="http://mysite.com/img/apple-touch-icon-57x57.png" />

        {/* multiple script elements */}
        <script src="http://include.com/pathtojs.js" type="text/javascript" />

        {/* inline script elements */}
        <script type="application/ld+json">{`
          {
              "@context": "http://schema.org"
          }
      `}</script>

        {/* inline style elements */}
        <style type="text/css">{`
            body {
                background-color: blue;
            }

            p {
                font-size: 12px;
            }
        `}</style>
      </Helmet>
    </div>
  )
}

export default Page
```

## SSR CSS 首屏优化 <Badge>1.8.0</Badge>

### 背景

CSS是网页样式表语言，用于定义网页的外观和布局。CSS文件通常通过`<link>`元素在HTML中引入，并且默认是同步加载的。这意味着浏览器在解析HTML时会遇到`<link>`元素时停止渲染，并等待CSS文件下载完成后再继续渲染。这样做有一个好处是可以保证网页在加载时不会出现样式闪烁或错乱的问题。但是也有一个坏处是会增加网页的首屏时间（First Contentful Paint, FCP），即用户看到网页内容所需的时间。FCP是一个重要的性能指标，影响用户对网站的印象和满意度。

根据我们对盐言文稿页的监测和分析，3G Fast情况下，我们发现我们的网站FCP在 2s+，其中 CSS 会有一个600ms左右的渲染阻塞。这导致浏览器在渲染网页时需要等待所有CSS文件下载完成后才能显示内容。我们认为这是一个需要优化的问题，因为我们希望提供给用户更快速和流畅的网页体验。

我们希望通过实现CSS异步加载来优化我们网站的FCP性能指标。

### 配置

1. 开启特性前需要在 APP 的 `config.ts` 中将 [csscritical](http://mix.zhdocs.io/configs/app.html#csscritical) 设置为 `true`，并配合使用[@zh-mix-mkt/react-css-critical](http://mix-market.zhdocs.io/market/react-css-critical.html)中的`useCssCritical`

2. 使用异步方案加载 CSS 后，Layout 组件中的`injectCss`将不包含当前页面的 CSS 文件地址，而是通过在`injectScript`注入 JS 行内代码来加载 CSS。

3. 当发生**渲染降级**时，**CSS 首屏优化策略将被关闭**，样式仍然使用同步 CSS 链接加载。

csscritical和[stream](http://mix.zhdocs.io/configs/app.html#stream)配置有冲突，当配置csscritical为true时，stream不能为 true。框架侧无法对流做CSS字符串注入和替换。

当渲染降级时，因为页面节点在服务端本身是不做渲染的，故不会收集到页面的 CSS 字符串。如果使用异步方案来加载 CSS，可能出现客户端渲染完成了，但是 CSS 还没加载的情况，故当发生渲染降级时，将关闭 CSS 首屏优化策略，仍然使用同步 CSS 链接加载样式。

```tsx | pure
const Layout: FC<ILayoutProps> = props => {
  const {injectState} = props

  // 当开启特性后，在Layout组件中返回的`injectCss`将不在包含当前对应页面的 CSS 文件地址。将在`injectScript`注入JS行内代码用于加载CSS文件。
  const {injectCss, injectScript} = props.staticList || {}

  return (
    <html>
      <head>
        {/* 空数组 */}
        {injectCss}
      </head>

      <body>
        {/* 注入了一个行内 JS 用于加载 CSS 文件 */}
        {injectScript}
      </body>
    </html>
  )
}

export default Layout

```

![https://pica.zhimg.com/v2-a9621f4a18bb561663f586a8f17e2cda.png](https://pica.zhimg.com/v2-a9621f4a18bb561663f586a8f17e2cda.png)
