<Tree>
  <ul>
    <li>
      apps
      <small>app 均放置该目录，一个目录即一个 app</small>
      <ul>
        <li>
          appA
          <small>一个名为 appA 的应用，采用约定式路由</small>
          <ul>
            <li>
              components
              <small>appA 页面通用组件</small>
              <ul>
                <li>
                  layout
                  <small>(* 框架使用) 页面 layout 组件</small>
                  <ul>
                    <li>
                      index.tsx
                      <small>页面服务端渲染的 layout，只在服务端执行，不要在此运行客户端有关逻辑</small>
                    </li>
                    <li>
                      App.tsx
                      <small>服务端和客户端的页面嵌套组件，服务端在 layout 中引用，客户端在 client 入口引用，可通过 __isBrowser__ 或者 useEffect 判断当前在 浏览器环境做一些初始化操作</small>
                    </li>
                  </ul>
                </li>
                <li>... app 的其他通用组件</li>
              </ul>
            </li>
            <li>
              pages
              <small>appA 页面目录</small>
              <ul>
                <li>
                  page1
                  <small>appA 的 page1 页面，路由将解析为 /${prefix}/page1/</small>
                  <ul>
                    <li>fetch.ts</li>
                    <li>render.tsx</li>
                    <li>
                      components/...组件
                      <small> page1 的业务组件，也可以放置其他位置，但推荐将 「业务组件」 和 「外层通用组件区分」 </small>
                    </li>
                  </ul>
                </li>
                <li>
                  page2
                  <small>appA 的 page2 页面，带动态参数 id 和动态可选参数 name，路由将解析为：/${prefix}/page2/:id/:name? </small>
                  <ul>
                    <li>fetch.ts</li>
                    <li>render$id$name#.tsx</li>
                  </ul>
                </li>
              </ul>
            </li>
            <li>
              store
              <small>(* 框架使用) [可选] app A 的自定义全局 state</small>
              <ul>
                <li>
                  index.ts
                  <small>自定义的 reducer 和 state，将和框架生成的 state 进行合并</small>
                </li>
              </ul>
            </li>
            <li>
              config.ts
              <small>appA 的配置文件</small>
            </li>
          </ul>
        </li>
        <li>... 其他更多的 app</li>
      </ul>
    </li>
    <li>
      package.json
      <small>项目依赖</small>
    </li>
    <li>
      project.config.ts
      <small>项目级别配置文件，可配置服务端口号，项目级别中间件，所使用的渲染插件等</small>
    </li>
  </ul>
</Tree>
