# Changesets

## 使用

- 命令参考：[https://github.com/changesets/changesets/blob/main/docs/command-line-options.md](https://github.com/changesets/changesets/blob/main/docs/command-line-options.md)

```shell
pnpm changeset
pnpm changeset version
pnpm publish -r
```

## mix 中的 changesets

```json
{
  "change": "changeset",
  "cv": "changeset version",
  "release": "pnpm run build && pnpm release:only",
  "release:only": "changeset publish --registry=http://npm.in.zhihu.com",
  "change:alpha": "pnpm changeset pre enter alpha",
  "change:exit": "pnpm changeset pre exit"
}
```

### 发正式包

#### 本地发包  (废弃，禁止使用)

```shell
pnpm run change

pnm run cv

pnpm run release
```

#### 接入 changeset-publish CI 自动发包

代码修改完之后，执行 `pnpm run change` 生成版本说明临时文件，提交代码合入 master 后将自动发包

- [https://git.in.zhihu.com/kfe/changeset-publish](https://git.in.zhihu.com/kfe/changeset-publish)

### 发测试包

```shell
pnpm run change:alpha

pnpm run change

pnm run cv

pnpm run release

pnpm run change:exit # 退出测试包环境
```
