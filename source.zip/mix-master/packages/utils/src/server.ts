/** 和服务端渲染相关 并且 要打包到 build 中的工具函数 */
import { readFileSync } from 'fs'
import { join } from 'path'
import type { IConfig } from '@zh-mix/types'

export const normalizeSSrPath = (path: string, base?: string) => {
  if (base) {
    path = path.replace(base, '')
  }
  if (path.startsWith('//')) {
    path = path.replace('//', '/')
  }
  if (!path.startsWith('/')) {
    path = `/${path}`
  }

  return path
}

/**
 * 获取 app 的 client asset manifest，NOTE: 不能直接遍历赋值加载所有资源，因为存在拆包，不一定所有资源都有用
 * @param config app config，用于获取 manifest 路径
 * @returns manifest 内容
 */
export const getManifest = (config: IConfig): Record<string, string> => {
  const manifestPath = join(config.getOutput().clientOutPut, './asset-manifest.json')

  if (config?.isDev) {
    delete require.cache[manifestPath]
  }

  return require(manifestPath)
}

const readAsyncChunk = async (config: IConfig): Promise<Record<string, string>> => {
  try {
    const str = readFileSync(join(config.getOutput().clientOutPut, './asyncChunkMap.json')).toString()
    return JSON.parse(str)
  } catch (error) {
    return {}
  }
}

export const addAsyncChunk = async (dynamicCssOrder: string[], webpackChunkName: string, config: IConfig) => {
  const arr = []
  const asyncChunkMap = await readAsyncChunk(config)
  for (const key in asyncChunkMap) {
    if (asyncChunkMap[key].includes(webpackChunkName)) {
      arr.push(`${key}.css`)
    }
  }
  return arr.concat(dynamicCssOrder)
}
