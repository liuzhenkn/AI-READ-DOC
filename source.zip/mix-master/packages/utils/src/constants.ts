/** app 所存储的目录名 */
export const appDirName = 'apps'

/** 最终产物输出路径 */
export const outputDirName = 'build'

/** 构建时临时文件写出路径，位于 ${outputDirName} 内 */
export const preBuildOutputDirName = 'preBuild'

/** 前端资源打包数据路径，位于 ${outputDirName} 内 */
export const clientOutputDirName = 'client'

/** 服务端资源打包数据路径，位于 ${outputDirName} 内 */
export const serverOutputDirName = 'server'

/** 自定义路由文件名 */
export const declaretiveRoutesFileName = '_route.ts'

/** app 的页面目录 */
export const pagesDirName = 'pages'

/** 约定式路由解析写出的文件名称 */
export const temporaryRoutesFileName = 'mix-temporary-routes.js'

/** webpack 打包默认的 chunkName */
export const defaultChunkName = 'Page'

export const notImportRouterFlag = '//#not-import-react-router-dom'

export const defaultHtmlTemplatePath = './components/layout/index.html'
