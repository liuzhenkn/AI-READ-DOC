import { join } from 'path'
import type { IConfig } from '@zh-mix/types'
import {
  getCwd,
  getUserConfig,
  normalizeStartPath,
  normalizeEndPath,
  getAppDir,
  judgeFramework,
  getBuildOutput
} from './cwd'

import { defaultChunkName } from './constants'
const loadModule = require.resolve

/**
 * 加载 app 配置，在构建时 和 服务端渲染运行时均有使用
 * @param app 所需要加载的配置的 app 名称
 * @returns IConfig
 */
const loadConfig = (app: string): IConfig => {
  const framework = judgeFramework()
  const userConfig = getUserConfig(app)
  const cwd = getCwd()
  const mode = 'ssr'
  const stream = false

  const alias = Object.assign({
    '@': getAppDir(app),
    '~': getCwd(),
    _build: getBuildOutput(app).preBuildOutPut
  }, framework === 'react'
    ? {
        // 注意顺序 react/jsx-runtime -> react
        'react/jsx-runtime': loadModule('react/jsx-runtime') ?? join(cwd, './node_module/react/jsx-runtime'),
        'react/jsx-dev-runtime': loadModule('react/jsx-dev-runtime') ?? join(cwd, './node_module/react/jsx-dev-runtime'),
        react: loadModule('react') ?? join(cwd, './node_module/react'),
        'react-router-dom': loadModule('react-router-dom') ?? join(cwd, './node_module/react-router-dom')
      }
    : {}, userConfig.alias)

  const publicPath = userConfig.publicPath?.startsWith('http') ? userConfig.publicPath : normalizeStartPath(userConfig.publicPath ?? '/')
  const devPublicPath = publicPath.startsWith('http') ? publicPath.replace(/^http(s)?:\/\/(.*)?\d/, '') : publicPath // 本地开发不使用 http://localhost:3000 这样的 path 赋值给 webpack-dev-server 会很难处理

  const moduleFileExtensions = [
    '.web.mjs',
    '.mjs',
    '.web.js',
    '.js',
    '.web.ts',
    '.ts',
    '.web.tsx',
    '.tsx',
    '.json',
    '.web.jsx',
    '.jsx',
    '.css'
  ]

  const isDev = userConfig.isDev ?? process.env.NODE_ENV !== 'production'

  const fePort = userConfig.fePort ?? 8888

  let https = userConfig.https ? userConfig.https : !!process.env.HTTPS

  if (!((typeof https === 'boolean' && https) || (typeof https === 'object' && Object.keys(https).length !== 0))) {
    https = false
  }

  const host = '0.0.0.0'

  const chunkName = defaultChunkName

  const useHash = !isDev // 生产环境默认生成hash

  const whiteList: RegExp[] = [/\.(css|less|sass|scss)$/, /antd.*?(style)/, /store$/]

  const jsOrder = [`runtime~${chunkName}.js`, 'vendor.js', `${chunkName}.js`, 'zhlibs.js'].concat(userConfig.extraJsOrder ?? [])

  const cssOrder = ['vendor.css', `${chunkName}.css`].concat(userConfig.extraCssOrder ?? [])

  const webpackStatsOption: IConfig['webpackStatsOption'] = {
    assets: true, // 添加资源信息
    cachedAssets: true, // 显示缓存的资源（将其设置为 `false` 则仅显示输出的文件）
    children: false, // 添加 children 信息
    chunks: false, // 添加 chunk 信息（设置为 `false` 能允许较少的冗长输出）
    colors: true, // 以不同颜色区分构建信息
    modules: false, // 添加构建模块信息
    warnings: false,
    entrypoints: true // 入口 JS 文件
  }

  // dev-server 的很多配置网上找到的都是 v3 版本的，可以参考 https://github.com/webpack/webpack-dev-server/blob/master/migration-v4.md
  // DOC: https://webpack.docschina.org/configuration/dev-server/
  // 禁用输出在 webpack 的 infrastructureLogging 中配置
  const webpackDevServerConfig = Object.assign({
    https,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, PATCH, OPTIONS',
      'Access-Control-Allow-Headers': 'X-Requested-With, content-type, Authorization'
    },
    // Allows to configure options for serving static files from directory (by default 'public' directory).
    static: false,
    client: {
      // Enables a full-screen overlay in the browser when there are compiler errors or warnings.
      overlay: true
    },
    allowedHosts: 'all',
    devMiddleware: {
      stats: webpackStatsOption
    }
  }, userConfig.webpackDevServerConfig, {
    host,
    port: fePort
  })

  const chainBaseConfig = () => {
    // 覆盖默认webpack配置
  }
  const chainClientConfig = () => {
    // 覆盖默认 client webpack配置
  }
  const chainServerConfig = () => {
    // 覆盖默认 server webpack配置
  }

  const manifestPath = `${normalizeEndPath(devPublicPath)}asset-manifest.json`
  const staticPath = `${normalizeEndPath(devPublicPath)}static`
  const hotUpdatePath = `${normalizeEndPath(devPublicPath)}*.hot-update**`

  const proxyKey = [staticPath, hotUpdatePath, manifestPath]

  const config = Object.assign({}, {
    prefix: '/',
    chainBaseConfig,
    chainServerConfig,
    chainClientConfig,
    cwd,
    isDev,
    publicPath,
    useHash,
    host,
    moduleFileExtensions,
    fePort,
    chunkName,
    jsOrder,
    cssOrder,
    getOutput: () => getBuildOutput(app),
    webpackStatsOption,
    whiteList,
    dynamic: true,
    mode,
    static: false,
    html: {},
    stream,
    polyfill: true,
    https,
    manifestPath,
    proxyKey,
    container: '' // 为空默认启动
  }, userConfig)
  config.alias = alias
  config.webpackDevServerConfig = webpackDevServerConfig // 防止把整个 webpackDevServerConfig 全量覆盖了

  return config
}

export {
  loadConfig
}
