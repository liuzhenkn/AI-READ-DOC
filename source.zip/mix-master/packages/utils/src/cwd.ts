import { promises as fs, accessSync, readFileSync } from 'fs'
import { resolve, join } from 'path'
import type { UserConfig, IPlugin, IProjectConfig } from '@zh-mix/types'
import { loadConfig } from './loadConfig'
import { appDirName, outputDirName, preBuildOutputDirName, clientOutputDirName, serverOutputDirName, pagesDirName, notImportRouterFlag, temporaryRoutesFileName, defaultHtmlTemplatePath } from './constants'

const getCwd = () => process.cwd()
/**
 * 返回 app 所存放的目录地址，例：/home/example/apps
 * @returns Apps 的目录地址
 */
export const getAppBase = () => resolve(getCwd(), `./${appDirName}/`)

/** 获取产物构建路径 */
export const getOutputDir = () => resolve(getCwd(), `./${outputDirName}/`)

/**
 * 返回 ${app} 的具体目录路径
 * @param app app 名称
 * @returns app 具体路径
 */
const getAppDir = (app: string) => resolve(getAppBase(), `./${app}`)

/**
 * 返回 ${app} 的页面代码的具体目录路径
 * @param app app 名称
 * @returns app pages 的具体路径
 */
const getAppPagesDir = (app: string) => resolve(getAppDir(app), `./${pagesDirName}`)

const getBuildAppName = (): string => {
  return process.env.APP!
}

/**
 * 判断文件是否存在
 * @param file 文件
 * @returns 文件是否存在
 */
const accessFileSync = (file: string) => {
  let res = true
  try {
    accessSync(file)
  } catch (error) {
    res = false
  }
  return res
}

const getBuildOutput = (app: string, mkdir = true) => {

  const buildOutDir = join(getCwd(), `./${outputDirName}`)

  const clientOutPut = join(buildOutDir, `./${clientOutputDirName}`, `./${app}`)
  const serverOutPut = join(buildOutDir, `./${serverOutputDirName}`, `./${app}`)
  const preBuildOutPut = join(buildOutDir, `./${preBuildOutputDirName}`, `./${app}`)

  if ((!accessFileSync(serverOutPut) || !accessFileSync(clientOutPut) || !accessFileSync(preBuildOutPut)) && mkdir) {
    const { mkdir } = require('shelljs')
    if (!accessFileSync(serverOutPut)) { mkdir('-p', serverOutPut) }
    if (!accessFileSync(clientOutPut)) { mkdir('-p', clientOutPut) }
    if (!accessFileSync(preBuildOutPut)) { mkdir('-p', preBuildOutPut) }
  }

  return {
    clientOutPut,
    serverOutPut,
    preBuildOutPut
  }
}

const getHtmlTemplatePath = (app: string, templatePath?: string): string | undefined => {
  const htmlFile = templatePath ?? resolve(getAppDir(app), defaultHtmlTemplatePath)

  const hasTemplate = accessFileSync(htmlFile)
  if (hasTemplate) {
    return htmlFile
  }
}

/**
 * 使用 esbuild 构建 app 配置，每个 app 必须存在该文件，因为 app 的 base url (prefix) 是必须的
 * transformConfig 应在路由解析生成、打包前
 * @param app 所打包的 app 名称 (即目录名)
 */
const transformConfig = async (app: string) => {
  try {
    const { build } = require('esbuild')
    const { nodeExternalsPlugin } = require('esbuild-node-externals')

    const appConfigPath = resolve(getAppBase(), `./${app}/config.ts`)
    const hasAppConfig = accessFileSync(appConfigPath)

    const serverOutput = getBuildOutput(app).serverOutPut
    const outfile = resolve(serverOutput, './config.js')

    if (hasAppConfig) {
      // 不能 bundle: true，否则 webpack chain 和 postcss 的一些依赖 应该也会被打包到 config 中
      // 方案一 bundle: false，方案二 bundle: true + nodeExternals，目前采用 方案二

      // 插件不支持 sync 同步 api: buildSync，所以用了 build
      await build({
        entryPoints: [appConfigPath],
        loader: { '.ts': 'ts' },
        format: 'cjs',
        bundle: true,
        outfile,
        // https://www.npmjs.com/package/esbuild-node-externals
        plugins: [nodeExternalsPlugin()],
        platform: 'node'
      })
    } else {
      throw new Error(`${app} 未创建 config.ts 文件，这个是必须的哦 ~`)
    }

  } catch (error) {
    console.log('transformConfig ~ error', error)
    throw error
  }
}

/**
 * 使用 esbuild 构建 ProjectConfig 配置，项目级别配置
 * transformConfig 应在路由解析生成、打包前
 * 开发阶段每次都会调用，正式打包阶段应在 buildAll 阶段构建 (避免每个 app 都重新生成一次该配置)
 */
const transformProjectConfig = async () => {

  const { build } = require('esbuild')
  const { nodeExternalsPlugin } = require('esbuild-node-externals')

  const configPath = resolve(getCwd(), './project.config.ts')
  const hasConfig = accessFileSync(configPath)

  const buildOutDir = join(getCwd(), `./${outputDirName}`)
  const outfile = join(buildOutDir, `./${serverOutputDirName}`, './project.config.js')

  if (hasConfig) {
    // 不能 bundle: true，否则 webpack chain 和 postcss 的一些依赖 应该也会被打包到 config 中
    // 方案一 bundle: false，方案二 bundle: true + nodeExternals，目前采用 方案二

    // 插件不支持 sync 同步 api: buildSync，所以用了 build
    await build({
      entryPoints: [configPath],
      loader: { '.ts': 'ts' },
      format: 'cjs',
      bundle: true,
      outfile,
      // https://www.npmjs.com/package/esbuild-node-externals
      plugins: [nodeExternalsPlugin()],
      platform: 'node'
    })
  }
}

const normalizeStartPath = (path: string) => {
  if (path.startsWith('//')) {
    path = path.replace('//', '/')
  }
  if (!path.startsWith('/')) {
    path = `/${path}`
  }
  return path
}

const normalizeEndPath = (path: string) => {
  if (!path.endsWith('/')) {
    path = `${path}/`
  }
  return path
}

const judgeFramework = () => {
  const cwd = getCwd()
  const packageJSON = require(resolve(cwd, './package.json'))
  if (packageJSON.dependencies.react || packageJSON.devDependencies.react) {
    return 'react'
  }

  console.log('judgeFramework error, please check packageJSON')
}

/**
 * 获取 app 层面的用户配置
 * @param app 应用名称
 * @returns 用户的应用配置
 */
const getUserConfig = (app: string): UserConfig => {
  let config = { userConfig: { prefix: '/' } }

  try {
    const serverOutput = getBuildOutput(app).serverOutPut
    config = require(resolve(serverOutput, './config'))
  } catch (error) {
    console.log(`未获取到 ${app} 的用户配置项，将使用默认配置`, error)
  }

  return config.userConfig ?? config
}

/**
 * 获取项目配置 (服务启动运行时 和 编译时使用)
 * @returns 项目配置
 */
const getProjectConfig = (): IProjectConfig => {
  const defaultServerPort = 3000
  const envServerPort = process.env.SERVER_PORT ? Number(process.env.SERVER_PORT) : defaultServerPort

  const buildOutDir = join(getCwd(), `./${outputDirName}`)
  const configFile = join(buildOutDir, `./${serverOutputDirName}`, './project.config.js')
  const hasConfig = accessFileSync(configFile)
  if (hasConfig) {
    const config: IProjectConfig = require(configFile).default
    return config?.serverPort
      ? config
      : { ...config, serverPort: envServerPort }
  }

  const msg = '未找到项目配置文件 project.config，请进行相应的配置'
  console.log(msg)

  throw new Error(msg)
}

const loadPlugin = (): IPlugin => {
  const config = getProjectConfig()
  if (config.plugin.clientPlugin && config.plugin.serverPlugin) {
    return config.plugin
  }

  throw new Error('请配置项目所需要使用的 clientPlugin 和 serverPlugin')
}

const copyReactContext = async (app: string) => {
  const preBuildOutPut = getBuildOutput(app).preBuildOutPut
  await fs.copyFile(resolve(getCwd(), './node_modules/@zh-mix/plugin-react/src/entry/create-context.ts'), resolve(preBuildOutPut, './create-context.ts'))
}

const getLocalNodeModules = () => resolve(__dirname, '../../../node_modules') // mix/node_modules

const normalizePublicPath = (path: string) => {
  // 兼容 /pre /pre/ 两种情况
  if (!path.endsWith('/')) {
    path = `${path}/`
  }
  return path
}

const getOutputPublicPath = (app: string) => {
  const { publicPath, isDev } = loadConfig(app)
  const path = normalizePublicPath(publicPath)
  return isDev ? path : `${path}${app}/`
}

const getImageOutputPath = (app: string) => {
  const { publicPath, isDev } = loadConfig(app)
  const imagePath = 'static/images'
  const normalizePath = normalizePublicPath(publicPath)
  return {
    publicPath: isDev ? `${normalizePath}${imagePath}` : `${normalizePath}${app}/${imagePath}`,
    imagePath
  }
}

/**
 * 解析预编译的 temporaryRoutesFileName 来判断是否需要引入 react-router-dom
 * @param app app 名称
 * @returns 为 true 则不需要引入 router
 */
const parseNotImportRouterFlag = (app: string) => {
  const RoutesContent = readFileSync(resolve(getBuildOutput(app, false).preBuildOutPut, `./${temporaryRoutesFileName}`)).toString()
  return RoutesContent.includes(notImportRouterFlag)
}

const cyrb53 = function (str: string, seed = 0) {
  let h1 = 0xdeadbeef ^ seed; let h2 = 0x41c6ce57 ^ seed
  for (let i = 0, ch; i < str.length; i++) {
    ch = str.charCodeAt(i)
    h1 = Math.imul(h1 ^ ch, 2654435761)
    h2 = Math.imul(h2 ^ ch, 1597334677)
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909)
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909)
  return 4294967296 * (2097151 & h2) + (h1 >>> 0)
}

const cryptoAsyncChunkName = (chunks: Array<{name: string}>, asyncChunkMap: Record<string, string[]>) => {
  // 加密异步模块 name，防止名称过长
  // static/js/vendors-node_modules_pnpm_webpack-dev-server_4_9_0_debug_4_3_4_webpack_5_72_1_node_modules_we-5cdb96.js
  chunks.sort((a, b) => a.name > b.name ? -1 : 1) // 保证相同值不同顺序的数组最终的加密结果一致
  const allChunksNames = chunks.map(item => item.name).join('~')
  const allChunksNamesArr = allChunksNames.split('~')
  const cryptoAllChunksNames = String(cyrb53(allChunksNames))

  if (allChunksNamesArr.length >= 2 && !asyncChunkMap?.[cryptoAllChunksNames]) {
    asyncChunkMap[cryptoAllChunksNames] = allChunksNamesArr
  }

  return cryptoAllChunksNames
}

export {
  transformConfig,
  normalizeStartPath,
  accessFileSync,
  judgeFramework,
  getAppDir,
  getAppPagesDir,
  getBuildOutput,
  normalizeEndPath,
  getUserConfig,
  getCwd,
  getBuildAppName,
  loadPlugin,
  copyReactContext,
  getLocalNodeModules,
  getImageOutputPath,
  getOutputPublicPath,
  transformProjectConfig,
  getProjectConfig,
  parseNotImportRouterFlag,
  cryptoAsyncChunkName,
  getHtmlTemplatePath
}
