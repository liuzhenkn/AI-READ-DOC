import { pathToRegexp, Key } from 'path-to-regexp'

const normalizeClientPath = (path: string, prefix: string) => {
  path = path.replace(prefix!, '')
  if (path.startsWith('//')) {
    path = path.replace('//', '/')
  }
  if (!path.startsWith('/')) {
    path = `/${path}`
  }
  return path
}

const pathIsMatch = (path: string, pathname: string) => pathToRegexp(path).test(pathname)

const getQuery = () => {
  const querys: Record<string, string> = {}

  const queryString = window.location.search.substring(1)

  if (queryString) {
    const queryList = queryString.split('&')
    queryList.forEach(el => {
      const arr = el.split('=')
      querys[arr[0]] = arr[1]
    })
  }

  return querys
}

function safeDecodeURIComponent (text: string) {
  try {
    return decodeURIComponent(text)
  } catch (e) {
    return text
  }
}

function getParams (path: string) {
  const { pathname } = window.location

  const params: Record<string, string> = {}

  const keys: Key[] = []
  const regexp = pathToRegexp(path, keys)

  const values = pathname.match(regexp) ? pathname.match(regexp)!.slice(1) : []

  for (let len = values.length, i = 0; i < len; i++) {
    const value = values[i]
    if (keys[i] && value) {
      params[keys[i].name] = safeDecodeURIComponent(value)
    }
  }

  return params
}

/**
 * 获取 动态路由参数 + GET query 参数
 * @param path 动态路由
 * @returns 动态路由参数 + GET query 参数，query 参数会覆盖动态路由参数
 */
const getUrlParams = (path: string) => {
  return { ...getParams(path), ...getQuery() }
}

export { getUrlParams, normalizeClientPath, pathIsMatch }
