import { IPlugin } from '@zh-mix/types'
import { loadConfig, getProjectConfig, parseServerRoutes } from '@zh-mix/utils'
import * as nodemon from 'nodemon'
import { join } from 'path'

import * as debug from 'debug'

export function koaPlugin (): IPlugin['serverPlugin'] {
  return {
    name: 'plugin-koa',
    dev: async (app, argv) => { // 某些服务框架已经有自己的开发启动命令，所以没把 dev 通用方法提到 cli 管理
      const log = debug('服务 (开发环境)')
      log.enabled = true

      const projectConfig = getProjectConfig()
      const appsConfig = await parseServerRoutes()

      const container = argv?.container ? (argv.container as string) : (process.env.CONTAINER_NAME ?? '')
      container && log(`当前启动的容器名称为 ${container}`)

      const appConfig = loadConfig(app)
      nodemon({
        cwd: appConfig.cwd,
        script: require.resolve('@zh-mix/core-koa'),
        watch: [
          appConfig.getOutput().serverOutPut,
          join(require.resolve('@zh-mix/core-koa'), '..')
        ],
        nodeArgs: [argv?.debug ? '--inspect=:9231' : ''],
        verbose: true,
        stdout: true,
        // NOTE: 确保 webpack hot reload 前端部分加载完了，再重新启动 node 服务
        delay: 1000,
        env: {
          NODE_ENV: 'development',
          CONTAINER_NAME: container
        }
      }).on('start', function () {
        const url = `http://${process.env.DEV_HOST ?? '127.0.0.1'}:${projectConfig.serverPort}`

        log(`🍨 「启动成功」，服务地址：${url}`)
        argv?.debug && log('🍨 开启了 debug 参数，可通过 node 附加进行断点调试')

        console.log('\n')
        appsConfig.forEach(app => {
          const appLog = debug(app.name)
          appLog.enabled = true
          app.url.forEach(u => {
            appLog(`🔗 页面 URL：${url}${u}`)
          })
        })
        console.log('\n')

      }).on('quit', function () {
        log('🍨 已停止服务')
        process.exit()
      }).on('restart', function (files) {
        log(`🍨 「重启服务」，因为以下文件变化 ${files}`)
      })
    },
    build: () => { }
  }
}
