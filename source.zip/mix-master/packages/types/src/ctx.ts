import { Request, Response } from 'express'
import type { Context } from 'koa'

export interface ExpressContext {
  request: Request
  response: Response
}

export type ISSRContext<T={}> = (Context | ExpressContext) & T

export interface Options {
  mode?: string
}

export interface IWindow extends Window {
  __USE_SSR__?: boolean
  __INITIAL_DATA__?: any
  STORE_CONTEXT?: any
  prefix?: string
}

export interface IGlobal {
  window: {
    __USE_SSR__?: IWindow['__USE_SSR__']
    __INITIAL_DATA__?: IWindow['__INITIAL_DATA__']
  }
}
