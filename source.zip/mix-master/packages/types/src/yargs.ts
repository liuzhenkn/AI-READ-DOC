import * as yargs from 'yargs'

export interface Args {
  /** 启动或构建的 app 名称 */
  app?: string

  clean?: boolean

  /** 是否启用多进程模型启动服务，默认关闭 */
  cluster?: boolean

  /** 是否进行打包产物分析 */
  analyzer?: boolean

  /** 「开发模式」 下是否开启 server 的 inspect 进行附加调试 */
  debug?: boolean

  /** 多进程编译的 app 名称 */
  apps?: string[]

  /** 当前容器名称，如果有值将赋值给 CONTAINER_NAME 环境变量，服务启动时将仅启动相关的 apps */
  container?: string

  /** 创建app模版 */
  template?: string
}

export type ArgvBuilder = Partial<Record<keyof Args, yargs.Options>>

export type Argv = yargs.ArgumentsCamelCase<yargs.InferredOptionTypes<ArgvBuilder>>
