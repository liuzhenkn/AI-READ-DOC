import { Configuration as WebpackConfiguration, RuleSetCondition } from 'webpack'
import { Configuration as WebpackDevServerConfiguration } from 'webpack-dev-server'
import type { Middleware } from 'koa'
import type Koa from 'koa'
import type { ProcessedOptions } from 'html-webpack-plugin'

import { Argv } from './yargs'

import * as WebpackChain from '@gem-mine/webpack-chain'

export interface IPlugin {
  clientPlugin: {
    name: string
    dev?: (app: string, argv?: Argv) => void
    build?: (app: string, argv?: Argv) => void
  }
  serverPlugin: {
    name: string
    dev?: (app: string, argv?: Argv) => void
    build?: (app: string, argv?: Argv) => void
  }
}

export interface IProjectConfig {
  /** 本地开发时 Node.js 服务启动监听的端口, 也可以通过环境变量指定 SERVER_PORT=9000，默认为 3000 */
  serverPort?: number

  /** render router 前执行的中间件，需要 server-core 中实现 (koa 版本已经实现) */
  beforeRouterMiddleware?: <StateT = Koa.DefaultState, ContextT = Koa.DefaultContext>(app: Koa<StateT, ContextT>) => Middleware

  /** render router 后执行的中间件，需要 server-core 中实现 (koa 版本已经实现) */
  afterRouterMiddleware?: <StateT = Koa.DefaultState, ContextT = Koa.DefaultContext>(app: Koa<StateT, ContextT>) => Middleware

  plugin: IPlugin
}

export interface IConfig {
  /** 标志当前运行环境，根据 process.env.NODE_ENV !== 'production' 判断 */
  isDev: boolean

  stream: boolean

  /** 本地开发时 webpack-dev-server 托管前端静态资源的端口，Node.js Server 会自动 proxy 静态资源, 无特殊需求不需要修改，考虑到可能开发环境要同时启动多个 app，所以这个配置下放到 app 层面 */
  fePort: number

  /** webpack dev server 的启动 host，默认 0.0.0.0 */
  host: string

  alias?: Record<string, string>

  prefix: string
  mode: 'ssr' | 'csr'

  /** 纯客户端渲染，默认为 false，当配置未 true 时，将不再启动服务端构建 */
  static?: boolean
  /** 透传 html-webpack-plugin 插件配置，用于纯 csr 模式模板配置 */
  html?: Partial<ProcessedOptions>

  /** 需要启动该 app 的服务容器，不设置默认启动，设置后可通过启动服务时传入容器名指定需要启动的 apps */
  container: string

  /**
   * 是否启用服务端渲染 CSS style 注入，然后 css 文件使用异步加载
   * 默认为 false
   */
  cssCritical?: boolean

  /** 静态资源的 publicPath, 本地开发环境一般无需配置
   * 生产环境若走本地静态资源目录可基于 afterRouterMiddleware 中间件实现 staic 中间件
   * 若需要走单独的 CDN 服务部署可配置为具体的 CDN 地址例如 https://static.zhihu.com/mix/ */
  publicPath: string

  /** 指定前端页面进行构建构建。在某些情况下我们只需要调试某个前端页面而不是所有页面，此时可以通过该配置来选择需要调试的页面进行构建来提升构建速度减小代码体积。但要注意，如果生产环境仍然是所有页面都需要发布，需要在生产环境禁用此配置，否则构建出来的代码只包含当前选中的页面。 */
  routerOptimize?: {
    include?: string[]
    exclude?: string[]
  }
  /** 针对同一前端 path 可以对应多个路由时控制约定式路由优先级例如 /foo, 可以同时匹配 /:page /foo。用于约定式路由解析生成的数组排序。数字越大代表优先级越高。没有显示指定的路由优先级统一为 0 */
  routerPriority?: Record<string, number>

  /** 是否开启代码分割，默认开启 */
  dynamic: boolean

  /** 是否开启底层 webpack-dev-server 的 https 模式，需配合 3000 端口的 Node.js 的 https 服务同步使用。设置为 true 将使用默认的自签名证书。当此证书无法被信任时，也可以自行传递与 Node.js 服务端一致的证书配置。 */
  https: boolean | object

  /** webpack-dev-server 启动配置，host 和 port 使用整体配置中的进行覆盖 */
  webpackDevServerConfig?: WebpackDevServerConfiguration

  /** 需要额外初始化加载的 js chunk name，通常配合 splitChunks 配置一起使用, 若生成其他 name 的 chunk 开发者可通过 http://localhost:3000/asset-manifest.json 文件查看具体的 chunkName */
  extraJsOrder?: string[]

  /** 需要额外初始化加载的 css chunk name，通常配合 splitChunks 配置一起使用 */
  extraCssOrder?: string[]

  /** webpack 相关配置 */
  chainBaseConfig: (config: WebpackChain, isServer: boolean, app: string) => void
  chainServerConfig: (config: WebpackChain, app: string) => void
  chainClientConfig: (config: WebpackChain, app: string) => void

  /** webpack stats 配置 */
  webpackStatsOption: WebpackConfiguration['stats']

  /** 是否使用 @babel/preset-env corejs usage 作为 polyfill，默认 true，开启需要项目安装 core-js@3 模块 */
  polyfill: boolean

  /** polyfill @babel/preset-env corejs 自定义配置 */
  corejsOptions?: Record<string, any>

  /** layout 和 page 的 fetch 是否并行发送 */
  parallelFetch?: boolean

  css?: () => {
    loaderOptions?: {
      /** css loader options */
      cssOptions?: any
      less?: any
      postcss?: {
        /** function | object */
        options?: Function | Record<string, any>
        /** 用户自定义 postcss 插件 */
        plugins?: any[]
      }
    }
  }

  /** 服务端渲染前置中间件，在调用 render 前调用，其中的 next 为 render 渲染，所以这个比 afterRender 常用的多 */
  beforeRender?: (appConfig: ServerAppConfig) => Middleware

  /** 服务端渲染后置中间件，在调用 render next 后调用 */
  afterRender?: (appConfig: ServerAppConfig) => Middleware

  cwd: string

  /** webpack 打包是否生成 hash，生产环境默认生成 hash */
  useHash: boolean

  /** webpack 打包 extensions 默认为 ['.web.mjs',
    '.mjs',
    '.web.js',
    '.js',
    '.web.ts',
    '.ts',
    '.web.tsx',
    '.tsx',
    '.json',
    '.web.jsx',
    '.jsx',
    '.css'] */
  moduleFileExtensions: string[]

  /** webpack 打包默认 chunkname，默认为 Page，不建议修改 */
  chunkName: string

  /** 服务端渲染时写入的 css */
  cssOrder: string[]
  /** 服务端渲染时写入的 js，需要根据 webpack 默认打包配置做调整 */
  /** const jsOrder = [`runtime~${chunkName}.js`, 'vendor.js', `${chunkName}.js`].concat(userConfig.extraJsOrder ?? []) */
  jsOrder: string[]

  /** 当前 app 的打包输出路径 */
  getOutput: () => {
    clientOutPut: string
    serverOutPut: string
    /** 临时文件，构建时需要 */
    preBuildOutPut: string
  }

  /** 处理 server 端构建模块时，我们默认会对所有的第三方模块使用 externals 模式，即不在构建时用 Webpack 处理，运行时直接从 node_modules 中加载具体模块，但对于一些只提供了 esm 格式的模块，或者是非 Node.js 环境能直接执行的文件，例如 jsx|less|sass|css 等类型的文件会发生运行错误，针对这种类型的特殊模块我们提供了白名单配置，设置服务端构建配置 externals 的白名单，即需要让 Webpack 来处理的模块. */
  /** https://www.npmjs.com/package/webpack-node-externals allowlist */
  whiteList: RegExp[] | string[]

  /** 开发模式下的 manifestPath，做静态资源代理时使用，不过用处不大，实际上无需代理该文件 */
  manifestPath: string

  /** dev 模式下需要代理的静态资源 */
  proxyKey: string[]

  /** 开发阶段启动的代理，底层使用 http-proxy-middleware 来进行代理，框架只是单纯透传参数， 具体配置查看 http-proxy-middleware 文档 */
  proxy?: any

  /** 需要 babel 处理的 node_nodules 中的依赖 */
  babelExtraModule?: RuleSetCondition

  babelOptions?: (isServer: boolean, app: string) => {
    presets?: unknown[]
    plugins?: unknown[]
  }

  /** react 框架下默认如果一个 app 只有一个页面将不引入 react-router，如果需要强制引入，可以设置该选项为 true */
  useReactRouter?: boolean
}

export type UserConfig = Partial<IConfig> & Pick<IConfig, 'prefix'>

/**
 * setStyle 通用 webpack 插件传入参数
 */
export interface StyleOptions {
  rule: string
  include?: RegExp | RegExp[]
  exclude?: RegExp | RegExp[]
  loader?: string
  importLoaders: number
  isServer: boolean
}

export interface ServerAppConfig {
  /** app 名称，即目录名称 */
  name: string

  /** 请求的 url，一个项目可能有多个页面，所以是数组 */
  url: string[]

  /** 服务端 render 文件 */
  file: string

  /** 容器名，用于实现不同容器部署不同的 app */
  container?: string

  beforeRender?: IConfig['beforeRender']

  afterRender?: IConfig['afterRender']

  /** app loadConfig 配置 */
  config: IConfig
}

export type ServerAppsConfig = ServerAppConfig[]

/** 开发环境静态资源代理配置 */
export interface proxyOptions {
  express?: boolean
}
