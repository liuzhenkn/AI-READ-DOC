import * as WebpackChain from '@gem-mine/webpack-chain'
import { loadConfig, getCwd } from '@zh-mix/utils'
import { resolve } from 'path'
import { IConfig } from '@zh-mix/types'

const loadModule = require.resolve

const addBabelLoader = (
  chain: WebpackChain.Rule<WebpackChain.Module>,
  isServer: boolean,
  isDev: boolean,
  envOptions: any,
  babelOptions: ReturnType<Required<IConfig>['babelOptions']>
) => {
  chain.use('babel-loader')
    .loader(loadModule('babel-loader'))
    .options({
      cacheDirectory: true,
      cacheCompression: false,
      sourceType: 'unambiguous',
      presets: [
        [
          loadModule('@babel/preset-env'),
          envOptions
        ],
        [loadModule('babel-preset-react-app'), { flow: false, typescript: true, runtime: 'automatic' }],
        ...babelOptions?.presets ?? []
      ].filter(Boolean),
      plugins: [
        [loadModule('@babel/plugin-transform-runtime'), {
          regenerator: false,
          corejs: false,
          helpers: true
        }],
        [loadModule('@babel/plugin-proposal-private-methods'), { loose: true }],
        [loadModule('@babel/plugin-proposal-private-property-in-object'), { loose: true }],
        (!isServer && isDev) && loadModule('react-refresh/babel'),
        ...babelOptions?.plugins ?? []
      ].filter(Boolean)
    })
    .end()
}

const getBrowserlist = () => {
  const defaultBrowserslist = [
    'defaults'
  ]
  const cwd = getCwd()
  const packageJSON = require(resolve(cwd, './package.json'))
  if (packageJSON?.browserslist && Array.isArray(packageJSON.browserslist)) {
    return packageJSON.browserslist
  }

  return defaultBrowserslist
}

export const addBabelChain = (chain: WebpackChain, app: string, isServer: boolean) => {
  const appConfig = loadConfig(app)
  const { polyfill, babelExtraModule, corejsOptions, isDev, babelOptions } = appConfig

  const envOptions = {
    modules: false
  }

  const browsers = getBrowserlist()

  if (polyfill && !isServer) {
    Object.assign(envOptions, {
      targets: {
        browsers
      },
      corejs: {
        version: 3,
        proposals: true
      },
      useBuiltIns: 'usage',
      ...corejsOptions
    })
  }

  const babelModule = chain.module
    .rule('compileBabel')
    .test(/\.(js|mjs|jsx|ts|tsx)$/)
    .exclude
    .add(/node_modules|core-js/)
    .end()

  const module = chain.module
    .rule('compileBabelForExtraModule')
    .test(/\.(js|mjs|jsx|ts|tsx)$/)
    .include
    .add([/plugin-react/, /zh-mix\/utils/, /zh-mix-mkt/, /react-router/]) // NOTE: 正则，处理 mix 生态代码库

  let babelForExtraModule
  if (babelExtraModule) {
    babelForExtraModule = module.add(babelExtraModule).end().exclude.add(/core-js/).end()
  } else {
    babelForExtraModule = module.end().exclude.add(/core-js/).end()
  }

  const babelOptionsConfig = typeof babelOptions === 'function'
    ? babelOptions(isServer, app)
    : { presets: [], plugins: [] }

  addBabelLoader(babelModule, isServer, isDev, envOptions, babelOptionsConfig)
  addBabelLoader(babelForExtraModule, isServer, isDev, envOptions, babelOptionsConfig)

}
