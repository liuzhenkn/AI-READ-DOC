import { Compiler, WebpackError } from 'webpack'

interface Options {
  appBase: string
  appName: string
}

const PLUGIN_NAME = 'CrossAppDependentAnalysePlugin'

export class CrossAppDependentAnalysePlugin {
  options: Options

  constructor (options: Options) {
    this.options = options
  }

  apply (compiler: Compiler) {
    compiler.hooks.compilation.tap(PLUGIN_NAME, (compilation, { normalModuleFactory }) => {
      normalModuleFactory.hooks.createModule.tap({ name: PLUGIN_NAME }, (data, ResolveData) => {
        const modulePath: string = data.resourceResolveData?.path ?? ''
        const appBase = this.options.appBase + '/'
        const appName = this.options.appName

        if (modulePath.startsWith(appBase)) {
          const moduleAppPath = modulePath.replace(appBase, '')

          if (!moduleAppPath.startsWith(appName)) {
            const contextModule = ResolveData.contextInfo.issuer
            const error = new WebpackError(`${contextModule} 中存在跨 APP 引用依赖:${modulePath}`)
            compilation.errors.push(error)
          }
        }

      })

    })
  }
}
