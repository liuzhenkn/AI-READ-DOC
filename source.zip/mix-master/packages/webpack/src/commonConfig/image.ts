import * as WebpackChain from '@gem-mine/webpack-chain'
import { getImageOutputPath } from '@zh-mix/utils'

const loadModule = require.resolve

export const addImageChain = (chain: WebpackChain, isServer: boolean, app: string) => {
  const { publicPath, imagePath } = getImageOutputPath(app)
  chain.module
    .rule('images')
    .test(/\.(jpe?g|png|gif|image.svg)(\?[a-z0-9=.]+)?$/)
    .use('url-loader')
    .loader(loadModule('url-loader'))
    .options({
      name: '[name].[hash:8].[ext]',
      // require 图片的时候不用加 .default
      esModule: false,
      limit: 4096,
      fallback: {
        loader: loadModule('file-loader'),
        options: {
          emitFile: !isServer,
          publicPath,
          name: '[name].[hash:8].[ext]',
          esModule: false,
          outputPath: imagePath
        }
      }
    })
    .end()
}
