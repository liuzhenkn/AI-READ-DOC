import * as WebpackChain from '@gem-mine/webpack-chain'
import { StyleOptions } from '@zh-mix/types'
import { loadConfig } from '@zh-mix/utils'
const loadModule = require.resolve
const MiniCssExtractPlugin = require('mini-css-extract-plugin')

export const addStyleChain = (chain: WebpackChain, reg: RegExp, options: StyleOptions, app: string, isServer: boolean) => {
  const appConfig = loadConfig(app)
  const { css, useHash, isDev } = appConfig

  const { include, exclude, importLoaders, loader } = options

  // ========== ↓ css-loader-config ↓ ==========
  const userCssloaderOptions = css?.().loaderOptions?.cssOptions ?? {}
  const defaultCssloaderOptions = {
    importLoaders: importLoaders, // 在 css-loader 前应用的 loader 的数量
    modules: {
      // 对 .module.xxx 的文件开启 css-modules
      auto: true,
      // webpack 官方建议 ↓ 开发环境便于看类名，正式环境包尽可能小
      // 开发环境使用 '[path][name]__[local]'
      // 生产环境使用 '[hash:base64]'
      // xen: [name]-[local]-[hash:base58:5]
      // 为了让 e2e 能简单一些的抓取类名，不再使用 [hash:base64] 方案
      localIdentName: isDev ? '[path][name]-[local]' : '[name]-[local]_[hash:base64:5]'
    },
    // 使用 isomorphic-style-loader 时，需要设置 esModule 为 false，否则服务端渲染的 css 类名等会为空
    esModule: !isServer,

    // 服务端会读取 css 通过 style 注入到 html 渲染结果，不应该包含 sourcemap
    sourceMap: !isServer,
    url: {
      filter: (url: string) => {
        // 绝对路径开头的静态资源地址不处理
        return !url.startsWith('/')
      }
    }
  }
  const finalCssloaderOptions = Object.assign({}, defaultCssloaderOptions, userCssloaderOptions)
  // ========== ↑ css-loader-config ↑ ==========

  // ========== ↓ postcss-loader-config ↓ ==========
  const postCssPlugins = css?.().loaderOptions?.postcss?.plugins ?? [] // 用户自定义 postcss 插件
  const userPostcssOptions = css?.().loaderOptions?.postcss?.options // postCssOptions maybe function|object

  const finalPostcssOptions = typeof userPostcssOptions === 'function'
    ? userPostcssOptions
    : Object.assign({
      ident: 'postcss',
      plugins: [
        require('postcss-flexbugs-fixes'), // flex 语法转换，bug-fix https://www.npmjs.com/package/postcss-flexbugs-fixes
        require('postcss-discard-comments'), // 移除注释
        require('postcss-preset-env')({ // https://www.npmjs.com/package/postcss-preset-env
          autoprefixer: {
            flexbox: 'no-2009'
          },
          stage: 3
        })
      ].concat(postCssPlugins)
    }, userPostcssOptions ?? {}) // 合并用户自定义 postcss options

  // ========== ↑ postcss-loader-config ↑ ==========

  chain.plugin('mini-css-extract-plugin').use(MiniCssExtractPlugin, [{ // 配合 MiniCssExtractPlugin.loader
    filename: useHash ? 'static/css/[name].[contenthash:8].css' : 'static/css/[name].css',
    chunkFilename: useHash ? 'static/css/[name].[contenthash:8].chunk.css' : 'static/css/[name].chunk.css',
    // 此警告意思为在不同的js中引用相同的css时，先后顺序不一致。也就是说，在1.js中先后引入a.css和b.css，而在2.js中引入的却是b.css和a.css，此时会有这个warning,目前的项目使用的css module 该顺序不影响样式，故忽略
    ignoreOrder: true
  }])

  // client: less -> postcss -> css -> mini-css-extract
  // server: less -> postcss -> css -> isomorphic-style-loader
  chain.module
    .rule(options.rule)
    .test(reg)
    .when(Boolean(include), rule => {
      include && rule.include.add(include).end()
    })
    .when(Boolean(exclude), rule => {
      exclude && rule.exclude.add(exclude).end()
    })
    .when(isServer, rule => {
      rule
        .use('isomorphic-style-loader')
        .loader(loadModule('isomorphic-style-loader')).end()
    })
    .when(!isServer, rule => {
      rule.use('mini-css-extract-plugin-loader')
        .loader(MiniCssExtractPlugin.loader)
        .options({
          emit: !isServer
        })
        .end()
    })
    .use('css-loader')
    .loader(loadModule('css-loader'))
    .options(finalCssloaderOptions)
    .end()
    .use('postcss-loader')
    .loader(loadModule('postcss-loader'))
    .options({
      postcssOptions: finalPostcssOptions
    })
    .end()
    .when(Boolean(loader), rule => {
      loader && rule.use(loader)
        .loader(loadModule(loader))
        .when(loader === 'less-loader', rule => {
          rule.options(css?.().loaderOptions?.less ?? {
            lessOptions: {
              javascriptEnabled: true
            }
          })
        })
        .end()
    })
}
