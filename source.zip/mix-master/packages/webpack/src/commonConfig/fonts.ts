import * as WebpackChain from '@gem-mine/webpack-chain'
const loadModule = require.resolve

export const addFontsChain = (chain: WebpackChain, isServer: boolean) => {
  chain.module
    .rule('fonts')
    .test(/\.(eot|woff|woff2|ttf)(\?.*)?$/)
    // NOTE: webpack 5 自己会写出一份字体，导致写出两份，本地开发时未给 webpack5 写出的位置加代理，所以访问不到资源
    // 通过 type('javascript/auto') 禁用 webpack 5 自己的写出，使用 file-loader 进行处理
    .type('javascript/auto')
    .use('file-loader')
    .loader(loadModule('file-loader'))
    .options({
      name: 'static/[name].[hash:8].[ext]',
      esModule: false,
      emitFile: !isServer
    })
    .end()

}
