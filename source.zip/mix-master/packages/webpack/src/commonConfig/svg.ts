import * as WebpackChain from '@gem-mine/webpack-chain'
const loadModule = require.resolve

export const addSvgComponentChain = (chain: WebpackChain) => {
  chain.module
    .rule('svg')
    .test(/\.svg$/)
    .use('@svgr/webpack')
    .loader(loadModule('@svgr/webpack'))
    .options({
      svgProps: {
        height: '{props.size || props.height}',
        width: '{props.size || props.width}',
        fill: '{props.fill || "currentColor"}'
      },
      svgo: false
    })
    .end()
}
