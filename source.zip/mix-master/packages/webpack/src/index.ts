export * from './client'
export * from './server'

/** 通用 webpack 配置 */
export * from './commonConfig/CrossAppDependentAnalyse'
export * from './commonConfig/babel'
export * from './commonConfig/fonts'
export * from './commonConfig/image'
export * from './commonConfig/style'
export * from './commonConfig/svg'
