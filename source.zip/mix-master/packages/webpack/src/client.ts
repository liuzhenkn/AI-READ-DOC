import * as webpack from 'webpack'
import * as WebpackDevServer from 'webpack-dev-server'
import { loadConfig } from '@zh-mix/utils'

import * as debug from 'debug'

const startClientServer = async (webpackConfig: webpack.Configuration, app: string): Promise<void> => {
  const log = debug('静态服务')
  log.enabled = true

  const { webpackDevServerConfig, https, fePort, proxy, static: staticPage } = loadConfig(app)

  return await new Promise(resolve => {
    const compiler = webpack(webpackConfig)
    const apiProxy = staticPage ? proxy : {}

    const server = new WebpackDevServer({ proxy: apiProxy, ...webpackDevServerConfig }, compiler)

    compiler.hooks.done.tap('DonePlugin', () => resolve())

    server.startCallback(e => {
      const url = `${https ? 'https' : 'http'}://${WebpackDevServer.internalIPSync('v4')}:${fePort}`
      const devServerFilesUrl = `${url}/webpack-dev-server`
      log(`「启动成功」 资源列表可以打开: ${devServerFilesUrl} 查看`)
    })
  })
}

const startClientBuild = async (webpackConfig: webpack.Configuration, app: string): Promise<void> => {
  const { webpackStatsOption } = loadConfig(app)
  const compiler = webpack(webpackConfig)

  return await new Promise((resolve, reject) => {
    compiler.hooks.done.tap('DonePlugin', () => resolve())

    compiler.run((err, stats) => {
      if (err) {
        console.error('startClientBuild : ', err)
        reject(err)

        process.exit(1)
      }

      if (stats?.compilation?.errors?.length) {
        console.error('startClientBuild : ', stats.compilation.errors)
        reject(stats.compilation.errors)

        process.exit(1)
      }

      stats && console.log(stats.toString(webpackStatsOption))
    })
  })
}

export {
  startClientServer,
  startClientBuild
}
