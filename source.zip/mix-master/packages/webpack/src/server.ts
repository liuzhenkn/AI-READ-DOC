import * as webpack from 'webpack'
import { loadConfig } from '@zh-mix/utils'
import * as debug from 'debug'

const startServerBuild = async (webpackConfig: webpack.Configuration, app: string): Promise<void> => {
  const { webpackStatsOption } = loadConfig(app)
  const compiler = webpack(webpackConfig)

  return await new Promise((resolve, reject) => {
    compiler.hooks.done.tap('DonePlugin', () => resolve())

    compiler.run((err, stats) => {
      if (err) {
        console.error('startServerBuild : ', err)
        reject(err)

        process.exit(1)
      }

      if (stats?.compilation?.errors?.length) {
        console.error('startServerBuild : ', stats.compilation.errors)
        reject(stats.compilation.errors)

        process.exit(1)
      }

      stats && console.log(stats.toString(webpackStatsOption))
    })
  })
}

const startServerWatch = async (webpackConfig: webpack.Configuration, app: string): Promise<void> => {
  const log = debug('服务端构建结果')
  log.enabled = true

  const { webpackStatsOption } = loadConfig(app)
  const compiler = webpack(webpackConfig)
  return await new Promise((resolve, reject) => {
    compiler.hooks.done.tap('DonePlugin', () => resolve())
    compiler.watch({},
      (err, stats) => {
        if (err) {
          log(`startServerWatch : ${JSON.stringify(err)}`)
          reject(err)
        }

        if (stats?.compilation?.errors?.length) {
          log(`startServerWatch : ${stats.compilation.errors}`)
          reject(stats.compilation.errors)
        }

        stats && console.log(stats.toString(webpackStatsOption))
      })
  }
  )
}

export {
  startServerBuild,
  startServerWatch
}
