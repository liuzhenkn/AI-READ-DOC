# @zh-mix/webpack

## 1.8.0

### Minor Changes

- f6cc009: 框架侧增加 cssCritical 配置,增加服务端渲染注入 CSS 字符串到 HTML 模板的能力

### Patch Changes

- f6cc009: 修改生成环境类名为[name]-[local]\_[hash:base64:5], 便于 e2e case 抓取类名
- f6cc009: 锁定 serialize-javascript 版本为 6.0.0, 升级 6.0.1 后会引入 bigint 导致低端机加载失败
- f6cc009: 升级 mix-example 模板
- f6cc009: 服务端构建引入 isomorphic-style-loader, 通过运行时获取 CSS 字符串能力
- Updated dependencies [f6cc009]
- Updated dependencies [f6cc009]
- Updated dependencies [f6cc009]
- Updated dependencies [f6cc009]
- Updated dependencies [f6cc009]
  - @zh-mix/utils@1.8.0

## 1.7.0

### Minor Changes

- 9dcb799: 增加客户端请求异常统一处理

### Patch Changes

- Updated dependencies [9dcb799]
  - @zh-mix/utils@1.7.0

## 1.6.0

### Minor Changes

- fa84715: 开发环境和联调环境出现渲染降级时,渲染结果增加水印提示

### Patch Changes

- Updated dependencies [fa84715]
  - @zh-mix/utils@1.6.0

## 1.5.1

### Patch Changes

- b566cc3: 修复色值 rgba 转换成 rrggbbaa 导致低端机型色值失效问题
- Updated dependencies [b566cc3]
  - @zh-mix/utils@1.5.1

## 1.5.0

### Minor Changes

- 2a3c6ef: 优化 Mix 默认拆包逻辑：知乎相关 npm 包单独拆包 (减少 vendor hash 改变几率 + 减小 vendor 大小)，增加部分文件异步拆包按需加载

### Patch Changes

- Updated dependencies [2a3c6ef]
  - @zh-mix/utils@1.5.0

## 1.4.1

### Patch Changes

- cbc56dd: 修复在 stream 开发模式下，未使用 helmet 也会提示 helmet 不支持 stream 模式
- Updated dependencies [cbc56dd]
  - @zh-mix/utils@1.4.1

## 1.4.0

### Minor Changes

- cf056b0: mix npm 包名域调整至 zh-mix

### Patch Changes

- Updated dependencies [cf056b0]
  - @zh-mix/utils@1.4.0

## 1.3.0

### Minor Changes

- 043d1e1: 渲染降级时，增加 csr_downgrade 事件抛出

### Patch Changes

- Updated dependencies [043d1e1]
  - @kfe/mix-utils@1.3.0

## 1.2.0

### Minor Changes

- fe7246d: 框架底层支持 react-helmet，http://mix-market.zhdocs.io/market/react-helmet.html

### Patch Changes

- Updated dependencies [fe7246d]
  - @kfe/mix-utils@1.2.0

## 1.1.0

### Minor Changes

- 8893d10: APP 纯静态化方案，支持活动静态页、后台、离线包等场景。(可配置单个 app 开启纯静态化, 模板支持 app 级别自定义)

### Patch Changes

- Updated dependencies [8893d10]
  - @kfe/mix-utils@1.1.0

## 1.0.0

### Major Changes

- b7fd3b6: 增加 babelOptions 配置项，可拓展 babel plugin/presets

### Patch Changes

- Updated dependencies [b7fd3b6]
  - @kfe/mix-utils@1.0.0

## 0.0.28

### Patch Changes

- 00e9702: 修改 JS splitChunk 默认方案
- Updated dependencies [00e9702]
  - @kfe/mix-utils@0.0.28

## 0.0.27

### Patch Changes

- c61cf0b: 修复 webpack-manifest-plugin 自动 removeKeyHash 在某些情况下导致生成 key 值错误
- Updated dependencies [c61cf0b]
  - @kfe/mix-utils@0.0.27

## 0.0.26

### Patch Changes

- af363ff: 优化异步 CSS 加载, 将 JS 加载的 CSS 提取到 HTML 中进行加载
- Updated dependencies [af363ff]
  - @kfe/mix-utils@0.0.26

## 0.0.25

### Patch Changes

- 2ff0b6b: mix 新增创建 app 模版功能
- Updated dependencies [2ff0b6b]
  - @kfe/mix-utils@0.0.25

## 0.0.24

### Patch Changes

- 5b96091: react 开发阶段接入 react-refresh, 实现组件粒度 HMR, 热更新时保留状态
- Updated dependencies [5b96091]
  - @kfe/mix-utils@0.0.24

## 0.0.23

### Patch Changes

- babc649: 提交代码时接入 commit 信息及代码格式校验
- 4ab9680: 迁移抽取通用 webpack 配置
- Updated dependencies [babc649]
- Updated dependencies [4ab9680]
  - @kfe/mix-utils@0.0.23

## 0.0.22

### Patch Changes

- ed6a2ef: 修复 react/jsx-runtime 路径解析错误
- 177de33: 升级 @kfe/changeset-publish
- 22335f4: 升级 JSX 转换方式, 介绍文档：https://zh-hans.reactjs.org/blog/2020/09/22/introducing-the-new-jsx-transform.html
- Updated dependencies [ed6a2ef]
- Updated dependencies [177de33]
- Updated dependencies [22335f4]
  - @kfe/mix-utils@0.0.22

## 0.0.21

### Patch Changes

- b5aecd7: 忽略 MiniCssExtractPlugin css 引入顺序 warning
- Updated dependencies [b5aecd7]
  - @kfe/mix-utils@0.0.21

## 0.0.20

### Patch Changes

- dcdbb29: 开发阶段框架层增加跨 app 引用依赖检测 webpack plugin
- Updated dependencies [dcdbb29]
  - @kfe/mix-utils@0.0.20

## 0.0.19

### Patch Changes

- 429595d: 修复上一版本引入的路径校验问题
- Updated dependencies [429595d]
  - @kfe/mix-utils@0.0.19

## 0.0.18

### Patch Changes

- 86833a7: 降级 csr 模式的数据处理 state 和 csr 路由跳转保持一致
- Updated dependencies [86833a7]
  - @kfe/mix-utils@0.0.18

## 0.0.17

### Patch Changes

- c3cf104: browserslist 配置支持
- Updated dependencies [c3cf104]
  - @kfe/mix-utils@0.0.17

## 0.0.16

### Patch Changes

- a200d16: webpack 设置为 peer 依赖，版本由业务侧控制
- Updated dependencies [a200d16]
  - @kfe/mix-utils@0.0.16

## 0.0.15

### Patch Changes

- 96c7b12: 接入 @kfe/changeset-publish 机器人发包通知
- Updated dependencies [96c7b12]
  - @kfe/mix-utils@0.0.15

## 0.0.14

### Patch Changes

- 457b0b7: 修复开发阶段 打包进程因开发过程中断, 增加生产环境错误中断
- Updated dependencies [457b0b7]
  - @kfe/mix-utils@0.0.14

## 0.0.13

### Patch Changes

- 1b9c9d7: koa router 路由删除 / 路由，修改并发打包数目 (from xen)
- 1b9c9d7: 版本和 mix 统一
- Updated dependencies [1b9c9d7]
- Updated dependencies [1b9c9d7]
  - @kfe/mix-utils@0.0.13

## 0.0.11

### Patch Changes

- c2c4159: 修复项目打包
- Updated dependencies [c2c4159]
  - @kfe/mix-utils@0.0.11

## 0.0.10

### Patch Changes

- 6248910: 完成第一个测试版本
- Updated dependencies [6248910]
  - @kfe/mix-utils@0.0.10
