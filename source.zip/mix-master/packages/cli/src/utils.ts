import ora from 'ora'
import { promises as fs } from 'fs'
import { resolve } from 'path'
import { getAppBase } from '@zh-mix/utils'

export async function oraPromise<T> (
  promise: Promise<T>,
  message: string
): Promise<T> {

  const spinner = ora(message + '\n').start()
  return await new Promise((resolve, reject) => {
    promise
      .then(data => {
        spinner.succeed()
        resolve(data)
      })
      .catch(err => {
        spinner.fail()
        reject(err)
      })
  })
}

export function isType<T> (obj: T, type: string) {
  return Object.prototype.toString.call(obj) === `[object ${type}]`
}

export const listApp = async () => {
  const appBase = getAppBase()
  const appFolders = await fs.readdir(appBase)

  const apps = []

  for (const app of appFolders) {
    const configPath = resolve(appBase, `./${app}/config.ts`)
    const isApp = await fs.access(configPath)
      .then(() => true)
      .catch(() => false)
    isApp && apps.push(app)
  }

  return apps
}
