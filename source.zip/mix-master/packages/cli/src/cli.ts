#!/usr/bin/env node

import * as yargs from 'yargs'
import dev from './command/dev'
import build from './command/build'
import buildAll from './command/buildAll'
import list from './command/list'
import start from './command/start'
import clean from './command/clean'
import newApp from './command/new'
import { ArgvBuilder } from '@zh-mix/types'

const builder = {
  app: {
    string: true,
    describe: '所需要操作的 APP 名称，命令行参数优先于环境变量',
    default: ''
  },
  analyzer: {
    alias: 'a',
    boolean: true,
    describe: '是否进行打包产物分析',
    default: false
  },
  debug: {
    alias: 'd',
    boolean: true,
    describe: '「开发模式」 下是否开启 server 的 inspect 进行附加调试', // server-plugin 层面实现
    default: false
  },
  clean: {
    boolean: true,
    describe: '进行构建前是否删除以前的产物，默认进行删除',
    default: true
  },
  apps: {
    array: true,
    describe: 'buildAll 所需要编译的 app 名称',
    default: []
  },
  // 容器配置规则
  // - 项目启动时未配置 container 或 process.env.CONTAINER_NAME，将启动项目中的所有 app
  // - 项目启动时如果有配置 container 或 process.env.CONTAINER_NAME，将启动 appConfig.container 相同和 未设置容器名的 app
  // - 启动项目时 和 app 配置层均有配置的情况下，如果值不相同则不启动
  container: {
    string: true,
    describe: '当前的容器名称，如果有值将赋值给 CONTAINER_NAME 环境变量，服务启动时将仅启动相关的 apps，在 dev 和 prod 环境均生效'
  }
}

void yargs
  .command<ArgvBuilder>(['dev', 'watch'], '启动本地开发服务器进行项目的开发调试', builder, dev)
  .command<ArgvBuilder>('new', '创建新 app ', { ...builder, template: { string: true, describe: '创建所需要 app 自定义模版名称', default: '' } }, newApp)
  .command<ArgvBuilder>('build', '构建指定 app 的服务端 和 客户端代码', builder, build)
  .command<ArgvBuilder>('buildAll', '构建所有 app 的服务端和客户端代码，可通过 apps 参数指定需要构建的 app', builder, buildAll)
  .command<ArgvBuilder>('list', '根据目录结构打印 app 列表', builder, list)
  .command<ArgvBuilder>('clean', '删除指定 app 的构建产物', { ...builder, clean: { boolean: true, describe: '删除指定 app 的构建产物', default: true } }, clean)
  .command<ArgvBuilder>(['prod', 'start'], '启动生产环境服务端渲染服务', {
  ...builder,
  cluster: {
    boolean: true,
    describe: '是否启用多进程模型 cluster 启动服务，默认关闭',
    default: false
  }
}, start)
  .demandCommand(1, 'You need at least one command before moving on')
  .fail((msg, err) => {
    if (err) {
      console.log(err)
      process.exit(1)
    }
    msg && console.log(msg)
  })
  .parse()
