import { Argv } from '@zh-mix/types'
import cleanAll from './cleanAll'
import * as debug from 'debug'
import { isType } from './../utils'

export default async function dev (argv: Argv): Promise<void> {
  // NOTE: 删除所有的历史构建产物 原因
  // 1. 开发阶段的静态资源因为存在runtime阶段有 js 加载的情况，如果用 webpack-dev-server 未找到设置加载前缀设置的地方
  // 2. 所以开发阶段的静态资源全部使用 server proxy 来代理，具体查看: utils/devStaticProxy
  // 3. 如果要实现多 app dev 启动，不能直接设置 webpack 多入口打包，因为是通过别名设置的打包不同 app，需要启动多个 webpack 构建进程
  await cleanAll(argv)

  process.env.NODE_ENV = 'development'

  const log = debug('脚手架 (开发模式)')
  log.enabled = true

  const { parseFeRoutes, transformConfig, getBuildAppName, loadPlugin, copyReactContext, transformProjectConfig, getCwd, loadConfig } = await import('@zh-mix/utils')

  const env = await import('dotenv')
  env.config({ path: require('path').resolve(getCwd(), './.env.local.development') })

  // NOTE: 优先取 cli 命令传入的 app，再取环境变量
  const app = (argv.app || getBuildAppName()) as string

  if (argv.analyzer) {
    log('🍨 已经开启代码包大小分析，服务端默认端口 8900，客户端默认端口 8901，将自动打开浏览器')
    process.env.GENERATE_ANALYSIS = 'true'
  }

  if (!app) {
    log('🍨 请设置需要启动的 APP 名称')
    return
  }

  log(`🍨 启动 ${app} 的构建服务`)

  await Promise.all([transformProjectConfig(), transformConfig(app)])

  await parseFeRoutes(app)

  const plugin = loadPlugin()

  if (!isType(plugin?.clientPlugin, 'Object') || !isType(plugin?.serverPlugin, 'Object')) {
    log('🍨 「错误」 插件配置错误，插件应该是一个对象')
    console.log(plugin)
    return
  }

  log(`🍨 加载客户端插件 ${plugin.clientPlugin?.name ?? '(插件未设置昵称)'}，服务端插件 ${plugin.serverPlugin?.name ?? '(插件未设置昵称)'}`)

  if (plugin.clientPlugin?.name === 'plugin-react') {
    await copyReactContext(app)
  }

  await plugin.clientPlugin?.dev?.(app, argv)

  const { static: isStaticPage } = loadConfig(app)
  if (!isStaticPage) {
    await plugin.serverPlugin?.dev?.(app, argv)
  }
}
