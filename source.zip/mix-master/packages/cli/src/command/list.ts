import { Argv } from '@zh-mix/types'
import * as debug from 'debug'
import { listApp } from './../utils'

export default async function list (argv: Argv): Promise<void> {
  const log = debug('脚手架 (获取 APP 列表)')
  log.enabled = true

  const apps = await listApp()
  apps.forEach((app, index) => log(`[${index + 1}] - ${app}`))

  log(`共 ${apps.length} 个 app`)
}
