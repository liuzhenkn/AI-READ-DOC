import { Argv } from '@zh-mix/types'
import clean from './clean'
import { isType } from './../utils'
import { join } from 'path'
import { outputDirName, serverOutputDirName } from '@zh-mix/utils/cjs/constants'

const transformProjectConfig = async () => {
  const { transformProjectConfig, getCwd, accessFileSync } = await import('@zh-mix/utils')

  const buildOutDir = join(getCwd(), `./${outputDirName}`)
  const outfile = join(buildOutDir, `./${serverOutputDirName}`, './project.config.js')

  if (!accessFileSync(outfile)) {
    console.log('项目配置不存在，进行项目配置构建')
    await transformProjectConfig()
  }
}

export default async function build (argv: Argv): Promise<void> {
  process.env.NODE_ENV = 'production'

  await clean(argv)

  if (argv.analyzer) { process.env.GENERATE_ANALYSIS = 'true' }

  const { parseFeRoutes, transformConfig, getBuildAppName, loadPlugin, copyReactContext, loadConfig } = await import('@zh-mix/utils')

  // NOTE: 优先取 cli 命令传入的 app，再取环境变量
  const app = (argv.app || getBuildAppName()) as string

  if (!app) {
    console.log('请设置需要启动的 APP 名称')
    return
  }

  await transformProjectConfig()
  await transformConfig(app)
  await parseFeRoutes(app)
  const plugin = loadPlugin()

  if (!isType(plugin?.clientPlugin, 'Object') || !isType(plugin?.serverPlugin, 'Object')) {
    const msg = '「错误」 插件配置错误，插件应该是一个对象'
    console.log(plugin)
    throw new Error(msg)
  }

  if (plugin.clientPlugin?.name === 'plugin-react') {
    await copyReactContext(app)
  }

  await plugin.clientPlugin?.build?.(app, argv)

  const { static: isStaticPage } = loadConfig(app)
  if (!isStaticPage) {
    await plugin.serverPlugin?.build?.(app, argv)
  }
}
