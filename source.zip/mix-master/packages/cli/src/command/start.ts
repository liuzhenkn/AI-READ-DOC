import { Argv } from '@zh-mix/types'
import * as debug from 'debug'
import * as os from 'os'
import util from 'util'
import type { Worker } from 'cluster'
import { resolve } from 'path'

const cfork = require('cfork')

export default async function (argv: Argv) {
  const log = debug('Server CLI')
  log.enabled = true

  const { loadPlugin, getCwd } = await import('@zh-mix/utils')
  const plugin = loadPlugin()

  let serverEntry = ''

  if (plugin.serverPlugin?.name === 'plugin-koa') {
    serverEntry = resolve(getCwd(), './node_modules/@zh-mix/core-koa/cjs/server.js')
  }

  if (!serverEntry) {
    log('未找到插件入口，服务启动失败')
    return
  }

  // 当 cli 有传入参数时，优先取 cli 参数，再取 CONTAINER_NAME 环境变量
  const container = argv?.container ? (argv.container as string) : (process.env.CONTAINER_NAME ?? '')
  container && log(`当前启动的容器名称为 ${container}`)

  if (!argv.cluster) {
    log(`服务入口为 ${serverEntry}, 未启用 cluster 模式，将以单进程启动服务`)
    process.env.NODE_ENV = 'production'
    process.env.CONTAINER_NAME = container
    require(serverEntry)

    return
  }

  const cpuNumbers = os.cpus().length // NOTE: 容器内获取的数量是整个物理机的，不能通过该方案获取

  log(`服务入口为 ${serverEntry}, 将启用 ${cpuNumbers} 个进程 (取 cpu 内核数目)`)

  cfork({
    exec: serverEntry,
    count: cpuNumbers,
    env: {
      NODE_ENV: 'production',
      CONTAINER_NAME: container
    }
  })
    .on('fork', (worker: Worker) => {
      log(`${Date()} 启动服务进程 [${worker.process.pid}]`)
    })
    .on('disconnect', (worker: Worker) => {
      console.warn(
        '[%s] [master:%s] wroker:%s disconnect, exitedAfterDisconnect: %s.',
        Date(),
        process.pid,
        worker.process.pid,
        worker.exitedAfterDisconnect
      )
    })
    .on('exit', (worker: Worker, code: number, signal: string) => {
      const exitCode = worker.process.exitCode
      const err = new Error(
        util.format(
          'worker %s died (code: %s, signal: %s, exitedAfterDisconnect: %s)',
          worker.process.pid,
          exitCode,
          signal,
          worker.exitedAfterDisconnect
        )
      )
      err.name = 'WorkerDiedError'
      console.error('[%s] [master:%s] wroker exit: %s', Date(), process.pid, err.stack)
    })
}
