import { Argv } from '@zh-mix/types'
import { rm } from 'shelljs'
import * as debug from 'debug'

export default async function (argv: Argv) {
  const log = debug('脚手架 (开发模式)')
  log.enabled = true
  const { getOutputDir } = await import('@zh-mix/utils')
  const outputDir = getOutputDir()
  log(`删除历史构建 ${outputDir}/*`)
  rm('-rf', outputDir)
}
