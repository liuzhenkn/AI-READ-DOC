import { Argv } from '@zh-mix/types'
import { rm } from 'shelljs'
import * as debug from 'debug'

export default async function (argv: Argv) {
  const log = debug('脚手架 (开发模式)')
  log.enabled = process.env.NODE_ENV === 'development'

  const { getBuildOutput, getBuildAppName } = await import('@zh-mix/utils')

  // NOTE: 优先取 cli 命令传入的 app，再取环境变量
  const app = (argv.app || getBuildAppName()) as string

  if (!app) {
    log('🍨 请设置需要清理产物的 APP 名称')
    return
  }

  const outDir = getBuildOutput(app, false)

  if (argv.clean) {
    log(`🍨 清理 ${app} 的老版本构建产物`)
    rm('-rf', outDir.clientOutPut)
    rm('-rf', outDir.preBuildOutPut)
    rm('-rf', outDir.serverOutPut)
  }
}
