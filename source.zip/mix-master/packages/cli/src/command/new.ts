import { Argv } from '@zh-mix/types'
import { join, resolve, dirname } from 'path'
import * as glob from 'glob'
import * as fs from 'fs'
import * as debug from 'debug'
import * as _ from 'lodash'

const log = debug('脚手架 (根据模版创建 app )')
log.enabled = true

export default async function (argv: Argv) {
  const { accessFileSync, getCwd } = await import('@zh-mix/utils')

  const { app, template } = argv

  if (!app || !template) {
    log('usage: pnpm mix new <app> <template>')
    return
  }

  const appNamePath = join(getCwd(), `apps/${app}`)
  const templateApp = join(getCwd(), `app-templates/${template}`)

  if (accessFileSync(appNamePath)) {
    log('应用已经存在，请勿重复创建')
    return
  }

  if (!accessFileSync(templateApp)) {
    log('项目模版不存在，请先自定义模版')
    return
  }

  const reg = /^[a-z0-9]+(-?[a-z0-9]+)+$/
  if (!reg.test(`${app}`)) {
    log('请用中划线的方式来命名,例如：hello-world')
    return
  }

  const files = glob.sync(`${templateApp}/**/@(.*|*.*)`, {
    dot: true,
    nodir: true
  })

  const render = (content: string) => {
    _.templateSettings.interpolate = /<%=([\s\S]+?)%>/g
    return _.template(content)({ name: `${app}` })
  }

  for (const file of files) {
    const relativePath = file.replace(`${templateApp}/`, '')
    const dist = resolve(appNamePath, relativePath)
    const content = fs.readFileSync(file, 'utf-8')
    try {
      fs.mkdirSync(dirname(dist), {
        recursive: true
      })
    } catch (err) {
      log('模版文件夹创建失败')
      return
    }
    fs.writeFileSync(dist, render(content), {
      encoding: 'utf-8',
      flag: 'w+'
    })
  }
}
