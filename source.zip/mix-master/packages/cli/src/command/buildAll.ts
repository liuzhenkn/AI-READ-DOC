import { Argv } from '@zh-mix/types'
import * as debug from 'debug'
import { listApp } from './../utils'
import * as os from 'os'

import concurrently from 'concurrently'

export default async function buildAll (argv: Argv): Promise<void> {
  const log = debug('buildAll')
  log.enabled = true

  let apps = argv.apps as string[]
  if (!apps?.length) {
    apps = await listApp()
  }

  const threads = os.cpus().length
  const maxProcesses = Math.min(Math.ceil(threads / 2), 12)
  const { transformProjectConfig, getCwd } = await import('@zh-mix/utils')

  log('🍨 构建项目配置')
  transformProjectConfig()

  log(`需要编译的 APP 有 ${apps.join(' ')} (总共 ${apps.length} 个)`)
  log(`cpu 内核为 ${threads}，最大可启用 ${maxProcesses} 个编译进程`)

  const shells = apps.map((name) => {
    return {
      name,
      command: `mix build --app ${name}`
    }
  })

  try {
    const start = Date.now()

    const { result } = concurrently(shells, {
      prefix: '[{time} pid: {pid}] {name} => ',
      killOthers: ['failure'],
      restartTries: 1,
      maxProcesses,
      cwd: getCwd(),
      timestampFormat: 'HH:mm:ss'
    })

    await result

    log(`构建成功，耗时 ${Date.now() - start} ms`)
    process.exit(0)

  } catch (error) {
    log('🍨 构建失败，CloseEvent ↓')
    console.log(error)
    process.exit(1)
  }

}
