export const CSR_DOWNGRADE_EVENT = 'csr_downgrade'
