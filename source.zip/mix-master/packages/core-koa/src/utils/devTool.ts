import * as Koa from 'koa'
import type { ServerAppsConfig } from '@zh-mix/types'
import { isDev } from './helper'
import { getDevProxyMiddlewaresArr } from '@zh-mix/utils'

const devTool = (app: Koa<Koa.DefaultState, Koa.DefaultContext>, appsConfig: ServerAppsConfig) => {
  const dev = isDev()
  if (!dev) {
    return
  }

  appsConfig.forEach(_ => {
    getDevProxyMiddlewaresArr(_.config, { express: false }).forEach(middleware => {
      app.use(middleware)
    })
  })
}

export default devTool
