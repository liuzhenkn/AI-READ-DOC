import { ServerAppsConfig } from '@zh-mix/types'
import * as Router from 'koa-router'
import { render } from './render'
import * as compose from 'koa-compose'

async function initSsrRouter (appsConfig: ServerAppsConfig) {
  const router = new Router()
  for (const app of appsConfig) {
    if (app.url?.length) {

      const renderCompose = compose(await Promise.all([app.beforeRender, render, app.afterRender]
        .filter(fn => typeof fn === 'function')
        .map(fn => {
          return fn!(app)
        })))

      router.get(app.url, renderCompose)
    }
  }

  return router.routes()
}

export { initSsrRouter }
