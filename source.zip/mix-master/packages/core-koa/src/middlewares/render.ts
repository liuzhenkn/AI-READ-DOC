import { render as reactRender } from '@zh-mix/core-react'
import { Context, Next, Middleware } from '~/typings/app'
import { ServerAppConfig } from '@zh-mix/types'
import { Readable } from 'stream'
import { judgeFramework } from '@zh-mix/utils'
import { CSR_DOWNGRADE_EVENT } from './../utils/events'

function render (app: ServerAppConfig) {

  return async function render (ctx: Context<string | Readable>, next: Next) {

    const frame = judgeFramework()

    if (frame === 'react') {

      if (app.config.stream) {

        const stream = await reactRender<Readable>(ctx, app, {
          stream: true, // NOTE: stream 为异步返回的，所以 afterRender 执行时，用户可能还在 stream 传输中
          mode: 'ssr'
        })

        // NOTE: 能捕获到 renderToNodeStream JSX 2 Stream 过程中的异常
        // 但是非渲染过程，比如 fetch 中的异常是捕获不到的 (比如 401)
        stream.on('error', async (error) => {
          stream.destroy()
          const renderToString = await reactRender<string>(ctx, app, {
            // 这里只能用 string 形式来渲染 koa 无法二次赋值 stream 给 body
            stream: false,
            mode: 'csr'
          })

          ctx.app.emit(CSR_DOWNGRADE_EVENT, app.name, error)

          ctx.res.end(renderToString)
        })

        ctx.body = stream
      } else { // 非 stream 形式
        try {
          ctx.body = await reactRender<string>(ctx, app, { stream: false, mode: 'ssr' })
        } catch (error) {

          ctx.body = await reactRender<string>(ctx, app, { stream: false, mode: 'csr' })
          ctx.app.emit(CSR_DOWNGRADE_EVENT, app.name, error)
          throw error
        }
      }

    }

    await next()
  } as Middleware
}

export { render }
