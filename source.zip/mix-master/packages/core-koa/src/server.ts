import * as Koa from 'koa'
import { initSsrRouter } from './middlewares/router'
import { parseServerRoutes, getProjectConfig } from '@zh-mix/utils'
import devTool from './utils/devTool'

async function bootstrap () {
  const app = new Koa()
  const appsConfig = await parseServerRoutes()
  const projectConfig = getProjectConfig()

  devTool(app, appsConfig)

  if (typeof projectConfig.beforeRouterMiddleware === 'function') {
    app.use(await projectConfig.beforeRouterMiddleware(app))
  }

  app.use(await initSsrRouter(appsConfig))

  if (typeof projectConfig.afterRouterMiddleware === 'function') {
    app.use(await projectConfig.afterRouterMiddleware(app))
  }

  app.listen(projectConfig.serverPort)
}

bootstrap()
