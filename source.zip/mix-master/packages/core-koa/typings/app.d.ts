import * as Koa from 'koa'
import { ISSRContext } from '@zh-mix/types'

export type Context<ResponseBodyT> = ISSRContext<Koa.ParameterizedContext<Koa.DefaultState, Koa.DefaultContext, ResponseBodyT>>
export type Next = Koa.Next

export type Middleware = Koa.Middleware