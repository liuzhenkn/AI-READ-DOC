import { FC } from 'react'

const DefaultErrorPage: FC = () => {
  return (
    <div
      style={{
        width: '100vw',
        height: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
      }}
    >
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          flexDirection: 'column'
        }}
      >
        <img
          style={{ width: '160px' }}
          src="https://pic1.zhimg.com/v2-3b97dd07f73e0772cfabf5094ad81c7a.png"
        />
        <div
          style={{
            fontWeight: '500',
            fontSize: '16px',
            color: '#121212',
            marginTop: '40px'
          }}
        >
          网络开小差了，再试试吧
        </div>
      </div>
    </div>
  )
}

export default DefaultErrorPage
