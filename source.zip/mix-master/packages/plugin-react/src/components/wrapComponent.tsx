import * as React from 'react'
import { useContext, useEffect, useState } from 'react'
import type { DynamicFC, StaticFC, Action, IWindow, ReactESMFetch, ReactFetch, RouteComponentProps, ReactRoutesType } from '@zh-mix/core-react'
import { getUrlParams } from '@zh-mix/utils/esm/client'
import DefaultErrorPage from './DefaultErrorPage'

// @ts-expect-error
import * as MixRoutes from '_build/mix-temporary-routes'
// @ts-expect-error
import { STORE_CONTEXT } from '_build/create-context.ts'

const { ErrorPage } = MixRoutes as ReactRoutesType

declare const window: IWindow

let hasRender = false

interface fetchType {
  fetch?: ReactESMFetch
  layoutFetch?: ReactFetch
}

const fetchAndDispatch = async ({ fetch, layoutFetch }: fetchType, dispatch: React.Dispatch<Action>, routerProps: any, state: any) => {
  let asyncLayoutData = {}
  let asyncData = {}
  if (layoutFetch) {
    asyncLayoutData = await layoutFetch({ routerProps, state })
  }
  if (fetch) {
    const fetchFn = await fetch()
    asyncData = await fetchFn.default({ routerProps, state })
  }

  const combineData = Object.assign({}, asyncLayoutData, asyncData)

  await dispatch({
    type: 'updateContext',
    payload: combineData
  })
}

function wrapComponent (WrappedComponent: DynamicFC<RouteComponentProps> | StaticFC<RouteComponentProps>, url: string) {
  return () => {

    const routerProps = {
      params: getUrlParams(url)
    }

    const [ready, setReady] = useState(WrappedComponent.name !== 'dynamicComponent')
    const [downgradeError, setDowngradeError] = useState<unknown>()
    const { state, dispatch } = useContext(STORE_CONTEXT)

    useEffect(() => {
      didMount()
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    const didMount = async () => {
      if (hasRender || !window.__USE_SSR__) {
        // ssr 情况下只有路由切换的时候才需要调用 fetch
        // csr 情况首次访问页面也需要调用 fetch
        const { fetch, layoutFetch } = (WrappedComponent as DynamicFC)

        try {
          await fetchAndDispatch({ fetch, layoutFetch }, dispatch, routerProps, state)
        } catch (error) {
          setDowngradeError(error)
          setReady(true)
          hasRender = true
          throw error
        }

        if (WrappedComponent.name === 'dynamicComponent') {
          WrappedComponent = (await (WrappedComponent as DynamicFC)()).default
          WrappedComponent.fetch = fetch
          WrappedComponent.layoutFetch = layoutFetch
          setReady(true)
        }
      }
      hasRender = true
    }

    if (downgradeError && ready) {
      return ErrorPage ? <ErrorPage downgradeErr={downgradeError} path={url} {...routerProps} /> : <DefaultErrorPage />
    }

    return (
      ready ? <WrappedComponent {...routerProps}></WrappedComponent> : null
    )
  }
}

export {
  wrapComponent
}
