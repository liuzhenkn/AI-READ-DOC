export const SsrDownGradeRemindWaterMark = () => {

  const WATER_MARK_COLUMN = 9
  const waterMarkList = Array.from({ length: WATER_MARK_COLUMN })

  return (
    <div style={{
      position: 'fixed',
      color: 'red',
      fontSize: '15px',
      lineHeight: '100%',
      zIndex: '99999',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'stretch',
      top: 0,
      left: 0,
      bottom: 0,
      right: 0,
      opacity: '0.1',
      pointerEvents: 'none'
    }}>
      {waterMarkList.map((_, parentIndex) => (
          <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'space-around' }} key={parentIndex}>
            {waterMarkList.map((_, index) => (
              <div key={index} style={{ transform: 'rotate(30deg)' }}>
                <span>SSR 渲染降级</span>
              </div>
            ))}
          </div>
      ))}
    </div>
  )
}
