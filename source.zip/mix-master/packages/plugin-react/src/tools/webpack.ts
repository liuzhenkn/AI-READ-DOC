import * as WebpackChain from '@gem-mine/webpack-chain'
import { loadConfig } from '@zh-mix/utils'

export const webpackDev = async (app: string) => {
  const { startClientServer, startServerWatch } = await import('@zh-mix/webpack')

  const { static: isStaticPage } = loadConfig(app)

  /** ------ client ------ */
  const clientConfigChain = new WebpackChain()
  const { getClientWebpack } = await import('../webpackConfig')
  const clientChain = getClientWebpack(clientConfigChain, app)

  const clientProcess = startClientServer(clientChain.toConfig(), app)

  /** ------ server ------ */
  let serverProcess = Promise.resolve()
  if (!isStaticPage) {
    const serverConfigChain = new WebpackChain()
    const { getServerWebpack } = await import('../webpackConfig')
    const serverChain = getServerWebpack(serverConfigChain, app)
    serverProcess = startServerWatch(serverChain.toConfig(), app)
  }

  await Promise.all([clientProcess, serverProcess])
}

export const webpackBuild = async (app: string) => {
  const { startClientBuild, startServerBuild } = await import('@zh-mix/webpack')

  const { static: isStaticPage } = loadConfig(app)

  /** ------ client ------ */
  const clientConfigChain = new WebpackChain()
  const { getClientWebpack } = await import('../webpackConfig')
  const clientChain = getClientWebpack(clientConfigChain, app)

  const clientProcess = startClientBuild(clientChain.toConfig(), app)

  /** ------ server ------ */
  let serverProcess = Promise.resolve()
  if (!isStaticPage) {
    const serverConfigChain = new WebpackChain()
    const { getServerWebpack } = await import('../webpackConfig')
    const serverChain = getServerWebpack(serverConfigChain, app)
    serverProcess = startServerBuild(serverChain.toConfig(), app)
  }

  await Promise.all([clientProcess, serverProcess])
}
