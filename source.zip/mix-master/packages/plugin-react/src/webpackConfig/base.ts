import { join } from 'path'
import * as WebpackChain from '@gem-mine/webpack-chain'
import { Mode } from '@zh-mix/types'
import { loadConfig, getCwd, getLocalNodeModules } from '@zh-mix/utils'
import * as webpack from 'webpack'
import { addBabelChain, addFontsChain, addImageChain, addStyleChain, addSvgComponentChain } from '@zh-mix/webpack'

const WebpackBar = require('webpackbar')

const BundleAnalyzerPlugin = require('webpack-bundle-analyzer').BundleAnalyzerPlugin

const generateAnalysis = Boolean(process.env.GENERATE_ANALYSIS)

const getBaseConfig = (chain: WebpackChain, isServer: boolean, app: string) => {
  const appConfig = loadConfig(app)
  const { isDev, alias, chainBaseConfig, moduleFileExtensions } = appConfig

  chain.bail(!isDev)

  const mode = process.env.NODE_ENV as Mode

  chain.mode(mode)
  chain.devtool(isDev ? 'cheap-module-source-map' : 'source-map')

  chain.when(isDev, chain => {
    chain.cache({
      type: 'filesystem',
      buildDependencies: {
        config: [__filename]
      },
      name: `${app}~${isServer ? 'server' : 'client'}`
    })
      .infrastructureLogging({
        // NOTE: 仅仅显示错误与告警
        level: 'warn'
      })

  }).end()

  chain
    .resolve
    .modules
    .add('node_modules')
    .add(join(getCwd(), './node_modules'))
    .when(isDev, chain => {
      chain.add(getLocalNodeModules())
    })
    .end()
    .extensions.merge(moduleFileExtensions)
    .end()
    .alias
    .end()

  alias && Object.keys(alias).forEach(item => {
    chain.resolve.alias
      .set(item, alias[item])
  })

  addBabelChain(chain, app, isServer)
  addFontsChain(chain, isServer)
  addImageChain(chain, isServer, app)
  addSvgComponentChain(chain)

  addStyleChain(chain, /\.css$/, {
    rule: 'css',
    isServer,
    importLoaders: 1
  }, app, isServer)

  addStyleChain(chain, /\.less$/, {
    rule: 'less',
    loader: 'less-loader',
    isServer,
    importLoaders: 2
  }, app, isServer)

  chain.when(generateAnalysis, chain => {
    chain.plugin('analyze').use(BundleAnalyzerPlugin, [{ analyzerPort: isServer ? 8900 : 8901, logLevel: 'warn' }])
  })

  chain.plugin('mixDefine').use(webpack.DefinePlugin, [{
    __isBrowser__: !isServer
  }])

  chain.plugin('webpackBar').use(new WebpackBar({
    color: !isServer ? '#4587EF' : '#F3CF60',
    name: !isServer ? '客户端构建' : '服务端构建'
  }))

  chainBaseConfig(chain, isServer, app)
  return appConfig
}

export {
  getBaseConfig
}
