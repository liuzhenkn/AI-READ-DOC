import { parseNotImportRouterFlag, getCwd } from '@zh-mix/utils'
import { join } from 'path'
import type { IConfig } from '@zh-mix/types'
import * as WebpackChain from '@gem-mine/webpack-chain'
import * as debug from 'debug'

const getReactRouter = (app: string, useReactRouter = false) => {
  const cwd = getCwd()
  const notImportRouterFlag = parseNotImportRouterFlag(app)

  if (notImportRouterFlag && !useReactRouter) {
    const emptyReactRouterDom = join(cwd, './node_modules/@zh-mix/plugin-react/esm/entry/empty-react-router-dom.js')
    return emptyReactRouterDom
  }
}

export const addReactRouterShakingChain = (chain: WebpackChain, appConfig: IConfig, app: string) => {
  const { useReactRouter } = appConfig

  const reactRouterDom = getReactRouter(app, useReactRouter)

  if (reactRouterDom) {
    const log = debug('客户端构建')
    log.enabled = true

    chain.resolve.alias.delete('react-router-dom')
    chain.resolve.alias.set('react-router-dom', reactRouterDom)

    log('🍨 该 app 只有一个页面，将移除 react-router 依赖，如果需要强制引入可以配置 useReactRouter 选项')
  }
}
