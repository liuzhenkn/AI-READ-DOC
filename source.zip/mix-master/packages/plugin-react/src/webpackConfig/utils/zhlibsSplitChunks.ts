// https://git.in.zhihu.com/cfe/verdaccio-config-zhihu/-/blob/master/config.yml

const zhihuNodeModules = [
  '@zhihu/',
  '@zhihu-',
  '@zh-',
  '@fe/',
  '@cfe/',
  '@efe/',
  '@ep/',
  '@sec/',
  '@kfe/',
  '@bit/',
  '@msfe/',
  '@msfe-',
  '@zhmp/',
  'zhihu-',
  'za-'
].join('|')

const zhihuNodeModulesRegExp = new RegExp(`[\\/]node_modules[\\/](${zhihuNodeModules})`)

/**
 * 判断是否为知乎 npm 包 & js，单独拆包
 * 降低 vendor hash 改变的频率，复用 CDN 缓存
 * @param module webpack cacheGroups 提供的参数，webpack 缺少这部分的类型定义
 */
export const getZhiHuLibsTest = (module: {resource?: string}) => {
  return module.resource &&
  /\.js$/.test(module.resource) &&
  zhihuNodeModulesRegExp.test(module.resource)
}

const zhihuNodeModulesAsync = [
  // mix-ui 中的空组件图片做了异步按需加载，框架层统一做一次拆包
  '@kfe/mix-ui/lib/esm/components/empty/images'
].join('|')

const zhihuNodeModulesAsyncRegExp = new RegExp(`[\\/]node_modules[\\/](${zhihuNodeModulesAsync})`)

/**
 * 将部分知乎内部可以异步加载按需加载的包或者文件，单独做拆包判断
 * @param module  webpack cacheGroups 提供的参数，webpack 缺少这部分的类型定义
 */
export const getZhiHuLibsTestAsync = (module: {resource?: string}) => {
  return module.resource &&
  /\.js$/.test(module.resource) &&
  zhihuNodeModulesAsyncRegExp.test(module.resource)
}
