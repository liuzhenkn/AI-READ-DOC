import { join } from 'path'
import * as WebpackChain from '@gem-mine/webpack-chain'
import { getBaseConfig } from './base'
import * as webpack from 'webpack'
import { getLocalNodeModules, getAppBase } from '@zh-mix/utils'

import * as nodeExternals from 'webpack-node-externals'
import { CrossAppDependentAnalysePlugin } from '@zh-mix/webpack'

const loadModule = require.resolve

const getServerWebpack = (chain: WebpackChain, app: string) => {
  const appConfig = getBaseConfig(chain, true, app)
  const { chunkName, getOutput, chainServerConfig, whiteList, cwd, isDev } = appConfig
  chain.target('node')

  chain.entry(chunkName)
    .add(loadModule('../entry/server-entry'))
    .end()
    .output
    .path(getOutput().serverOutPut)
    .filename('[name].server.js')
    .libraryTarget('commonjs')

  const modulesDir = [join(cwd, './node_modules')]
  modulesDir.push(getLocalNodeModules())
  // https://www.npmjs.com/package/webpack-node-externals ，use additionalModuleDirs
  chain.externals(nodeExternals({ allowlist: whiteList, additionalModuleDirs: modulesDir }))

  chain.plugin('serverLimit').use(webpack.optimize.LimitChunkCountPlugin, [{ maxChunks: 1 }])

  // NOTE: 禁用服务端代码压缩，便于服务端错误定位
  chain.optimization.minimize(false)

  isDev && chain
    .plugin('CrossAppDependentAnalyse')
    .use(CrossAppDependentAnalysePlugin, [{
      appBase: getAppBase(),
      appName: app
    }])

  chainServerConfig(chain, app) // 合并用户自定义配置
  return chain
}

export {
  getServerWebpack
}
