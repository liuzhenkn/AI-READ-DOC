import { promises } from 'fs'
import { resolve } from 'path'
import * as WebpackChain from '@gem-mine/webpack-chain'
import { getBaseConfig } from './base'
import { getOutputPublicPath, cryptoAsyncChunkName, getHtmlTemplatePath } from '@zh-mix/utils'
import { addReactRouterShakingChain } from './utils/reactRouterShaking'
import { getZhiHuLibsTest, getZhiHuLibsTestAsync } from './utils/zhlibsSplitChunks'

const ReactRefreshWebpackPlugin = require('@pmmmwh/react-refresh-webpack-plugin')
const { WebpackManifestPlugin } = require('webpack-manifest-plugin')
const CssMinimizerPlugin = require('css-minimizer-webpack-plugin')
const TerserPlugin = require('terser-webpack-plugin')

const loadModule = require.resolve
let asyncChunkMap: Record<string, string[]> = {}

const getClientWebpack = (chain: WebpackChain, app: string) => {
  const appConfig = getBaseConfig(chain, false, app)
  const { isDev, chunkName, getOutput, useHash, chainClientConfig, host, fePort, html } = appConfig

  const publicPath = getOutputPublicPath(app)

  chain.target('browserslist') // 取业务方的 browserslist 配置

  chain.entry(chunkName)
    .add(loadModule('../entry/client-entry'))
    .end()
    .output
    .path(getOutput().clientOutPut)
    .filename(useHash ? 'static/js/[name].[contenthash:8].js' : 'static/js/[name].js')
    .chunkFilename(useHash ? 'static/js/[name].[contenthash:8].chunk.js' : 'static/js/[name].chunk.js')
    .publicPath(publicPath)
    .end()

  const htmlTemplatePath = getHtmlTemplatePath(app, html?.template)
  htmlTemplatePath && chain.plugin('html').use(loadModule('html-webpack-plugin'), [
    Object.assign(
      {},
      {
        inject: true,
        template: htmlTemplatePath
      },
      !isDev
        ? {
            minify: {
              removeComments: true,
              collapseWhitespace: true,
              removeRedundantAttributes: true,
              useShortDoctype: true,
              removeEmptyAttributes: true,
              removeStyleLinkTypeAttributes: true,
              keepClosingSlash: true,
              minifyJS: true,
              minifyCSS: true,
              minifyURLs: true
            }
          }
        : undefined
      ,
      html
    )
  ])

  chain.optimization
    .runtimeChunk(true) // 当前配置生成的jsOrder: [`runtime~${chunkName}.js`, 'vendor.js', `${chunkName}.js`, 'zhlibs.js']
    .splitChunks({ // splitChunks，https://webpack.docschina.org/plugins/split-chunks-plugin/
      name (module: any, chunks: any, cacheGroupKey: string) {
        return cryptoAsyncChunkName(chunks, asyncChunkMap)
      },
      cacheGroups: {
        vendors: {
          chunks: 'all',
          priority: 0,
          test: (module: any) => {
            return module.resource &&
              /\.js$/.test(module.resource) &&
              module.resource.match('node_modules')
          },
          name: 'vendor'
        },
        zhlibs: {
          priority: 10,
          chunks: 'all',
          test: getZhiHuLibsTest,
          name: 'zhlibs'
        },
        zhlibsAsync: {
          priority: 20,
          chunks: 'async',
          test: getZhiHuLibsTestAsync
        }
      }
    })
    .when(!isDev, optimization => {
      // webpack 5 的 terser-webpack-plugin 开箱即用，无需配置：https://webpack.docschina.org/plugins/terser-webpack-plugin/
      // 不过 fork 了下 next 的压缩配置，另外可以考虑 minify: TerserPlugin.esbuildMinify (时间快，但是包可能稍大)
      optimization.minimizer('terser')
        .use(TerserPlugin, [{
          parallel: 2, // from xen
          terserOptions: { // https://github.com/vercel/next.js/blob/7db6aa2fde34699cf319d30980c2ee38bb53f20d/packages/next/build/webpack-config.ts#L663
            keep_fnames: true, // 由于代码里通过函数名称判断了 WrappedComponent.name，所以需要保留函数名称
            parse: {
              ecma: 8
            },
            compress: {
              ecma: 5,
              warnings: false,
              // The following two options are known to break valid JavaScript code
              comparisons: false,
              inline: 2, // https://github.com/vercel/next.js/issues/7178#issuecomment-493048965
              dead_code: true // (default: true) -- remove unreachable code
            },
            mangle: { safari10: true },
            output: {
              ecma: 5,
              safari10: true,
              comments: false,
              // Fixes usage of Emoji and certain Regex
              ascii_only: true
            }
          }
        }])

      // 使用 cssnano 优化和压缩 CSS：https://webpack.docschina.org/plugins/css-minimizer-webpack-plugin/
      // 配置了使用 esbuild 作为压缩工具
      optimization.minimizer('optimize-css').use(CssMinimizerPlugin, [{
        // esbuildMinify 进行压缩时会将 rgba 转换为 rrggbbaa 格式，导致在低端机型 rgba 展示色值失效，增加 minimizerOptions 中 target 属性来解决该问题
        // 因 esbuild taget 有自身定义规则，从 package 中读取 browserslist 值无法使用，所以直接传入 chrome61
        // 文档：https://esbuild.github.io/api/#target
        minimizerOptions: {
          target: 'chrome61'
        },
        minify: CssMinimizerPlugin.esbuildMinify
      }])
    })

  // process 环境变量应该使用 EnvironmentPlugin 来定义，实现在构建时替换
  // chain.plugin('provide').use(webpack.ProvidePlugin, [{
  //   process: loadModule('process/browser')
  // }])

  chain.plugin('manifest').use(WebpackManifestPlugin, [{
    fileName: 'asset-manifest.json',
    writeToFileEmit: true,
    removeKeyHash: false
  }])

  chain.plugin('WriteAsyncManifest').use(
    class WriteAsyncChunkManifest {
      apply (compiler: any) {
        compiler.hooks.watchRun.tap('thisCompilation', async () => {
          // 每次构建前清空上一次的 chunk 信息
          asyncChunkMap = {}
        })
        compiler.hooks.done.tapAsync(
          'WriteAsyncChunkManifest',
          async (params: any, callback: any) => {
            await promises.writeFile(resolve(
              getOutput().clientOutPut,
              './asyncChunkMap.json'),
            JSON.stringify(asyncChunkMap))
            callback()
          }
        )
      }
    }
  )

  chain.when(isDev, chain => {
    chain.plugin('fast-refresh').use(new ReactRefreshWebpackPlugin({
      overlay: {
        sockHost: host,
        sockPort: fePort
      }
    }))
  })

  addReactRouterShakingChain(chain, appConfig, app)

  chainClientConfig(chain, app) // 合并用户自定义配置
  return chain
}

export {
  getClientWebpack
}
