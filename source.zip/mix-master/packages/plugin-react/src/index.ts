import { IPlugin } from '@zh-mix/types'
import { webpackDev, webpackBuild } from './tools/webpack'

export function reactPlugin (): IPlugin['clientPlugin'] {
  return {
    name: 'plugin-react',
    dev: async (app) => {
      await webpackDev(app)
    },
    build: async (app) => {
      await webpackBuild(app)
    }
  }
}
