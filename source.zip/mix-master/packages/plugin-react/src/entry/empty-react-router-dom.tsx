import * as React from 'react'

import type {
  BrowserRouterProps,
  PathRouteProps,
  RoutesProps
} from 'react-router-dom'

export const BrowserRouter = ({ basename, children, window }: BrowserRouterProps): JSX.Element => {
  return (<>{children}</>)
}

export const Route = (_props: PathRouteProps): React.ReactElement => {
  return (<>{_props.element}</>)
}

export const Routes = ({ children, location }: RoutesProps): React.ReactElement => {
  return (<>{children}</>)
}
