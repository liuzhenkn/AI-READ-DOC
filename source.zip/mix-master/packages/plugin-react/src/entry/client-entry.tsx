import * as ReactDOM from 'react-dom'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
// @ts-expect-error
import * as MixRoutes from '_build/mix-temporary-routes'
import type { IWindow, LayoutProps, ReactRoutesType, ReactESMPreloadFeRouteItem, ReactESMFeRouteItem } from '@zh-mix/core-react'
import { normalizeClientPath, pathIsMatch } from '@zh-mix/utils/esm/client'
import { wrapComponent } from './../components/wrapComponent'
import { AppContext } from './context'

import { HelmetProvider } from '@zh-mix-mkt/react-helmet'

const { FeRoutes, layoutFetch, App, PrefixRouterBase } = MixRoutes as ReactRoutesType

declare const window: IWindow

const preloadComponent = async (Routes: ReactESMPreloadFeRouteItem[], PrefixRouterBase?: string) => {
  for (const route of Routes) {
    const { component, path } = route
    let pathname = location.pathname
    if (PrefixRouterBase) {
      pathname = normalizeClientPath(pathname, PrefixRouterBase)
    }

    // 只有服务端渲染情况下预加载页面组件，防止渲染不一致
    if (component.name === 'dynamicComponent' && pathIsMatch(path, pathname) && window.__USE_SSR__) {
      route.component = (await (component as ReactESMFeRouteItem['component'])()).default
    }
  }
  return Routes
}

const clientRender = async (): Promise<void> => {
  const IApp = App ?? function (props: LayoutProps) {
    return props.children!
  }
  // 客户端渲染||hydrate
  const baseName = window.prefix ?? PrefixRouterBase

  // 当前做服务端加载的页面，需要预加载组件，不然服务端渲染和客户端渲染会不一致，客户端渲染(含降级时) 不做组件预加载
  const routes = await preloadComponent(FeRoutes, baseName)

  const helmetContext = {}

  ReactDOM[window.__USE_SSR__ ? 'hydrate' : 'render'](
    <BrowserRouter basename={baseName}>
      <AppContext>
        <HelmetProvider context={helmetContext}>
          <IApp>
            <Routes>
              {
                // 使用高阶组件wrapComponent使得csr首次进入页面以及csr/ssr切换路由时调用getInitialProps
                routes.map(item => {
                  const { fetch, component, path } = item
                  component.fetch = fetch
                  component.layoutFetch = layoutFetch
                  const WrappedComponent = wrapComponent(component, `${baseName}${path}`)

                  const optionalRegex = /\/(:\w+)\?$/
                  const optionalGroup = path.match(optionalRegex)
                  // 含有可选参数 https://github.com/remix-run/react-router/issues/7285
                  if (optionalGroup) {
                    return (
                      <Route key={path} path={path.replace(optionalRegex, '')}>
                        <Route path={optionalGroup[1]} element={<WrappedComponent />} />
                        <Route path='' element={<WrappedComponent />} />
                      </Route>
                    )
                  }

                  return <Route key={path} path={path} element={<WrappedComponent />} />
                })
              }
            </Routes>
          </IApp>
        </HelmetProvider>
      </AppContext>
    </BrowserRouter>
    , document.getElementById('app'))
}

clientRender()

export {
  clientRender
}
