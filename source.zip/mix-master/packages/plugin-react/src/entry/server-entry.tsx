import * as React from 'react'
import { StaticRouter } from 'react-router-dom/server'
import * as serialize from 'serialize-javascript'
// @ts-expect-error
import * as Routes from '_build/mix-temporary-routes'

// @ts-expect-error
import { STORE_CONTEXT as Context } from '_build/create-context'
// @ts-expect-error
import Layout from '@/components/layout/index.tsx'

import { HelmetProvider, HelmetServerState } from '@zh-mix-mkt/react-helmet'
import { CssCritical, LoadCSS } from '@zh-mix-mkt/react-css-critical'

import type { IConfig } from '@zh-mix/types'
import type { ISSRContext, ReactESMFeRouteItem, ReactRoutesType, RouteComponentProps } from '@zh-mix/core-react'

import { normalizeSSrPath, getManifest, addAsyncChunk } from '@zh-mix/utils/cjs/server'
import { findRoute } from '@zh-mix/utils/cjs/findRoute'
import { SsrDownGradeRemindWaterMark } from '../components/SsrDownGradeRemindWaterMark'

const { FeRoutes, layoutFetch, PrefixRouterBase, state } = Routes as ReactRoutesType

interface IContext {params: RouteComponentProps['params']}

/**
 * 获取 动态路由参数 + GET query 参数
 * 不同框架可能有不同的获取方式，koa 配合 koa router 通过 ctx.params 和 ctx.request.query 获取
 * @param ctx context
 * @returns Url 参数
 */
const getUrlParams = (ctx: ISSRContext<IContext>) => {
  return { ...ctx.params, ...ctx.request.query }
}

type HelmetServerStateType = Partial<HelmetServerState>

const serverRender = async (ctx: ISSRContext<IContext>, config: IConfig): Promise<{
  helmet: HelmetServerStateType
  element: React.ReactElement
  inlineStyles: string[]}
> => {
  const { mode, parallelFetch, prefix, cssOrder, jsOrder, dynamic, isDev, cssCritical, stream } = config
  const isCsr = !!(mode === 'csr' || ctx.request.query?.csr)
  const dataType = ctx.request.query?.data_type

  // ZAE_ENV_TYPE 为编译时环境变量
  const isPreEnv = process.env.ZAE_ENV_TYPE === 'pre'

  let path = ctx.request.path // 这里取 pathname 不能够包含 queryString

  const base = prefix ?? PrefixRouterBase // 以开发者实际传入的为最高优先级
  if (base) {
    path = normalizeSSrPath(path, base)
  }

  const routeItem = findRoute<ReactESMFeRouteItem<Partial<IContext>>>(FeRoutes, path)

  if (!routeItem) {
    throw new Error(` 查找组件失败，请确认当前 path: ${path} 对应前端组件是否存在，若创建了新的页面文件夹，请重新执行 npm run dev 重启服务`)
  }

  const { component, fetch } = routeItem
  const Component = isCsr ? React.Fragment : (await component()).default

  const helmetContext: HelmetServerStateType = {}

  // 需要通过 style 标签注入 html 模块的 css 字符串
  const inlineStyles: string[] = []

  const enableCssCritical = !!cssCritical && !stream

  let layoutFetchData = {}
  let fetchData = {}
  let routerProps = {}

  if (!isCsr) {
    routerProps = { params: getUrlParams(ctx) } // 动态路由参数 + GET query 参数
    const fetchParams = {
      ctx,
      routerProps
    }

    const currentFetch = fetch ? (await fetch()).default : null
    if (parallelFetch) {
      [layoutFetchData, fetchData] = await Promise.all([
        layoutFetch ? layoutFetch(fetchParams) : Promise.resolve({}),
        currentFetch ? currentFetch(fetchParams) : Promise.resolve({})
      ])
    } else {
      layoutFetchData = layoutFetch ? await layoutFetch(fetchParams) : {}
      fetchData = currentFetch ? await currentFetch(fetchParams) : {}
    }
  }
  // NOTE: 单纯查看服务端数据，直接返回数据
  if (dataType === 'json' && !isCsr) {

    const element = <>{serialize(Object.assign({}, layoutFetchData ?? {}, fetchData ?? {}))}</>

    return {
      helmet: helmetContext,
      inlineStyles,
      element
    }
  }

  const combineData = isCsr ? null : Object.assign(state ?? {}, layoutFetchData ?? {}, fetchData ?? {})

  const injectState = isCsr
    ? null
    : <script dangerouslySetInnerHTML={{
      __html: `window.__USE_SSR__=true; window.__INITIAL_DATA__ =${serialize(combineData)}`
    }} />

  if (isCsr) { console.log(`Current path ${path} use csr render mode`) }

  const manifest = getManifest(config)
  const injectScript = [...jsOrder.map(js => manifest[js]).map(item => item && <script src={item} key={item} />)]

  // 当 enableCssCritical 未开启时，使用 injectCss 直接返回需要同步注入的 CSS 给业务方
  const injectCss: JSX.Element[] = []

  // 当 enableCssCritical 开启后，通过 JS 来创建 css link，避免样式加载阻塞页面渲染
  const injectCssAsyncUrls: string[] = []

  // 1. 组件的 css 文件大于 webpack 拆包阈值，并且该文件超过 2 次引用，将被单独拆包
  // 2. 对于这类 css 将使用 JS 加载，导致页面闪烁，故将这些 css 提到 html 层面加载
  let dynamicCssOrder = cssOrder

  if (dynamic) {
    dynamicCssOrder = cssOrder.concat([`${routeItem.webpackChunkName}.css`])
    dynamicCssOrder = await addAsyncChunk(dynamicCssOrder, routeItem.webpackChunkName, config)
  }

  dynamicCssOrder.forEach(css => {
    if (manifest[css]) {
      const item = manifest[css]
      // NOTE: 当渲染降级时，因为页面节点在服务端本身是不做渲染的，故不会收集到页面的 CSS 字符串
      // 如果使用异步方案来加载 CSS，可能出现客户端渲染完成了
      // 但是 CSS 还没加载的情况，故当发生渲染降级时，将关闭 CSS 首屏优化策略，仍然使用同步 CSS 链接加载样式
      if (enableCssCritical && !isCsr) {
        injectCssAsyncUrls.push(item)
      } else {
        injectCss.push(<link rel='stylesheet' href={item} key={item} />)
      }
    }
  })

  // 当 injectCssAsyncUrls 存在的情况下通过 LoadCSS 脚本来加载 CSS 文件
  if (injectCssAsyncUrls.length) {
    injectScript.unshift(<LoadCSS key="loadCSS" CssLinks={injectCssAsyncUrls} />)
  }

  // NOTE: 遍历 cssOrder 或 jsOrder 来判断首次要加载哪些资源，而不是 manifest，因为 manifest 中存在是需要通过异步加载的资源
  const staticList = {
    injectCss,
    injectScript
  }

  return {
    helmet: helmetContext,
    inlineStyles: isCsr ? [] : inlineStyles,
    element: (
      <StaticRouter location={ctx.request.url} basename={base}>
        <Context.Provider value={{ state: combineData }}>
          <HelmetProvider context={{ ...helmetContext }}>
            <CssCritical enable={enableCssCritical} inlineStyles={inlineStyles}>
              <Layout ctx={ctx} config={config} staticList={staticList} injectState={injectState}>
                <Component {...routerProps} />
              </Layout>

              {/* 当渲染降级时，开发环境、联调环境展示水印 */}
              {isCsr && (isDev || isPreEnv) && (
                <SsrDownGradeRemindWaterMark />
              )}
            </CssCritical>
          </HelmetProvider>
        </Context.Provider>
      </StaticRouter>
    )
  }
}

const getUrl = (config: IConfig) => {
  const { prefix } = config
  const prefixUrl = normalizeSSrPath(prefix).replace(/\/$/, '') // 前面加 / 后面不加 /，比如 /x

  return FeRoutes.map(route => {
    if ((route.path === '/index' || route.path === '/')) {
      return prefixUrl
    }

    return prefixUrl + normalizeSSrPath(route.path)
  })
}

export {
  serverRender,
  getUrl
}
