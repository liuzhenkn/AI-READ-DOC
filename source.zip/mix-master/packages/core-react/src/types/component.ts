import type { ReactChild } from 'react'
import type { RouteComponentProps } from './route'

type IProps<T={}> = T & {
  children: ReactChild
}

type SProps<T={}> = T & RouteComponentProps

interface Action {
  type: string
  payload: object
}

export {
  IProps,
  Action,
  SProps
}
