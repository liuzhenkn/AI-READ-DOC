import { ISSRContext, IConfig } from '@zh-mix/types'
import type { Action } from './component'

export interface RouteComponentProps {
  params?: Record<string, any>
}

export interface LayoutProps {
  ctx?: ISSRContext
  config?: IConfig
  children?: JSX.Element
  staticList?: StaticList
  injectState?: any
}

export interface DowngradeErrorComponentProps extends RouteComponentProps {
  path?: string
  downgradeErr?: unknown
}

export interface StaticList {
  injectCss: JSX.Element[]
  injectScript: JSX.Element[]
}

export interface ProvisionalFeRouteItem {
  path?: string
  layout: string
  fetch?: string
  component?: string
}

export interface Params<T> {
  ctx?: ISSRContext<T>
  routerProps?: RouteComponentProps
  state?: any
}

export type ReactFetch<T={}> = (params: Params<T>) => Promise<any>

export type ReactESMFetch = () => Promise<{
  default: ReactFetch
}>

export type ESMLayout = () => Promise<React.FC<LayoutProps>>

export interface StaticFC<T={}> extends React.FC<T> {
  fetch?: ReactESMFetch
  layoutFetch?: ReactFetch
}

export interface DynamicFC<T = {}> extends React.FC<T>{
  (): Promise<{
    default: StaticFC<T>
  }>
  name: 'dynamicComponent'
  fetch?: ReactESMFetch
  layoutFetch?: ReactFetch
}

export type ReactESMFeRouteItem<T = {}, U={}> = {
  path: string
  fetch?: ReactESMFetch
  component: DynamicFC<T>
  webpackChunkName: string
} & U

export type ReactESMPreloadFeRouteItem<T = {}, U={}> = Pick<ReactESMFeRouteItem, 'path' | 'fetch' | 'webpackChunkName'> & {
  component: DynamicFC<T> | StaticFC<T>
} & U

export interface ReactRoutesType {
  Layout: React.FC<LayoutProps>
  App?: React.FC
  layoutFetch: ReactFetch
  FeRoutes: ReactESMFeRouteItem[]
  PrefixRouterBase?: string
  state?: any
  reducer?: any
  ErrorPage?: React.FC<DowngradeErrorComponentProps>
}

export interface IContext<T=any> {
  state?: T
  dispatch?: React.Dispatch<Action>
}
