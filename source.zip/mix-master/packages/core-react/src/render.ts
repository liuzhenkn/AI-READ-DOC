import { renderToString, renderToNodeStream } from 'react-dom/server'
import { StringToStream, mergeStream2 } from '@zh-mix/utils'
import { ISSRContext, ExpressContext, IConfig, ServerAppConfig } from '@zh-mix/types'
import { injectToHtml, log } from './utils'

function render (ctx: ISSRContext, app: ServerAppConfig, options?: Partial<IConfig>): Promise<string>
function render<T> (ctx: ISSRContext, app: ServerAppConfig, options?: Partial<IConfig>): Promise<T>

/**
 * react jsx to string or merger
 * @param ctx context
 * @param app 当前渲染 app 的 serverConfig
 * @param options 服务运行时配置重写
 * @returns reactRender
 */
async function render (ctx: ISSRContext, app: ServerAppConfig, options?: Partial<IConfig>) {
  const config = Object.assign({}, app.config, options ?? {})
  const { stream, isDev } = config

  if (!ctx.response.type && typeof ctx.response.type !== 'function') {
    ctx.response.type = 'text/html;charset=utf-8'
  } else if (!(ctx as ExpressContext).response.hasHeader?.('content-type')) {
    (ctx as ExpressContext).response.setHeader?.('Content-type', 'text/html;charset=utf-8')
  }

  const serverRes = await commonRender(ctx, config, app.file)

  if (stream) {
    const stream = mergeStream2(new StringToStream('<!DOCTYPE html>'), renderToNodeStream(serverRes.element))

    if (isDev) {
      // renderToNodeStream 为异步行为，延迟执行判断
      setTimeout(() => {
        // <title data-rh="true"></title>
        const title = serverRes?.helmet?.helmet?.title?.toString?.() || ''
        if (title.includes('</title>') && !title.includes('></title>')) {
          log('error # react-helmet 不支持服务端渲染的 stream 模式下使用，如果需要使用 react-helmet 请切换渲染模式为 string (stream: false)')
        }
      }, 1000)
    }
    return stream
  } else {
    const html = `<!DOCTYPE html>${renderToString(serverRes.element)}`
    const helmet = serverRes?.helmet?.helmet || null
    const inlineStyles = serverRes?.inlineStyles || []

    if (helmet || inlineStyles.length) {
      return injectToHtml(html, helmet, inlineStyles)
    }

    return html
  }
}

async function commonRender (ctx: ISSRContext, config: IConfig, serverFile: string) {
  const { isDev } = config

  if (isDev) {
    delete require.cache[serverFile]
  }

  const { serverRender } = require(serverFile)
  const serverRes = await serverRender(ctx, config)
  return serverRes
}

export {
  render
}
