import { load } from 'cheerio'

import * as debug from 'debug'
import type { HelmetServerState } from '@zh-mix-mkt/react-helmet'

export const log = debug('mix')
log.enabled = process.env.NODE_ENV === 'development'

export const injectToHtml = (html: string, helmet: HelmetServerState | null, inlineStyles: string[]): string => {
  try {
    const $ = load(html, {
      decodeEntities: false
    })

    if (helmet) {
      const title = helmet.title.toString()
      const htmlAttributes = helmet.htmlAttributes.toComponent()
      const meta = helmet.meta.toString()
      const link = helmet.link.toString()
      const style = helmet.style.toString()
      const script = helmet.script.toString()

      // 默认空值为："<title data-rh=\"true\"></title>"
      if (title && !title.includes('></title>')) {
        $('head').prepend(title)
      }

      if (meta) {
        $('head').append(meta)
      }

      if (link) {
        $('head').append(link)
      }

      if (style) {
        $('head').append(style)
      }

      if (script) {
        $('head').append(script)
      }

      if (Object.keys(htmlAttributes)) {
        Object.keys(htmlAttributes).forEach(attrKey => {
          // @ts-expect-error
          $('html').attr(attrKey, htmlAttributes[attrKey])
        })
      }
    }

    if (inlineStyles.length) {
      const styleString = `<style id="critical-css">${inlineStyles.join('')}</style>`
      if (styleString) {
        $('head').append(styleString)
      }
    }

    return $.html()
  } catch (error) {
    console.log(error)
  }

  return html
}
